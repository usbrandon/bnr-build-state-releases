import io
import json
import os
import shutil
from pathlib import Path

from bnr_build_state import runner
from bnr_build_state.state_api import StateUnavailable
from client_fixtures import MANIFEST, SELECTED, SRC_A, SRC_B, SRC_C, run_results, write_project

ENV = dict(BNR_URL='https://api.example.com', BNR_TOKEN='tok', BNR_ACCOUNT_ID='1', PW='pw')


class FakeDbt:
    """Pretends to be subprocess.run for `dbt`: compile writes artifacts, build writes run_results."""

    def __init__(self, project, *, compile_code=0, build_code=0, build_statuses=None, compile_ids=None,
                 build_writes_results=True, compile_writes=True, on_build=None, fusion=False, test_code=0,
                 test_statuses=None, test_writes_results=True, manifest=MANIFEST):
        self.project = Path(project)
        self.manifest = manifest
        self.calls = []
        self.compile_code = compile_code
        self.build_code = build_code
        self.build_statuses = build_statuses
        self.compile_ids = compile_ids
        self.build_writes_results = build_writes_results
        self.compile_writes = compile_writes
        self.on_build = on_build
        self.fusion = fusion
        self.test_code = test_code
        self.test_statuses = test_statuses or {}
        self.test_writes_results = test_writes_results
        self.results_present_at_build = None

    def __call__(self, argv, **kwargs):
        self.calls.append(list(argv))
        command = next(t for t in argv[1:] if not t.startswith('-'))
        target = self.project / 'target'
        if command == 'compile':
            if self.compile_code:
                shutil.rmtree(target, ignore_errors=True)
            elif self.fusion:  # Fusion 2.0 writes compile run_results.json with no results
                write_project(self.project, manifest=self.manifest, results=run_results({}, version='2.0.9', which='compile'))
            elif self.compile_writes:
                ids = SELECTED if self.compile_ids is None else self.compile_ids
                write_project(self.project, manifest=self.manifest, results=run_results({uid: 'success' for uid in ids}, which='compile'))
            else:
                os.utime(target / 'run_results.json', (1_000_000, 1_000_000))  # left over from an earlier invocation
            return type('P', (), dict(returncode=self.compile_code))()
        if command == 'ls':
            ids = (SELECTED if self.compile_ids is None else self.compile_ids) + ['source.p.raw.a', 'exposure.p.dash']
            lines = ['12:00:00 log line'] + [json.dumps(dict(unique_id=uid, resource_type=uid.split('.')[0])) for uid in ids]
            return type('P', (), dict(returncode=0, stdout='\n'.join(lines) + '\n'))()
        nodes = MANIFEST['nodes']
        if command == 'test':
            # `--select p.<name>`: the full fqn of each test; dbt test runs exactly those.
            fqns = argv[argv.index('--select') + 1:]
            wanted = {uid for uid, n in nodes.items() if '.'.join(n['fqn']) in fqns}
            if not self.test_writes_results:
                return type('P', (), dict(returncode=self.test_code))()
            statuses = {uid: self.test_statuses.get(uid, 'success') for uid in wanted}
            (target / 'run_results.json').write_text(json.dumps(run_results(statuses, which='test')))
            return type('P', (), dict(returncode=self.test_code))()
        self.results_present_at_build = (target / 'run_results.json').exists()
        if self.on_build:
            self.on_build()
        if not self.build_writes_results:
            return type('P', (), dict(returncode=self.build_code))()
        statuses = self.build_statuses or {uid: 'success' for uid in SELECTED}
        paths = set()
        if '--exclude' in argv:
            paths = {t.removeprefix('path:') for t in argv[argv.index('--exclude') + 1:] if t.startswith('path:')}
        gone = {uid for uid in nodes if nodes[uid]['original_file_path'] in paths}
        # dbt expands --exclude eagerly: a test goes when ANY of its parents is excluded; cautious needs all of them.
        eager = '--indirect-selection' not in argv or argv[argv.index('--indirect-selection') + 1] == 'eager'
        taken = any if eager else all
        statuses = {uid: s for uid, s in statuses.items() if uid not in gone
                    and not (uid.startswith('test.') and taken(d in gone for d in nodes[uid]['depends_on']['nodes']))}
        target.mkdir(exist_ok=True)  # like dbt, the build recreates the directory a failed compile left missing
        (target / 'run_results.json').write_text(json.dumps(run_results(statuses, which=command)))
        return type('P', (), dict(returncode=self.build_code))()


class FakeApi:
    def __init__(self, *, mode='shadow', skip=(), plan_error=None, report_error=None, disagreements=0):
        self.mode, self.skip, self.plan_error, self.report_error = mode, list(skip), plan_error, report_error
        self.disagreements = disagreements
        self.plans, self.reports = [], []

    def plan(self, body):
        if self.plan_error:
            raise self.plan_error
        self.plans.append(body)
        nodes = [dict(unique_id=n['unique_id'], action='skip' if n['unique_id'] in self.skip else 'build',
                      reason='skip' if n['unique_id'] in self.skip else 'sql_changed', inputs={}) for n in body['nodes']]
        return dict(plan_id='pl_1', mode=self.mode, state_key=7, nodes=nodes,
                    summary=dict(build=len(nodes) - len(self.skip), skip=len(self.skip), undetermined=0))

    events_sent = None

    def events(self, body):
        self.events_sent = (self.events_sent or []) + [body]
        return dict(id=len(self.events_sent))

    def report(self, body):
        if self.report_error:
            raise self.report_error
        self.reports.append(body)
        return dict(plan_id='pl_1', updated=len(body['results']), stale=0, disagreements=self.disagreements)

    def explain(self, plan_id):
        return dict(plan_id=plan_id, mode='shadow', nodes=[dict(unique_id='model.p.fct', action='skip', reason='skip',
                    inputs=dict(sql_sha256=['a' * 64, 'a' * 64], stamps={SRC_B: ['5', '5']}), result_status='reused')])


class FakeProvider:
    platform, dialect, locator = 'snowflake', 'snowflake', 'acme'
    warehouse_info = None

    def warehouse(self):
        return self.warehouse_info

    def __init__(self):
        self.closed = False
        self.observed = []

    def stamps(self, relations):
        return {r: f'stamp:{r.identifier}' for r in relations}

    definitions = {'stg': 'create or replace view D.S.stg as (select id from D.RAW.A)'}

    def view_definitions(self, relations):
        return {r: self.definitions.get(r.identifier) for r in relations}

    def relations(self, database, schema):
        return {'stg', 'fct', 'countries', 'snap'}

    def observe(self, relations, hash_scope=None):
        self.observed.extend(relations)
        self.hash_scope = dict(hash_scope or {})
        return {r: dict(schema_sha256='s' * 64) for r in relations}

    def close(self):
        self.closed = True


class FakeLoadedAt:
    """Replaces providers.base.loaded_at_stamps so no SQL runs for loaded_at sources."""

    def __call__(self, connection, items, batch=50):
        return {uid: f'loaded:{uid}' for uid, _ in items}


def _run(tmp_path, argv, *, env=ENV, api=None, provider_cls=FakeProvider, dbt=None, providers=None):
    write_project(tmp_path)
    dbt = dbt or FakeDbt(tmp_path)
    api = api if api is not None else FakeApi()
    providers = providers if providers is not None else []

    def factory(profile):
        providers.append(provider_cls())
        return providers[-1]
    out, err = io.StringIO(), io.StringIO()
    code = runner.run(argv, env, api_factory=lambda url, token: api, provider_factory=factory,
                      subprocess_run=dbt, out=out, err=err, cwd=str(tmp_path), loaded_at=FakeLoadedAt())
    return code, dbt, api, (providers[0] if providers else None), out.getvalue(), err.getvalue()


def test_shadow_runs_original_command_and_reports_with_observations(tmp_path):
    providers, closed_at_build = [], []
    dbt = FakeDbt(tmp_path, on_build=lambda: closed_at_build.append(providers[0].closed))
    code, dbt, api, provider, out, err = _run(tmp_path, ['build', '--select', 'x'], dbt=dbt, providers=providers)
    assert code == 0
    assert closed_at_build == [True] and len(providers) == 2 and all(p.closed for p in providers)
    assert dbt.calls[0] == ['dbt', 'compile', '--select', 'x'] and dbt.calls[1] == ['dbt', 'build', '--select', 'x']
    body = api.plans[0]
    assert body['project'] == 'p' and body['target'] == dict(platform='snowflake', locator='acme', database='D', schema='S')
    invocation = {k: v for k, v in body['invocation'].items() if k not in ('client', 'timings')}  # own test below
    assert invocation == dict(command='build', args=['--select', 'x'], cause='bnr dbt build')
    stamps = {s['unique_id']: (s['stamp'], s['stamp_kind']) for s in body['sources']}
    assert stamps[SRC_A] == (f'loaded:{SRC_A}', 'loaded_at_field') and stamps[SRC_B] == (f'loaded:{SRC_B}', 'loaded_at_query')
    assert stamps['source.p.raw.c'] == ('stamp:C', 'provider')
    assert {n['unique_id']: n['target_present'] for n in body['nodes']}['model.p.hooked'] is False
    report = api.reports[0]
    assert report['plan_id'] == 'pl_1' and len(report['observations']) == len(providers[1].observed) > 0 and provider.observed == []
    assert {o['unique_id'] for o in report['observations']} >= {'model.p.fct', 'model.p.stg', 'seed.p.countries'}  # seeds store rows too
    assert set(providers[1].hash_scope.values()) <= {'skip', 'default', 'force'} and len(providers[1].hash_scope) == len(providers[1].observed)
    assert 'built 10' in out and 'reused 0' in out and 'disagreements 0' in out and 'bnr state explain pl_1' in out
    assert len(dbt.calls) == 2  # nothing excluded, so no follow-up test step


def test_enforce_appends_exclusions_and_reports_reused(tmp_path):
    api = FakeApi(mode='enforce', skip=['model.p.fct', 'test.p.not_null_fct_id', 'seed.p.countries'])
    code, dbt, api, provider, out, _ = _run(tmp_path, ['build', '--exclude', 'other'], api=api)
    assert code == 0
    assert dbt.calls[1] == ['dbt', 'build', '--exclude', 'other', 'path:models/fct.sql', 'path:seeds/countries.csv']
    statuses = {r['unique_id']: r['status'] for r in api.reports[0]['results']}
    assert statuses['model.p.fct'] == 'reused' and statuses['seed.p.countries'] == 'reused'
    assert statuses['model.p.stg'] == 'success'
    assert api.reports[0]['observations']  # Enforce observes too: it verifies the nodes it built as `unverified`
    assert statuses['test.p.not_null_fct_id'] == 'reused'
    assert 'reused 3' in out


def test_planned_build_test_excluded_with_a_skipped_parent_runs_in_a_test_step(tmp_path):
    # The relationships test reads skipped fct and built stg. dbt's exclusion is greedy (any parent excluded takes the
    # test), so `--exclude path:models/fct.sql` dropped it from the build although the plan said build. A `dbt test`
    # step with the same global, target, path and defer flags, and none of the user's selection, runs exactly the
    # planned-build tests that went that way (here also not_null_fct_id, which this plan wanted built), and their
    # results land in the report.
    api = FakeApi(mode='enforce', skip=['model.p.fct'])
    argv = ['--debug', 'build', '-s', 'x', '--target', 'dev', '--defer', '--state', 'st', '--threads', '4', '--vars', 'a: 1',
            '--exclude', 'other', '--store-failures']
    code, dbt, api, _, out, err = _run(tmp_path, argv, api=api)
    assert code == 0
    assert dbt.calls[2] == ['dbt', '--debug', 'test', '--target', 'dev', '--defer', '--state', 'st', '--threads', '4', '--vars', 'a: 1',
                            '--store-failures', '--select', 'p.not_null_fct_id', 'p.relationships_fct_stg']
    statuses = {r['unique_id']: r['status'] for r in api.reports[0]['results']}
    assert statuses['test.p.relationships_fct_stg'] == 'success' and statuses['test.p.not_null_fct_id'] == 'success'
    assert statuses['model.p.fct'] == 'reused'
    assert 'running 2 test(s) dbt excluded with a skipped parent' in err and 'missing from dbt results' not in err
    assert 'built 9' in out and 'reused 1' in out  # ten selected: nine built (two of them in the test step), fct reused


def test_test_step_failure_fails_the_invocation_and_is_reported(tmp_path):
    api = FakeApi(mode='enforce', skip=['model.p.fct'])
    dbt = FakeDbt(tmp_path, test_code=1, test_statuses={'test.p.relationships_fct_stg': 'fail'})
    code, dbt, api, _, out, _ = _run(tmp_path, ['build'], api=api, dbt=dbt)
    assert code == 1 and dbt.calls[2][:3] == ['dbt', 'test', '--select']
    statuses = {r['unique_id']: r['status'] for r in api.reports[0]['results']}
    assert statuses['test.p.relationships_fct_stg'] == 'error' and 'errors 1' in out


def test_build_failure_keeps_its_exit_code_over_a_passing_test_step(tmp_path):
    api = FakeApi(mode='enforce', skip=['model.p.fct'])
    code, dbt, _, _, _, _ = _run(tmp_path, ['build'], api=api, dbt=FakeDbt(tmp_path, build_code=2))
    assert code == 2 and len(dbt.calls) == 3


def test_fail_fast_build_failure_skips_the_test_step(tmp_path):
    api = FakeApi(mode='enforce', skip=['model.p.fct'])
    code, dbt, api, _, _, err = _run(tmp_path, ['build', '-x'], api=api, dbt=FakeDbt(tmp_path, build_code=1))
    assert code == 1 and len(dbt.calls) == 2 and 'not running' in err and len(api.reports) == 1


def test_test_step_without_results_warns_and_the_planned_test_is_reported_missing(tmp_path):
    api = FakeApi(mode='enforce', skip=['model.p.fct'])
    dbt = FakeDbt(tmp_path, test_code=2, test_writes_results=False)
    code, _, api, _, _, err = _run(tmp_path, ['build'], api=api, dbt=dbt)
    assert code == 2 and 'no run results from the dbt test step' in err
    assert 'missing from dbt results: test.p.not_null_fct_id, test.p.relationships_fct_stg' in err
    assert 'test.p.relationships_fct_stg' not in {r['unique_id'] for r in api.reports[0]['results']}


def test_users_cautious_indirect_selection_is_respected_and_no_test_step_is_needed(tmp_path):
    # Under cautious, dbt excludes a test only when all its parents are excluded, so the relationships test ran in the
    # build and nothing is left to re-run; the user's flag is forwarded unchanged.
    api = FakeApi(mode='enforce', skip=['model.p.fct'])
    code, dbt, api, _, _, err = _run(tmp_path, ['build', '--indirect-selection', 'cautious'], api=api)
    assert code == 0 and dbt.calls[1][:5] == ['dbt', 'build', '--indirect-selection', 'cautious', '--exclude']
    statuses = {r['unique_id']: r['status'] for r in api.reports[0]['results']}
    assert statuses['test.p.relationships_fct_stg'] == 'success'
    assert dbt.calls[2] == ['dbt', 'test', '--indirect-selection', 'cautious', '--select', 'p.not_null_fct_id']


def test_run_command_never_adds_a_test_step(tmp_path):
    api = FakeApi(mode='enforce', skip=['model.p.fct'])
    code, dbt, _, _, _, err = _run(tmp_path, ['run'], api=api)
    assert code == 0 and [c[1] for c in dbt.calls] == ['compile', 'run'] and 'test(s)' not in err


def test_off_mode_runs_original_without_exclusions(tmp_path):
    code, dbt, api, _, _, _ = _run(tmp_path, ['run'], api=FakeApi(mode='off', skip=['model.p.fct']))
    assert code == 0 and dbt.calls[1] == ['dbt', 'run'] and len(api.reports) == 1


def test_mode_override_off_skips_state_entirely(tmp_path):
    code, dbt, api, _, _, err = _run(tmp_path, ['build'], env=dict(ENV, BNR_STATE_MODE_OVERRIDE='off'))
    assert code == 0 and dbt.calls == [['dbt', 'build']] and api.plans == []
    assert 'BNR_STATE_MODE_OVERRIDE=off' in err


def test_missing_configuration_runs_original(tmp_path):
    code, dbt, api, _, _, err = _run(tmp_path, ['build'], env={'PW': 'pw'})
    assert code == 0 and dbt.calls == [['dbt', 'build']] and api.plans == [] and 'BNR_URL' in err


def test_empty_and_sample_runs_are_not_planned_or_reported(tmp_path):
    # `--empty` and `--sample` build relations with no or partial data: recording them as built would let the
    # next real run skip them. Nothing is planned and nothing is reported; dbt runs unchanged.
    for argv in (['build', '--empty'], ['run', '--sample', '3 days', '-s', 'x']):
        code, dbt, api, _, _, err = _run(tmp_path, argv)
        assert code == 0 and dbt.calls == [['dbt', *argv]] and api.plans == [] and api.reports == []
        assert 'partial data' in err


def test_non_wrapped_command_passes_through(tmp_path):
    code, dbt, api, _, _, _ = _run(tmp_path, ['docs', 'generate'])
    assert code == 0 and dbt.calls == [['dbt', 'docs', 'generate']] and api.plans == []


def test_compile_failure_falls_back_to_the_original_command(tmp_path):
    # Compile can fail where the build would not (a flag compile lacks, jinja introspecting a relation an
    # upstream model creates): the customer's run must never be blocked by the wrapper's own step.
    code, dbt, api, _, _, err = _run(tmp_path, ['build', '-s', 'x'], dbt=FakeDbt(tmp_path, compile_code=2))
    assert code == 0 and dbt.calls == [['dbt', 'compile', '-s', 'x'], ['dbt', 'build', '-s', 'x']] and api.plans == []
    assert 'state service unavailable, building everything' in err and 'compile exited 2' in err


def test_plan_failure_builds_everything_without_report(tmp_path):
    api = FakeApi(plan_error=StateUnavailable('http 503'))
    code, dbt, api, _, _, err = _run(tmp_path, ['build', '-s', 'x'], api=api)
    assert code == 0 and dbt.calls[1] == ['dbt', 'build', '-s', 'x'] and api.reports == []
    assert 'state service unavailable, building everything' in err and 'http 503' in err


def test_unsupported_adapter_builds_everything(tmp_path):
    from bnr_build_state.providers.base import UnsupportedAdapter

    def factory(profile):
        raise UnsupportedAdapter('no stamp provider for adapter bigquery')
    write_project(tmp_path)
    dbt = FakeDbt(tmp_path)
    err = io.StringIO()
    code = runner.run(['build'], ENV, api_factory=lambda u, t: FakeApi(), provider_factory=factory, subprocess_run=dbt,
                      out=io.StringIO(), err=err, cwd=str(tmp_path), loaded_at=FakeLoadedAt())
    assert code == 0 and dbt.calls == [['dbt', 'compile'], ['dbt', 'build']] and 'bigquery' in err.getvalue()


def test_report_failure_does_not_change_exit_code(tmp_path):
    api = FakeApi(report_error=StateUnavailable('timeout'))
    code, _, _, _, out, err = _run(tmp_path, ['build'], api=api, dbt=FakeDbt(tmp_path, build_code=1))
    assert code == 1 and 'report failed' in err and 'timeout' in err
    assert 'disagreements' not in out  # nothing was reported, so there is no count to show


def test_dbt_failure_is_reported_and_exit_code_preserved(tmp_path):
    statuses = {uid: 'success' for uid in SELECTED}
    statuses['model.p.fct'] = 'error'
    code, _, api, _, out, _ = _run(tmp_path, ['build'], dbt=FakeDbt(tmp_path, build_code=1, build_statuses=statuses))
    assert code == 1
    assert {r['unique_id']: r['status'] for r in api.reports[0]['results']}['model.p.fct'] == 'error'
    assert 'errors 1' in out


def test_run_id_and_cause_come_from_env(tmp_path):
    _, _, api, _, _, _ = _run(tmp_path, ['build'], env=dict(ENV, BNR_RUN_ID='42', BNR_CAUSE='airflow nightly'))
    assert api.plans[0]['run_id'] == 42 and api.plans[0]['invocation']['cause'] == 'airflow nightly'


def test_explain_prints_one_line_per_node_and_filters():
    out = io.StringIO()
    assert runner.explain('pl_1', ENV, api_factory=lambda u, t: FakeApi(), out=out) == 0
    text = out.getvalue()
    assert 'model.p.fct' in text and 'skip' in text and 'reused' in text and 'aaaaaaaa' in text
    out = io.StringIO()
    runner.explain('pl_1', ENV, api_factory=lambda u, t: FakeApi(), node='nothing', out=out)
    assert 'model.p.fct' not in out.getvalue()


def test_unselected_view_parent_is_stamped_by_lineage(tmp_path):
    ids = [uid for uid in SELECTED if uid != 'model.p.stg']
    code, _, api, _, _, _ = _run(tmp_path, ['build'], dbt=FakeDbt(tmp_path, compile_ids=ids))
    assert code == 0
    body = api.plans[0]
    sources = {s['unique_id']: (s['stamp'], s['stamp_kind']) for s in body['sources']}
    assert sources['model.p.stg'][0].startswith('lineage:') and sources['model.p.stg'][1] == 'lineage'
    assert 'model.p.stg' not in {n['unique_id'] for n in body['nodes']}
    assert SRC_A not in sources  # a lineage leaf is an input to the stamp, not a request source


def test_favor_state_makes_unselected_parents_unknown(tmp_path):
    # With --defer --favor-state dbt resolves an unselected parent to the --state artifacts' relation even when
    # the one the manifest names exists, so a stamp on the manifest's relation tracks a table the SQL never reads.
    ids = [uid for uid in SELECTED if uid != 'model.p.stg']
    argv = ['build', '--defer', '--favor-state', '--state', 'prod', '-s', 'fct']
    code, dbt, api, _, _, _ = _run(tmp_path, argv, dbt=FakeDbt(tmp_path, compile_ids=ids))
    assert code == 0 and dbt.calls[1] == ['dbt', *argv]
    sources = {s['unique_id']: (s['stamp'], s['stamp_kind']) for s in api.plans[0]['sources']}
    assert sources['model.p.stg'] == (None, 'unknown')
    assert sources[SRC_B] == ('loaded:' + SRC_B, 'loaded_at_query')  # sources are the same relation in every target


def _lineage_manifest(**overrides):
    def node(uid, materialized, deps):
        name = uid.rsplit('.', 1)[-1]
        return dict(unique_id=uid, resource_type=uid.split('.')[0], name=name, database='D', schema='S', alias=name,
                    config={'materialized': materialized}, depends_on=dict(nodes=list(deps)),
                    relation_name=None if materialized == 'ephemeral' else 'D.S.' + name)
    nodes = {
        'model.p.child': node('model.p.child', 'table', ['model.p.v1', 'model.p.eph']),
        'model.p.v1': node('model.p.v1', 'view', ['model.p.v2', SRC_A]),
        'model.p.v2': node('model.p.v2', 'view', ['model.p.tbl']),
        'model.p.tbl': node('model.p.tbl', 'table', [SRC_B]),
        'model.p.eph': node('model.p.eph', 'ephemeral', [SRC_A]),
    }
    for uid, changes in overrides.items():
        nodes[uid] = {**nodes[uid], **changes}
    return dict(nodes=nodes, sources={uid: MANIFEST['sources'][uid] for uid in (SRC_A, SRC_B)})


LINEAGE_VIEWS = {
    'v1': 'create or replace view D.S.V1 copy grants as (with a as (select id from D.RAW.A) select a.id from a join v2 on true)',
    'v2': 'create or replace view D.S.V2 as select id from "D"."S"."TBL"',
}


class _Fact:
    def __init__(self, uid, deps):
        self.unique_id, self.depends_on = uid, tuple(deps)


def _lineage_stamps(manifest, selected=('model.p.child',), provider=None, views=None):
    provider = provider or FakeProvider()
    provider.definitions = LINEAGE_VIEWS if views is None else views
    facts = [_Fact(uid, manifest['nodes'][uid]['depends_on']['nodes']) for uid in selected]
    return runner._stamps(provider, {}, FakeLoadedAt(), runner._parents(manifest, facts))


def test_lineage_resolves_through_views_and_ephemerals_to_tables_and_sources():
    stamps = _lineage_stamps(_lineage_manifest())
    assert set(stamps) == {'model.p.v1', 'model.p.eph'}
    assert all(stamp.startswith('lineage:') and kind == 'lineage' for stamp, kind in stamps.values())
    assert stamps == _lineage_stamps(_lineage_manifest())  # deterministic


def test_lineage_stamp_changes_with_a_leaf_stamp_or_a_deployed_definition():
    base = _lineage_stamps(_lineage_manifest())['model.p.v1'][0]
    class Moved(FakeProvider):
        def stamps(self, relations):
            return {r: f'moved:{r.identifier}' for r in relations}
    assert _lineage_stamps(_lineage_manifest(), provider=Moved())['model.p.v1'][0] != base
    redeployed = dict(LINEAGE_VIEWS, v2='create or replace view D.S.V2 as select id from D.S.TBL where id > 0')
    assert _lineage_stamps(_lineage_manifest(), views=redeployed)['model.p.v1'][0] != base


def test_lineage_is_unknown_when_anything_on_it_cannot_be_trusted():
    class NoTables(FakeProvider):
        def stamps(self, relations):
            return {r: None for r in relations}
    unknown = (None, 'unknown')
    assert _lineage_stamps(_lineage_manifest(), provider=NoTables())['model.p.v1'] == unknown
    # A leaf this run builds may change under the view: never stable.
    assert _lineage_stamps(_lineage_manifest(), selected=('model.p.child', 'model.p.tbl'))['model.p.v1'] == unknown
    # The deployed definition is unreadable (no privilege), unparsable, or reads a relation no ref or source names.
    assert _lineage_stamps(_lineage_manifest(), views=dict(LINEAGE_VIEWS, v2=None))['model.p.v1'] == unknown
    assert _lineage_stamps(_lineage_manifest(), views=dict(LINEAGE_VIEWS, v2='not sql (((('))['model.p.v1'] == unknown
    hardcoded = dict(LINEAGE_VIEWS, v2='create view D.S.V2 as select id from D.S.TBL join RAW.X.Y on true')
    assert _lineage_stamps(_lineage_manifest(), views=hardcoded)['model.p.v1'] == unknown
    missing = _lineage_manifest(**{'model.p.v2': dict(depends_on=dict(nodes=['model.p.gone']))})
    assert _lineage_stamps(missing)['model.p.v1'] == unknown
    cycle = _lineage_manifest(**{'model.p.v2': dict(depends_on=dict(nodes=['model.p.v1']))})
    assert _lineage_stamps(cycle)['model.p.v1'] == unknown
    no_inputs = _lineage_manifest(**{'model.p.v1': dict(depends_on=dict(nodes=[]))})
    assert _lineage_stamps(no_inputs, views=dict(LINEAGE_VIEWS, v1='create view D.S.V1 as select 1 as id'))['model.p.v1'] == unknown
    # The ephemeral reads only SRC_A (loaded_at), so it stays resolvable.
    assert _lineage_stamps(_lineage_manifest(), provider=NoTables())['model.p.eph'][1] == 'lineage'


def test_loaded_at_field_takes_precedence_over_a_provider_that_cannot_stamp():
    # BCS's P21 raw tables are externally catalogued Iceberg tables (provider stamp: unknown) that declare
    # loaded_at_field; the declared query is the stamp and the provider is never asked about them.
    class Unknown(FakeProvider):
        def stamps(self, relations):
            self.asked = list(relations)
            return {r: None for r in relations}
    provider = Unknown()
    sources = {uid: MANIFEST['sources'][uid] for uid in (SRC_A, SRC_B, SRC_C)}
    stamps = runner._stamps(provider, sources, FakeLoadedAt())
    assert stamps[SRC_A] == (f'loaded:{SRC_A}', 'loaded_at_field') and stamps[SRC_B] == (f'loaded:{SRC_B}', 'loaded_at_query')
    assert stamps[SRC_C] == (None, 'unknown') and [r.identifier for r in provider.asked] == ['C']


def test_unselected_parent_without_a_relation_is_unknown_not_omitted():
    # The planner ignores a dependency it is not told about, so a parent the client cannot stamp must be sent as
    # unknown (which forces a build), never left out (which reads as unchanged).
    manifest = _lineage_manifest(**{'model.p.child': dict(depends_on=dict(nodes=['model.p.tbl'])),
                                    'model.p.tbl': dict(relation_name=None)})
    assert _lineage_stamps(manifest) == {'model.p.tbl': (None, 'unknown')}


def test_skipped_test_with_unexcluded_parent_is_not_reported_reused(tmp_path):
    statuses = {uid: 'success' for uid in SELECTED if not uid.startswith('test.')}
    api = FakeApi(mode='enforce', skip=['test.p.not_null_fct_id'])
    _, dbt, api, _, _, _ = _run(tmp_path, ['build'], api=api, dbt=FakeDbt(tmp_path, build_statuses=statuses))
    assert 'test.p.not_null_fct_id' not in {r['unique_id'] for r in api.reports[0]['results']}
    assert len(dbt.calls) == 2  # a test dbt dropped on its own is not re-run either


def test_planned_skip_test_with_an_excluded_parent_is_reused_and_not_re_run(tmp_path):
    api = FakeApi(mode='enforce', skip=['model.p.fct', 'model.p.stg', 'test.p.relationships_fct_stg', 'test.p.not_null_fct_id'])
    code, dbt, api, _, out, _ = _run(tmp_path, ['build'], api=api)
    statuses = {r['unique_id']: r['status'] for r in api.reports[0]['results']}
    assert code == 0 and len(dbt.calls) == 2
    assert statuses['test.p.relationships_fct_stg'] == 'reused' and statuses['test.p.not_null_fct_id'] == 'reused'
    assert 'reused 4' in out


def test_empty_compile_results_take_the_selection_from_dbt_ls(tmp_path):
    dbt = FakeDbt(tmp_path, fusion=True)
    code, dbt, api, _, out, _ = _run(tmp_path, ['--debug', 'build', '--selector', 'nightly', '--threads', '8'],
                                     dbt=dbt)
    assert code == 0
    assert dbt.calls[1] == ['dbt', '--debug', 'ls', '--selector', 'nightly', '--output', 'json', '-q']
    assert dbt.calls[2] == ['dbt', '--debug', 'build', '--selector', 'nightly', '--threads', '8']
    assert {n['unique_id'] for n in api.plans[0]['nodes']} == set(SELECTED) - {'model.p.eph'}  # ephemerals are folded into their readers
    assert api.plans[0]['engine'] == dict(family='fusion', version='2.0.9')


def test_failed_dbt_ls_falls_back_to_the_original_command(tmp_path):
    class LsFails(FakeDbt):
        def __call__(self, argv, **kwargs):
            if 'ls' in argv:
                self.calls.append(list(argv))
                return type('P', (), dict(returncode=2, stdout=''))()
            return super().__call__(argv, **kwargs)
    code, dbt, api, _, _, err = _run(tmp_path, ['build'], dbt=LsFails(tmp_path, fusion=True))
    assert code == 0 and api.plans == [] and dbt.calls[-1] == ['dbt', 'build'] and 'dbt ls exited 2' in err


def test_compile_phase_results_are_removed_before_the_build(tmp_path):
    _, dbt, _, _, _, _ = _run(tmp_path, ['build'])
    assert dbt.results_present_at_build is False


def test_missing_build_results_skips_report_and_keeps_exit_code(tmp_path):
    code, dbt, api, _, out, err = _run(tmp_path, ['build'], dbt=FakeDbt(tmp_path, build_code=3, build_writes_results=False))
    assert code == 3 and len(api.plans) == 1 and api.reports == []
    assert '[bnr] no run results from dbt, nothing reported' in err and 'built 0' in out


def test_stale_compile_artifacts_fall_back(tmp_path):
    code, dbt, api, _, _, err = _run(tmp_path, ['build'], dbt=FakeDbt(tmp_path, compile_writes=False))
    assert code == 0 and api.plans == [] and dbt.calls[1] == ['dbt', 'build'] and 'compile artifacts are stale' in err


def test_unexpected_provider_error_before_plan_falls_back(tmp_path):
    class Boom(FakeProvider):
        def stamps(self, relations):
            raise RuntimeError('driver')
    code, dbt, api, _, _, err = _run(tmp_path, ['build'], provider_cls=Boom)
    assert code == 0 and dbt.calls[1] == ['dbt', 'build'] and api.plans == [] and 'RuntimeError: driver' in err


def test_provider_factory_error_falls_back(tmp_path):
    def factory(profile):
        raise RuntimeError('driver')
    write_project(tmp_path)
    dbt, err = FakeDbt(tmp_path), io.StringIO()
    code = runner.run(['build'], ENV, api_factory=lambda u, t: FakeApi(), provider_factory=factory, subprocess_run=dbt,
                      out=io.StringIO(), err=err, cwd=str(tmp_path), loaded_at=FakeLoadedAt())
    assert code == 0 and dbt.calls == [['dbt', 'compile'], ['dbt', 'build']] and 'RuntimeError' in err.getvalue()


def test_unknown_plan_mode_falls_back_without_report(tmp_path):
    code, dbt, api, _, _, err = _run(tmp_path, ['build'], api=FakeApi(mode='weird'))
    assert code == 0 and dbt.calls[1] == ['dbt', 'build'] and api.reports == [] and 'state service unavailable' in err


def test_close_failure_does_not_change_exit_code(tmp_path):
    class BadClose(FakeProvider):
        def close(self):
            raise OSError('close')
    code, dbt, api, _, _, err = _run(tmp_path, ['build'], provider_cls=BadClose, dbt=FakeDbt(tmp_path, build_code=4))
    assert code == 4 and len(api.reports) == 1 and 'close' in err


def test_observation_values_are_json_safe(tmp_path):
    import datetime

    class Dated(FakeProvider):
        def observe(self, relations, hash_scope=None):
            return {r: dict(row_count=datetime.datetime(2026, 1, 1)) for r in relations}
    _, _, api, _, _, _ = _run(tmp_path, ['build'], provider_cls=Dated)
    json.dumps(api.reports[0])


def test_project_dir_comes_from_env(tmp_path):
    proj = tmp_path / 'proj'
    write_project(proj)
    dbt, out = FakeDbt(proj), io.StringIO()
    api = FakeApi()
    code = runner.run(['build'], dict(ENV, DBT_PROJECT_DIR=str(proj)), api_factory=lambda u, t: api,
                      provider_factory=lambda p: FakeProvider(), subprocess_run=dbt, out=out, err=io.StringIO(),
                      cwd=str(tmp_path), loaded_at=FakeLoadedAt())
    assert code == 0 and len(api.plans) == 1


def test_missing_planned_build_node_is_warned_about_and_exit_code_kept(tmp_path):
    statuses = {uid: 'success' for uid in SELECTED if uid != 'model.p.hooked'}
    code, _, api, _, out, err = _run(tmp_path, ['build'], dbt=FakeDbt(tmp_path, build_code=1, build_statuses=statuses))
    assert code == 1 and len(api.reports) == 1
    assert '[bnr] warning: 1 planned node(s) missing from dbt results: model.p.hooked' in err


def test_no_missing_warning_when_every_planned_node_ran(tmp_path):
    _, _, _, _, _, err = _run(tmp_path, ['build'])
    assert 'missing from dbt results' not in err


def test_missing_warning_ignores_nodes_the_client_excluded(tmp_path):
    api = FakeApi(mode='enforce', skip=['model.p.fct', 'test.p.not_null_fct_id', 'seed.p.countries'])
    _, _, _, _, _, err = _run(tmp_path, ['build'], api=api)
    assert 'missing from dbt results' not in err


def test_selector_disables_enforce_exclusions_and_reports_as_shadow(tmp_path):
    api = FakeApi(mode='enforce', skip=['model.p.fct', 'seed.p.countries'])
    code, dbt, api, _, out, err = _run(tmp_path, ['build', '--selector', 's'], api=api)
    assert code == 0 and dbt.calls[1] == ['dbt', 'build', '--selector', 's']
    assert '[bnr] --selector in use: Enforce exclusions not applied (dbt does not combine --exclude with --selector); planning in Shadow' in err
    report = api.reports[0]
    assert report['observations'] and 'reused' not in {r['status'] for r in report['results']}
    assert 'reused 0' in out


def test_default_selector_in_selectors_yml_disables_enforce_exclusions(tmp_path):
    (tmp_path / 'selectors.yml').write_text('selectors:\n  - name: nightly\n    default: true\n    definition: tag:nightly\n')
    api = FakeApi(mode='enforce', skip=['model.p.fct'])
    _, dbt, api, _, _, err = _run(tmp_path, ['build'], api=api)
    assert dbt.calls[1] == ['dbt', 'build'] and '--selector in use' in err and api.reports[0]['observations']


def test_selectors_yml_without_a_default_does_not_block_enforce(tmp_path):
    (tmp_path / 'selectors.yml').write_text('selectors:\n  - name: nightly\n    definition: tag:nightly\n')
    api = FakeApi(mode='enforce', skip=['model.p.fct'])
    _, dbt, _, _, _, err = _run(tmp_path, ['build'], api=api)
    assert dbt.calls[1] == ['dbt', 'build', '--exclude', 'path:models/fct.sql'] and '--selector in use' not in err


def test_unreadable_schema_listing_means_targets_absent_without_fallback(tmp_path):
    class NoSchema(FakeProvider):
        def relations(self, database, schema):
            raise RuntimeError('schema does not exist')
    code, dbt, api, _, _, err = _run(tmp_path, ['build'], provider_cls=NoSchema)
    assert code == 0 and len(api.plans) == 1 and dbt.calls[1] == ['dbt', 'build']
    assert '[bnr] warning: could not list D.S: schema does not exist; treating its targets as absent' in err
    assert 'building everything' not in err
    targets = [n for n in api.plans[0]['nodes'] if n['unique_id'] in ('model.p.fct', 'seed.p.countries')]
    assert targets and all(n['target_present'] is False for n in targets)


def test_vars_are_redacted_in_the_plan_but_not_in_the_dbt_command(tmp_path):
    code, dbt, api, _, _, _ = _run(tmp_path, ['build', '--vars', '{"pw": "x"}'])
    assert code == 0 and dbt.calls[1] == ['dbt', 'build', '--vars', '{"pw": "x"}']
    assert api.plans[0]['invocation']['args'] == ['--vars', '<redacted>']


def test_warehouse_is_sent_only_when_complete(tmp_path):
    class Sized(FakeProvider):
        warehouse_info = dict(name='W', size='Small', credits_per_hour=2)

    class Unpriced(FakeProvider):
        warehouse_info = dict(name='W', size='Snowpark-optimized')

    class Broken(FakeProvider):
        def warehouse(self):
            raise RuntimeError('boom')

    _, _, api, _, _, _ = _run(tmp_path, ['build'], provider_cls=Sized)
    assert api.plans[0]['invocation']['warehouse'] == dict(name='W', size='Small', credits_per_hour=2)
    for cls in (FakeProvider, Unpriced, Broken):
        code, _, api, _, _, err = _run(tmp_path, ['build'], provider_cls=cls)
        assert code == 0 and 'warehouse' not in api.plans[0]['invocation'] and api.plans


def test_resource_type_filters_keep_unbuilt_nodes_out_of_the_plan(tmp_path):
    code, dbt, api, _, _, err = _run(tmp_path, ['build', '--resource-type', 'model', '--resource-type', 'snapshot'])
    assert code == 0 and '--resource-type' not in dbt.calls[0]
    kinds = {n['unique_id'].split('.')[0] for n in api.plans[0]['nodes']}
    assert kinds <= {'model', 'snapshot'} and 'snapshot' in kinds
    assert 'missing from dbt results' not in err


def test_plan_invocation_names_the_client_and_times_its_own_steps(tmp_path):
    from bnr_build_state import __version__
    code, _, api, _, _, _ = _run(tmp_path, ['build'])
    invocation = api.plans[0]['invocation']
    assert invocation['client'] == dict(name='bnr-build-state', version=__version__, executor='local')
    timings = invocation['timings']
    assert set(timings) == {'compile_ms', 'list_ms', 'stamps_ms', 'before_plan_ms'}
    assert all(isinstance(v, int) and v >= 0 for v in timings.values())
    assert timings['before_plan_ms'] >= timings['compile_ms']


def test_fallback_before_planning_is_recorded_as_a_client_event(tmp_path):
    code, _, api, _, _, err = _run(tmp_path, ['build'], dbt=None, api=FakeApi(plan_error=StateUnavailable('http 503: down')))
    assert code == 0 and not api.plans
    (event,) = api.events_sent
    assert event['kind'] == 'fallback' and event['plan_id'] is None and event['project'] == 'p'
    assert any('http 503: down' in m for m in event['messages'])
    assert event['invocation']['client']['name'] == 'bnr-build-state'


def test_planned_run_sends_its_warnings_and_a_clean_run_sends_nothing(tmp_path):
    _, _, api, _, _, _ = _run(tmp_path, ['build'])
    assert api.events_sent is None

    class Unlistable(FakeProvider):
        def relations(self, database, schema):
            raise RuntimeError('schema does not exist')
    api = FakeApi()
    code, _, api, _, _, _ = _run(tmp_path / 'b', ['build'], api=api, provider_cls=Unlistable)
    (event,) = api.events_sent
    assert code == 0 and event['kind'] == 'warnings' and event['plan_id'] == 'pl_1'
    assert any('schema does not exist' in m for m in event['messages'])


def test_event_messages_never_carry_the_token(tmp_path):
    env = dict(ENV, BNR_TOKEN='sekret-token')
    api = FakeApi(plan_error=StateUnavailable('http 401: bad token sekret-token'))
    _run(tmp_path, ['build'], env=env, api=api)
    assert 'sekret-token' not in json.dumps(api.events_sent)


def test_runs_that_never_consult_the_service_send_no_event(tmp_path):
    api = FakeApi()
    _run(tmp_path, ['build'], env=dict(ENV, BNR_STATE_MODE_OVERRIDE='off'), api=api)
    _run(tmp_path / 'b', ['build'], env={k: v for k, v in ENV.items() if k != 'BNR_TOKEN'}, api=api)
    assert api.events_sent is None


def test_event_failure_never_changes_the_exit_code(tmp_path):
    class Broken(FakeApi):
        def events(self, body):
            raise StateUnavailable('http 500')
    code, _, _, _, _, err = _run(tmp_path, ['build'], api=Broken(plan_error=StateUnavailable('down')))
    assert code == 0 and 'could not record the fallback event' in err


def test_provider_log_warnings_reach_the_event(tmp_path):
    import logging

    class Quiet(FakeProvider):
        def stamps(self, relations):
            logging.getLogger('bnr_build_state.providers.snowflake').warning('build-state commit_time query timed out for 3 relation(s)')
            return super().stamps(relations)
    api = FakeApi()
    _run(tmp_path, ['build'], api=api, provider_cls=Quiet)
    (event,) = api.events_sent
    assert any('commit_time query timed out' in m for m in event['messages'])
    assert not logging.getLogger('bnr_build_state').handlers  # the handler is removed after the run


def test_dbt_run_plans_models_only(tmp_path):
    api = FakeApi()
    _run(tmp_path, ['run'], api=api)
    kinds = {n['unique_id'].split('.')[0] for n in api.plans[0]['nodes']}
    assert kinds == {'model'}


def test_a_non_numeric_account_id_never_fails_the_build(tmp_path):
    api = FakeApi()
    code, _, api, _, _, err = _run(tmp_path, ['build'], env=dict(ENV, BNR_ACCOUNT_ID='acct-1'), api=api)
    assert code == 0 and api.plans == [] and api.events_sent is None
    assert 'could not record the fallback event' in err


def test_a_reader_of_an_ephemeral_is_planned_with_the_ephemerals_sources(tmp_path):
    """The ephemeral is not a node (dbt never builds it); its reader carries its sources and a hash that covers its SQL."""
    manifest = {**MANIFEST, 'nodes': dict(MANIFEST['nodes'])}
    manifest['nodes']['model.p.rd'] = dict(MANIFEST['nodes']['model.p.fct'], unique_id='model.p.rd', name='rd', alias='rd',
                                         original_file_path='models/rd.sql', relation_name='D.S.rd', fqn=['p', 'rd'],
                                         depends_on=dict(macros=[], nodes=['model.p.eph']), compiled_code='select id from __dbt__cte__eph')
    write_project(tmp_path, manifest=manifest)
    api = FakeApi()
    _run(tmp_path, ['build'], api=api, dbt=FakeDbt(tmp_path, compile_ids=SELECTED + ['model.p.rd'], manifest=manifest))
    nodes = {n['unique_id']: n for n in api.plans[0]['nodes']}
    assert 'model.p.eph' not in nodes and nodes['model.p.rd']['depends_on'] == [SRC_C]
    assert SRC_C in {s['unique_id'] for s in api.plans[0]['sources']}


def test_an_empty_selection_is_not_a_fallback(tmp_path):
    """`state:modified+` with nothing modified: dbt builds nothing, bnr plans nothing and records no event."""
    api = FakeApi()
    code, dbt, api, _, _, err = _run(tmp_path, ['build', '--select', 'state:modified+'], api=api,
                                     dbt=FakeDbt(tmp_path, fusion=True, compile_ids=[]))
    assert code == 0 and api.plans == [] and api.events_sent is None
    assert 'the selection is empty' in err and dbt.calls[-1] == ['dbt', 'build', '--select', 'state:modified+']


def test_a_reader_of_a_selected_view_is_planned_with_the_views_parents(tmp_path):
    """T (table) <- V (view) <- D (table): the plan request gives D the view's parent and source, so a rebuild of T or
    new data in its source reaches D although the view itself skips."""
    manifest = {**MANIFEST, 'nodes': dict(MANIFEST['nodes'])}
    base = MANIFEST['nodes']['model.p.fct']
    manifest['nodes']['model.p.v'] = dict(base, unique_id='model.p.v', name='v', alias='v', original_file_path='models/v.sql',
                                        relation_name='D.S.v', fqn=['p', 'v'], config={'materialized': 'view', 'pre-hook': [], 'post-hook': []},
                                        depends_on=dict(macros=[], nodes=['model.p.fct']), compiled_code='select id from D.S.fct')
    manifest['nodes']['model.p.d'] = dict(base, unique_id='model.p.d', name='d', alias='d', original_file_path='models/d.sql',
                                        relation_name='D.S.d', fqn=['p', 'd'], depends_on=dict(macros=[], nodes=['model.p.v']),
                                        compiled_code='select id from D.S.v')
    write_project(tmp_path, manifest=manifest)
    api = FakeApi()
    _run(tmp_path, ['build'], api=api, dbt=FakeDbt(tmp_path, compile_ids=SELECTED + ['model.p.v', 'model.p.d'], manifest=manifest))
    deps = {n['unique_id']: n['depends_on'] for n in api.plans[0]['nodes']}
    assert deps['model.p.d'] == ['model.p.v', 'model.p.fct']  # fct is incremental: the walk stops there, its own stamps cover its sources


def test_summary_line_carries_the_disagreement_count(tmp_path):
    """The service answers a report with the disagreements it found; the run log shows that number, not just the counts
    the client knew before reporting."""
    code, dbt, api, provider, out, err = _run(tmp_path, ['build'], api=FakeApi(disagreements=2))
    assert code == 0 and 'disagreements 2' in out and 'bnr state explain pl_1' in out
