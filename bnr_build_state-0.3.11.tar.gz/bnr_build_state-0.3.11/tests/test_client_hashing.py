import pytest

from bnr_build_state.hashing import analyze, raw_sha256


def test_whitespace_comments_and_identifier_case_do_not_change_hash():
    a = analyze('SELECT  id, Name FROM D.S.T -- trailing\n', 'snowflake')
    b = analyze('select id,\n  name\nfrom d.s.t /* block */', 'snowflake')
    assert a.parsed and b.parsed and a.sha256 == b.sha256


def test_quoted_identifiers_keep_case():
    a = analyze('select "Name" from t', 'snowflake')
    b = analyze('select "name" from t', 'snowflake')
    assert a.sha256 != b.sha256


def test_logic_change_changes_hash():
    assert analyze('select id from t', 'snowflake').sha256 != analyze('select id from t where id > 1', 'snowflake').sha256


def test_unparseable_sql_hashes_raw_text():
    sql = 'select ((( from'
    facts = analyze(sql, 'snowflake')
    assert not facts.parsed and facts.sha256 == raw_sha256(sql)
    assert analyze('select  ((( from', 'snowflake').sha256 != facts.sha256  # unparsed SQL is hashed exactly


def test_unparsed_literal_whitespace_is_significant():
    assert raw_sha256("select 'a  b' ((( ") != raw_sha256("select 'a b' ((( ")


def test_select_star_detection_ignores_count_star():
    assert analyze('select * from t', 'snowflake').select_star
    assert analyze('select a.* from t a', 'snowflake').select_star
    assert not analyze('select count(*) from t', 'snowflake').select_star
    assert not analyze('select id from t', 'snowflake').select_star



STAR_OVER_RELATION = [
    'with a as (select * from db.s.t) select * from a',  # import CTE stars a relation
    'with final as (select id from db.s.t) select * from final union all select * from db.s.u',
    'with a as (select id from db.s.t) select * from a join db.s.u on a.id = u.id',
    'with a as (select id from db.s.t) select u.* from a join db.s.u on a.id = u.id',
    'select * exclude (id) from db.s.t',
    'select * from db.s.t, lateral flatten(input => t.v)',
    'select * from table(flatten(input => parse_json(1)))',  # table function: shape not modelled
    'with t as (select id from db.s.t) select * from (select * from t, db.s.u)',
    'with "final" as (select id from db.s.t) select * from final',  # Snowflake reads table FINAL, not the CTE
]
STAR_OVER_OWN_QUERIES = [
    'with source as (select id, name from db.s.t), final as (select id from source) select * from final',
    'select * from (select id from db.s.t)',
    'with a as (select id from db.s.t) select a.* from a join db.s.u on a.id = u.id',  # a.* expands the CTE only
    'with recursive r as (select 1 as n union all select n + 1 from r where n < 3) select * from r',
    'select * from values (1), (2)',
    'with t as (select id from db.s.t) select * from (with t2 as (select id from t) select * from t2)',
    'with final as (select id from db.s.t) select * from FINAL',
]


@pytest.mark.parametrize('sql', STAR_OVER_RELATION)
def test_star_expanding_a_relation_is_flagged(sql):
    assert analyze(sql, 'snowflake').select_star


@pytest.mark.parametrize('sql', STAR_OVER_OWN_QUERIES)
def test_star_over_the_statements_own_ctes_and_subqueries_is_not_flagged(sql):
    assert not analyze(sql, 'snowflake').select_star


def test_multi_statement_sql_hashes_all_statements():
    one = analyze('create temp table x as select 1; select * from x', 'postgres')
    two = analyze('create temp table x as select 1; select 2 from x', 'postgres')
    assert one.parsed and one.sha256 != two.sha256


def test_dialects_are_accepted():
    for dialect in ('snowflake', 'postgres', 'duckdb'):
        assert analyze('select 1', dialect).parsed


def test_unknown_dialect_raises():
    with pytest.raises(ValueError, match='nosuchdialect'):
        analyze('select 1', 'nosuchdialect')


def test_command_fallback_is_unparsed():
    facts = analyze("ALTER WAREHOUSE w SET WAREHOUSE_SIZE = 'XSMALL'", 'snowflake')
    assert facts.parsed is False


@pytest.mark.parametrize('sql', [
    'select dateadd(month, -12, current_date) as cutoff, id from db.s.t',  # period flags move with the calendar
    'select id, current_timestamp() as loaded_at from db.s.t',
    'select id from db.s.t where d >= CURRENT_DATE',  # no parentheses: parsed as a column in Snowflake
    'select sysdate() as now_utc', 'select getdate()', 'select localtimestamp', 'select random() as r',
    'select uuid_string() as k from db.s.t', 'select seq4() as n from db.s.t', 'select current_role() as who',
    'select last_query_id()', 'select uniform(1, 10, random())',
    'merge into db.s.t using (select current_date as d) s on 1 = 1 when matched then update set d = s.d',
])
def test_clock_random_and_session_functions_are_volatile(sql):
    assert analyze(sql, 'snowflake').volatile


@pytest.mark.parametrize('sql', [
    'select id, current_date_x from db.s.t',  # a column named like one
    'select id from db.s.t where d < "current_date"',  # a quoted column
    "select id, 'current_date' as label from db.s.t",  # a string
    'select date_trunc(month, d) as m from db.s.t', 'select * from db.s.t',
])
def test_plain_sql_is_not_volatile(sql):
    assert not analyze(sql, 'snowflake').volatile


def test_unparsed_sql_is_scanned_for_volatile_functions():
    facts = analyze("ALTER WAREHOUSE w SET WAREHOUSE_SIZE = 'XSMALL'", 'snowflake')
    assert not facts.parsed and not facts.volatile
    facts = analyze("ALTER WAREHOUSE w SET COMMENT = 'x'; insert into t select current_date", 'snowflake')
    assert not facts.parsed and facts.volatile


def test_unordered_aggregates_are_detected_only_when_no_order_is_given():
    from bnr_build_state.hashing import analyze
    assert analyze('select any_value(x) from t', 'snowflake').unordered is True
    assert analyze('select listagg(x) from t group by y', 'snowflake').unordered is True
    assert analyze('select array_agg(x) from t', 'snowflake').unordered is True
    assert analyze('select listagg(x) within group (order by x) from t', 'snowflake').unordered is False
    assert analyze('select array_agg(x order by x) from t', 'snowflake').unordered is False
    assert analyze('select min(x), count(*) from t', 'snowflake').unordered is False
    assert analyze('copy into t from @s; select any_value(x) from t', 'snowflake').unordered is True  # text fallback when unparsed

