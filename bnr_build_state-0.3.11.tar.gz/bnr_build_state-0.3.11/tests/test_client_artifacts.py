import json
from pathlib import Path

import pytest

from bnr_build_state import artifacts as a
from client_fixtures import MANIFEST, RUN_RESULTS, SELECTED, SRC_A, SRC_B, SRC_C, run_results, write_project

ENGINE_FIXTURES = Path(__file__).resolve().parents[3] / 'packages/engine/tests/fixtures'


def test_selected_ids_follow_run_results_order():
    assert a.selected_ids(RUN_RESULTS) == SELECTED


def test_engine_of_detects_fusion_by_major_version():
    assert a.engine_of(run_results({}, version='2.0.0')) == dict(family='fusion', version='2.0.0')
    assert a.engine_of(run_results({}, version='1.12.5')) == dict(family='core', version='1.12.5')


def test_project_name_and_target_dir(tmp_path, monkeypatch):
    write_project(tmp_path)
    assert a.project_name(tmp_path) == 'p'
    assert a.target_dir(tmp_path, None, {}) == tmp_path / 'target'
    assert a.target_dir(tmp_path, 'out', {}) == tmp_path / 'out'
    assert a.target_dir(tmp_path, None, {'DBT_TARGET_PATH': 'envout'}) == tmp_path / 'envout'


def test_target_dir_honours_project_target_path(tmp_path):
    (tmp_path / 'dbt_project.yml').write_text('name: p\ntarget-path: out\n')
    assert a.target_dir(tmp_path, None, {}) == tmp_path / 'out'
    assert a.target_dir(tmp_path, 'cli', {}) == tmp_path / 'cli'
    assert a.target_dir(tmp_path, None, {'DBT_TARGET_PATH': 'envout'}) == tmp_path / 'envout'


def test_compiled_sql_prefers_manifest_then_compiled_file(tmp_path):
    write_project(tmp_path)
    target = tmp_path / 'target'
    assert a.compiled_sql(MANIFEST['nodes']['model.p.fct'], target, 'p') == 'select id from D.S.stg'
    assert a.compiled_sql(MANIFEST['nodes']['model.p.nosql'], target, 'p') == 'select 3'
    assert a.compiled_sql(MANIFEST['nodes']['model.p.py'], target, 'p') is None


def test_node_flags():
    n = MANIFEST['nodes']
    assert a.node_flags(n['model.p.hooked']) == ('has_hooks',)
    assert a.node_flags(n['model.p.py']) == ('python',)
    assert a.node_flags(n['snapshot.p.snap']) == ('snapshot',)
    assert a.node_flags(n['model.p.stg']) == ()
    custom = dict(n['model.p.stg'], config={'materialized': 'my_mat', 'pre-hook': [], 'post-hook': []})
    assert a.node_flags(custom) == ('custom_materialization',)
    sv = dict(n['model.p.stg'], config={'materialized': 'semantic_view', 'pre-hook': [], 'post-hook': []})
    assert a.node_flags(sv) == ('semantic_view',)


def test_relation_of_uses_relation_name_and_alias():
    rel = a.relation_of(MANIFEST['nodes']['model.p.fct'])
    assert rel == a.Relation('D', 'S', 'fct', 'D.S.fct')
    assert a.relation_of(MANIFEST['nodes']['model.p.eph']) is None


def test_facts_cover_every_selected_node(tmp_path):
    write_project(tmp_path)
    facts = a.facts(MANIFEST, SELECTED, tmp_path / 'target', 'p')
    by_id = {f.unique_id: f for f in facts}
    assert list(by_id) == SELECTED
    assert by_id['model.p.fct'].depends_on == ('model.p.stg', SRC_B)
    assert by_id['seed.p.countries'].sql is None and by_id['seed.p.countries'].checksum == 'c0ffee'
    assert by_id['model.p.nosql'].sql == 'select 3'
    assert by_id['test.p.not_null_fct_id'].relation is None
    assert by_id['model.p.hooked'].flags == ('has_hooks',)


def test_facts_skips_unknown_ids(tmp_path):
    write_project(tmp_path)
    assert [f.unique_id for f in a.facts(MANIFEST, ['model.p.stg', 'model.p.missing'], tmp_path / 'target', 'p')] == ['model.p.stg']


def test_sources_for_collects_only_referenced_sources(tmp_path):
    write_project(tmp_path)
    facts = a.facts(MANIFEST, ['model.p.stg', 'model.p.fct'], tmp_path / 'target', 'p')
    assert set(a.sources_for(MANIFEST, facts)) == {SRC_A, SRC_B}


def test_loaded_at_order_query_then_field_then_none():
    s = MANIFEST['sources']
    assert a.loaded_at(s[SRC_A]) == ('loaded_at_field', 'select max(_load_ts) from D.RAW.A')
    assert a.loaded_at(s[SRC_B]) == ('loaded_at_query', 'select max(ts) from D.RAW.B')
    assert a.loaded_at(s[SRC_C]) is None


def test_target_schemas_from_materialized_nodes(tmp_path):
    write_project(tmp_path)
    facts = a.facts(MANIFEST, SELECTED, tmp_path / 'target', 'p')
    assert a.target_schemas(facts) == {('D', 'S')}


@pytest.mark.parametrize('engine', ['core-1.11.1', 'fusion-2.0.0-preview.186'])
def test_real_engine_artifacts_parse(engine):
    target = ENGINE_FIXTURES / engine
    if not target.exists():
        pytest.skip('engine fixtures absent')
    manifest = a.load_json(target / 'manifest.json')
    results = a.load_json(target / 'run_results.json')
    ids = a.selected_ids(results)
    facts = a.facts(manifest, ids, target, manifest['metadata'].get('project_name') or 'p')
    assert facts and all(f.sql for f in facts if f.resource_type == 'model')
    assert a.engine_of(results)['family'] == ('fusion' if engine.startswith('fusion') else 'core')


def test_config_sha256_follows_dbt_state_modified_configs():
    # dbt's state:modified.configs compares unrendered_config minus alias/schema/database/tags/group (and meta, per the
    # docs); the materialization is the planner's own rule and hooks already force a build, so they stay out too.
    fct = MANIFEST['nodes']['model.p.fct']
    base = a.config_sha256(fct)
    assert base and len(base) == 64

    def with_(**changes):
        return a.config_sha256(dict(fct, unrendered_config={**fct['unrendered_config'], **changes}))
    assert with_(tags=['other'], schema='elsewhere', alias='FCT', database='X', group='g', meta={'owner': 'y'},
                 materialized='table', docs={'show': False}, enabled=True, bnr_state={'lag_tolerance_seconds': 5}) == base
    assert with_(**{'pre-hook': ['insert 1']}) == base
    assert with_(unique_key=['id', 'day']) != base and with_(on_schema_change='fail') != base
    assert with_(incremental_strategy='merge') != base and with_(cluster_by=['day']) != base and with_(transient=False) != base
    assert a.config_sha256(dict(fct, unrendered_config={'materialized': 'incremental', 'on_schema_change': 'append_new_columns',
                                                         'unique_key': 'id'})) == base  # key order does not matter
    assert a.config_sha256({k: v for k, v in fct.items() if k != 'unrendered_config'}) is None
    assert a.config_sha256(dict(fct, unrendered_config=None)) is None


def test_facts_carry_config_sha256(tmp_path):
    write_project(tmp_path)
    by_id = {f.unique_id: f for f in a.facts(MANIFEST, SELECTED, tmp_path / 'target', 'p')}
    assert by_id['model.p.fct'].config_sha256 == a.config_sha256(MANIFEST['nodes']['model.p.fct'])
    assert by_id['seed.p.countries'].config_sha256 is not None


def test_seed_checksum_only_carried_when_sha256(tmp_path):
    import copy
    write_project(tmp_path)
    manifest = copy.deepcopy(MANIFEST)
    manifest['nodes']['seed.p.countries']['checksum'] = dict(name='path', checksum='seeds/big.csv')
    assert {f.unique_id: f for f in a.facts(manifest, SELECTED, tmp_path / 'target', 'p')}['seed.p.countries'].checksum is None
    del manifest['nodes']['seed.p.countries']['checksum']
    assert {f.unique_id: f for f in a.facts(manifest, SELECTED, tmp_path / 'target', 'p')}['seed.p.countries'].checksum is None


def _fact(uid, materialized, deps, sql='select 1'):
    return a.NodeFacts(uid, uid.rsplit('.', 1)[-1], 'model', materialized, tuple(deps), sql, None, (), None)


def test_inline_ephemerals_splices_their_dependencies_into_readers_through_chains():
    e1 = _fact('model.p.e1', 'ephemeral', [SRC_A, 'model.p.e2'])
    e2 = _fact('model.p.e2', 'ephemeral', [SRC_B, 'model.p.tbl'])
    reader = _fact('model.p.rd', 'table', ['model.p.e1', SRC_C])
    other = _fact('model.p.other', 'table', ['model.p.tbl'])
    facts, folded = a.inline_ephemerals([e1, e2, reader, other])
    assert [f.unique_id for f in facts] == ['model.p.rd', 'model.p.other']
    assert facts[0].depends_on == (SRC_A, SRC_B, 'model.p.tbl', SRC_C)
    assert sorted(e.unique_id for e in folded['model.p.rd']) == ['model.p.e1', 'model.p.e2'] and 'model.p.other' not in folded
    # A selection with no ephemeral is returned as is.
    assert a.inline_ephemerals([other]) == ([other], {})
    # A cycle between ephemerals (impossible in dbt, defensive) terminates.
    loop_a = _fact('model.p.la', 'ephemeral', ['model.p.lb']); loop_b = _fact('model.p.lb', 'ephemeral', ['model.p.la', SRC_A])
    facts, folded = a.inline_ephemerals([loop_a, loop_b, _fact('model.p.r2', 'table', ['model.p.la'])])
    assert facts[0].depends_on == (SRC_A,) and len(folded['model.p.r2']) == 2


def test_loaded_at_reads_the_config_block_and_prefers_the_query():
    assert a.loaded_at({'config': {'loaded_at_field': 'ts'}, 'relation_name': 'R'}) == ('loaded_at_field', 'select max(ts) from R')
    assert a.loaded_at({'loaded_at_field': 'ts', 'config': {'loaded_at_query': 'select 1'}, 'relation_name': 'R'}) == ('loaded_at_query', 'select 1')
    assert a.loaded_at({'config': {}, 'relation_name': 'R'}) is None


def test_loaded_at_query_renders_source_refs_from_the_manifest(caplog):
    manifest = dict(sources={'source.p.jira.PROJECTS': dict(source_name='jira', name='PROJECTS', relation_name='RAW_PRD.JIRA.PROJECTS')})
    child = dict(unique_id='source.p.jira.PROJECTS__ISSUE_TYPES', relation_name='RAW_PRD.JIRA.PROJECTS__ISSUE_TYPES',
                 loaded_at_field='_load_ts', config={'loaded_at_query': "select max(_load_ts) from {{ source('jira', 'PROJECTS') }}"})
    assert a.loaded_at(child, manifest) == ('loaded_at_query', 'select max(_load_ts) from RAW_PRD.JIRA.PROJECTS')
    # Anything else that needs Jinja cannot be rendered here: the declaration is dropped (not the field, which dbt
    # would also ignore when a query is set) and the stamp falls back to the provider's.
    with caplog.at_level('WARNING', logger='bnr_build_state'):
        assert a.loaded_at(dict(child, config={'loaded_at_query': "select max(ts) from {{ var('x') }}"}), manifest) is None
    assert any('cannot render the loaded_at_query' in r.getMessage() for r in caplog.records)
    assert a.loaded_at(dict(child, config={'loaded_at_query': "select max(ts) from {{ source('jira', 'MISSING') }}"}), manifest) is None


def test_run_started_at_comes_from_the_manifest_or_run_results_metadata():
    fusion = dict(metadata=dict(invocation_started_at='2026-11-08T04:02:16.075569179Z'))
    core = dict(metadata=dict(invocation_started_at='2026-11-05T23:50:52.450076Z'))
    assert a.run_started_at(fusion).isoformat() == '2026-11-08T04:02:16'
    assert a.run_started_at({}, core).isoformat() == '2026-11-05T23:50:52'
    assert a.run_started_at({}, {}) is None and a.run_started_at(dict(metadata=dict(invocation_started_at='soon'))) is None


def test_run_timestamp_literals_are_neutralized_and_flagged():
    started = a.run_started_at(dict(metadata=dict(invocation_started_at='2026-11-08T04:02:16.075569179Z')))
    stg = _fact('model.p.stg', 'view', [SRC_A], "select id, TO_TIMESTAMP('2026-11-08 04:02:16.075569') AS LOAD_DATETIME from D.RAW.A")
    snap = _fact('snapshot.p.psa', 'snapshot', [SRC_A], "select *, '2026-11-08T04:02:16.075569+00:00' as psa_loaded_at from D.RAW.A")
    plain = _fact('model.p.fct', 'table', [SRC_A], "select id from D.RAW.A where d > '2026-11-08 04:02:15'")
    out = a.neutralize_run_timestamps([stg, snap, plain], started)
    assert out[0].sql == f"select id, TO_TIMESTAMP('{a.RUN_TIMESTAMP_TOKEN}') AS LOAD_DATETIME from D.RAW.A" and out[0].flags == ('run_timestamp',)
    assert out[1].sql == f"select *, '{a.RUN_TIMESTAMP_TOKEN}' as psa_loaded_at from D.RAW.A" and 'run_timestamp' in out[1].flags
    assert out[2] is plain  # a different instant is a real literal
    # Two runs of the same template hash the same.
    later = a.run_started_at(dict(metadata=dict(invocation_started_at='2026-11-09T04:17:00.000001Z')))
    stg2 = _fact('model.p.stg', 'view', [SRC_A], "select id, TO_TIMESTAMP('2026-11-09 04:17:00.000001') AS LOAD_DATETIME from D.RAW.A")
    assert a.neutralize_run_timestamps([stg2], later)[0].sql == out[0].sql
    assert a.neutralize_run_timestamps([stg], None) == [stg]


def test_bnr_state_is_read_from_config_or_meta():
    assert a.bnr_state({'config': {'bnr_state': {'volatile': False}}}) == {'volatile': False}
    assert a.bnr_state({'config': {'meta': {'bnr_state': {'always_build': True}}}}) == {'always_build': True}  # Fusion-safe form
    assert a.bnr_state({'config': {}, 'meta': {'bnr_state': {'lag_tolerance_seconds': 60}}}) == {'lag_tolerance_seconds': 60}
    assert a.bnr_state({'config': {'bnr_state': {'volatile': True}, 'meta': {'bnr_state': {'volatile': False}}}}) == {'volatile': True}
    assert a.bnr_state({'config': {'bnr_state': 'yes', 'meta': {'bnr_state': ['x']}}}) == {}


def test_readers_of_selected_views_inherit_the_views_dependencies():
    t = _fact('model.p.t', 'table', [SRC_A])
    v = _fact('model.p.v', 'view', ['model.p.t'])
    v2 = _fact('model.p.v2', 'view', ['model.p.v', SRC_B])
    d = _fact('model.p.d', 'table', ['model.p.v2'])
    other = _fact('model.p.o', 'table', ['model.p.t'])
    out = {f.unique_id: f for f in a.expand_through_views([t, v, v2, d, other])}
    # The views stay and their parents join; a table parent ends the walk (its own stamps and builds cover its sources).
    assert out['model.p.d'].depends_on == ('model.p.v2', 'model.p.v', 'model.p.t', SRC_B)
    assert out['model.p.v2'].depends_on == ('model.p.v', SRC_B, 'model.p.t')
    assert out['model.p.o'] is other and out['model.p.t'] is t  # a table parent is not read through
    looped = a.expand_through_views([_fact('model.p.x', 'view', ['model.p.y']), _fact('model.p.y', 'view', ['model.p.x', SRC_A])])
    assert SRC_A in looped[0].depends_on  # a cycle between views (impossible in dbt, defensive) terminates
