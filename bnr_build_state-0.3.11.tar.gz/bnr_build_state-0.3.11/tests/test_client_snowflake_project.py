import io
import json
import re
from pathlib import Path

import pytest

from bnr_build_state.providers import snowflake_project as sp
from client_fixtures import MANIFEST, SELECTED, run_results
from test_client_runner import ENV, FakeApi, FakeLoadedAt, FakeProvider

PROJECT = 'DB.DBT_PROJECTS.P'


class FakeSnowflake:
    """A Snowflake connection running a dbt project object: each EXECUTE writes that query's artifacts to a stage."""

    account = 'acme-xy12345'

    def __init__(self, *, fail=(), timezone=('America/Chicago', 'SESSION'), manifest=MANIFEST):
        self.sql, self.stage, self.logs, self.fail = [], {}, {}, set(fail)
        self.manifest = manifest
        self.timezone = timezone
        self.next_id = 0

    def cursor(self):
        return FakeCursor(self)

    def run(self, cursor, sql):
        self.sql.append(sql)
        match = re.fullmatch(r"execute dbt project (\S+) args='(.*)'(?: writeback=\w+)?", sql, re.S)
        if match:
            self.next_id += 1
            cursor.sfqid = f'q{self.next_id}'
            args = match.group(2).replace("''", "'").split()
            command = args[0]
            folder = self.stage.setdefault(cursor.sfqid, {})
            if command == 'list':
                self.logs[cursor.sfqid] = '\n'.join(
                    ['05:05:35.1 [info ]: Running with dbt=2.0.0'] +
                    [f'05:05:35.2 [info ]: {json.dumps(dict(unique_id=u, resource_type=u.split(".")[0]))}' for u in SELECTED])
            else:
                folder['manifest.json'] = json.dumps(self.manifest)
                gone = self.excluded(args)  # planning.exclusions_for writes `path:<original_file_path>`
                statuses = {} if command == 'compile' else {
                    u: 'success' for u in SELECTED if 'path:' + MANIFEST['nodes'][u]['original_file_path'] not in gone}
                folder['run_results.json'] = json.dumps(run_results(statuses, version='2.0.0', which=command))
            if command in self.fail:
                raise RuntimeError(f'dbt {command} failed')
            return []
        if sql.startswith('select system$locate_dbt_artifacts'):
            qid = re.search(r"'(q\d+)'", sql).group(1)
            return [(f'snow://dbt/{PROJECT}/results/query_id_{qid}/',)]
        if sql.startswith('select system$get_dbt_log'):
            return [(self.logs.get(re.search(r"'(q\d+)'", sql).group(1), ''),)]
        if sql.startswith('get '):
            qid, name, local = re.fullmatch(r"get 'snow://dbt/\S+/query_id_(q\d+)/target/(\S+)' 'file://(\S+)/'", sql).groups()
            if name not in self.stage.get(qid, {}):
                raise RuntimeError('file not found')
            Path(local, name).write_text(self.stage[qid][name])
            return []
        if sql.startswith('show parameters'):
            cursor.description = [('key',), ('value',), ('default',), ('level',)]
            return [('TIMEZONE', self.timezone[0], 'America/Los_Angeles', self.timezone[1])]
        return []

    @staticmethod
    def excluded(args):
        return {a for i, a in enumerate(args) if i and args[i - 1] == '--exclude'} | {
            a for i, a in enumerate(args) if '--exclude' in args[:i] and not a.startswith('-')}


class FakeCursor:
    def __init__(self, conn):
        self.conn, self.sfqid, self.rows, self.description = conn, None, [], None

    def execute(self, sql, timeout=None):
        if sql.startswith('execute dbt project'):
            assert timeout is None  # dbt's own run is never cut short by bnr's metadata ceiling
        self.rows = self.conn.run(self, sql)

    def fetchone(self):
        return self.rows[0] if self.rows else None

    def fetchall(self):
        return list(self.rows)

    def close(self):
        pass


def _run(args, *, mode='shadow', skip=(), conn=None, fake_provider=True, **kwargs):
    conn = conn or FakeSnowflake()
    api = FakeApi(mode=mode, skip=skip)
    out, err = io.StringIO(), io.StringIO()
    if fake_provider:
        kwargs['provider_factory'] = lambda profile: FakeProvider()
    code = sp.run_project(args, ENV, conn, PROJECT, database='D', schema='S', warehouse='W',
                          api_factory=lambda url, token: api, out=out, err=err, loaded_at=FakeLoadedAt(), **kwargs)
    return code, conn, api, out.getvalue(), err.getvalue()


def _executed(conn):
    return [re.fullmatch(r"execute dbt project \S+ args='(.*)'(?: writeback=\w+)?", s, re.S).group(1) for s in conn.sql if s.startswith('execute dbt')]


def test_shadow_plans_from_the_objects_artifacts_and_reports_its_run_results():
    code, conn, api, out, _ = _run('build --select tag:x')
    assert code == 0
    # Fusion compile run_results carry no results, so the selection comes from the list step's log.
    assert _executed(conn) == ['compile --select tag:x', 'list --select tag:x --output json --output-keys unique_id',
                               'build --select tag:x']
    body = api.plans[0]
    assert body['project'] == 'p'  # from the manifest: there is no local dbt_project.yml
    assert (body['target']['database'], body['target']['schema']) == ('D', 'S')
    assert {n['unique_id'] for n in body['nodes']} == set(SELECTED) - {'model.p.eph'}
    assert len(api.reports[0]['results']) == len(SELECTED)
    assert 'mode shadow' in out
    assert body['invocation']['client']['executor'] == 'snowflake_project'


def test_enforce_excludes_skipped_nodes_in_the_object_build():
    code, conn, api, _, _ = _run('build --select tag:x', mode='enforce', skip=['model.p.fct', 'test.p.not_null_fct_id'])
    assert code == 0
    build = _executed(conn)[2]
    assert build.startswith('build --select tag:x --exclude ') and 'fct' in build
    assert {r['unique_id'] for r in api.reports[0]['results'] if r['status'] == 'reused'} >= {'model.p.fct'}


def test_failed_build_returns_1_and_still_reports_the_objects_run_results():
    code, conn, api, _, err = _run('build', conn=FakeSnowflake(fail={'build'}))
    assert code == 1
    assert api.reports and len(api.reports[0]['results']) == len(SELECTED)
    assert 'EXECUTE DBT PROJECT' in err


def test_failed_compile_runs_the_original_build():
    code, conn, api, _, _ = _run('build', conn=FakeSnowflake(fail={'compile'}))
    assert code == 0 and not api.plans
    assert _executed(conn) == ['compile', 'build']


def test_step_without_artifacts_leaves_none_behind(tmp_path):
    conn = FakeSnowflake()
    dbt = sp.ProjectDbt(conn, PROJECT, tmp_path / 'target')
    dbt(['dbt', 'compile'])
    assert (tmp_path / 'target' / 'manifest.json').exists()
    dbt(['dbt', 'build'])
    assert (tmp_path / 'target' / 'run_results.json').exists()
    assert not (tmp_path / 'target' / 'manifest.json').exists()  # only compile's manifest is read
    conn.stage.clear()
    conn.run = (lambda original: lambda cursor, sql: (original(cursor, sql), conn.stage.clear())[0])(conn.run)
    dbt(['dbt', 'build'])
    assert not (tmp_path / 'target' / 'run_results.json').exists()


def test_args_text_quotes_whitespace_and_refuses_double_quotes():
    assert sp.args_text(['build', '--vars', '{a: 1}', '--select', 'x']) == 'build --vars "{a: 1}" --select x'
    with pytest.raises(ValueError):
        sp.args_text(['--vars', '{"a": 1}'])


@pytest.mark.parametrize('args', ['build --project-dir x', 'build --vars \'{"a": 1}\''])
def test_unplannable_args_run_exactly_as_given(args):
    code, conn, api, _, err = _run(args)
    assert code == 0 and not api.plans
    assert [s for s in conn.sql if s.startswith('execute')] == [f"execute dbt project {PROJECT} args={sp._lit(args)}"]
    assert 'not planned' in err


def test_real_provider_restores_the_callers_timezone_before_the_build_and_keys_on_the_locator():
    code, conn, api, _, _ = _run('build --select tag:x', fake_provider=False, locator='AGMHFEM-GZC16882')
    assert code == 0
    utc = conn.sql.index("alter session set timezone = 'UTC'")
    restore = conn.sql.index("alter session set timezone = 'America/Chicago'", utc)
    build = next(i for i, s in enumerate(conn.sql) if s.startswith('execute dbt project') and "args='build" in s)
    assert utc < restore < build
    assert api.plans[0]['target']['locator'] == 'AGMHFEM-GZC16882'


def test_unreadable_session_timezone_leaves_the_session_alone():
    conn = FakeSnowflake()
    conn.run = (lambda original: lambda cursor, sql: (_ for _ in ()).throw(RuntimeError('no')) if sql.startswith('show parameters')
                else original(cursor, sql))(conn.run)
    _run('build', conn=conn, fake_provider=False)
    assert not any('timezone' in s for s in conn.sql if s.startswith('alter session'))


def test_a_selector_value_named_like_a_command_is_not_the_command():
    assert sp._command_index(['--select', 'ls', 'build']) == 2
    assert sp._command_index(['--log-level', 'warn', 'ls', '--select', 'x']) == 2


def test_failed_step_prints_the_tail_of_dbts_log():
    conn = FakeSnowflake(fail={'build'})
    conn.logs_for_failure = True
    original = conn.run

    def run(cursor, sql):
        if sql.startswith('select system$get_dbt_log'):
            return [('\n'.join(f'line {i}' for i in range(80)),)]
        return original(cursor, sql)
    conn.run = run
    code, _, _, _, err = _run('build', conn=conn)
    assert code == 1 and 'line 79' in err and 'line 29' not in err


def test_truncated_list_log_falls_back_to_the_original_build():
    conn = FakeSnowflake()
    original = conn.run

    def run(cursor, sql):
        if sql.startswith('select system$get_dbt_log'):
            return [('x' * sp.LOG_LIMIT,)]
        return original(cursor, sql)
    conn.run = run
    code, conn, api, _, err = _run('build', conn=conn)
    assert code == 0 and not api.plans
    assert 'could not be read whole' in err and 'dbt ls exited 1' in err


def test_list_nodes_parses_prefixed_log_lines():
    text = '05:05:35 [info ]: Running\n05:05:36 [info ]: {"unique_id": "model.p.a"}\n05:05:37 [info ]: {"unique_id": broken'
    assert sp.list_nodes(text) == '{"unique_id": "model.p.a"}\n'


@pytest.mark.parametrize('timezone, restore', [(('America/Chicago', 'SESSION'), "alter session set timezone = 'America/Chicago'"),
                                               (('America/Los_Angeles', ''), 'alter session unset timezone')])
def test_borrowed_connection_restores_the_session_timezone_and_stays_open(timezone, restore):
    conn = FakeSnowflake(timezone=timezone)
    borrowed = sp._Borrowed(conn)
    borrowed.execute("alter session set timezone = 'UTC'")
    borrowed.close()
    assert conn.sql[-1] == restore


def test_default_selector_in_the_objects_manifest_keeps_enforce_in_shadow():
    """No local selectors.yml exists here; --exclude would replace the default selector and build everything else."""
    manifest = dict(MANIFEST, selectors={'nightly': dict(name='nightly', default=True, definition='tag:x')})
    code, conn, api, _, err = _run('build', mode='enforce', skip=['model.p.fct'], conn=FakeSnowflake(manifest=manifest))
    assert code == 0
    assert _executed(conn)[-1] == 'build'
    assert 'planning in Shadow' in err


def test_steps_report_every_execute_with_its_query_id():
    steps = []
    code, conn, _, _, _ = _run('build --select tag:x', steps=steps)
    assert code == 0
    assert [(s['command'], s['ok']) for s in steps] == [('compile', True), ('list', True), ('build', True)]
    assert all(s['query_id'] for s in steps) and steps[-1]['args'] == 'build --select tag:x'


def test_steps_record_a_failed_build_and_the_unplanned_fallback():
    steps = []
    _run('build', conn=FakeSnowflake(fail={'build'}), steps=steps)
    assert steps[-1]['command'] == 'build' and steps[-1]['ok'] is False and 'failed' in steps[-1]['error']
    steps = []
    _run("build --vars '{\"a\": 1}'", steps=steps)
    assert [s['command'] for s in steps] == ['build']


def _writebacks(conn):
    return [(re.search(r"args='(\w+)", s).group(1), (re.search(r" writeback=(\w+)$", s) or [None, None])[1])
            for s in conn.sql if s.startswith('execute dbt')]


def test_planning_steps_never_write_back_and_the_build_follows_the_caller():
    _, conn, _, _, _ = _run('build --select tag:x')
    assert _writebacks(conn) == [('compile', 'false'), ('list', 'false'), ('build', None)]
    _, conn, _, _, _ = _run('build --select tag:x', writeback=False)
    assert _writebacks(conn) == [('compile', 'false'), ('list', 'false'), ('build', 'false')]
    _, conn, _, _, _ = _run("build --vars '{\"a\": 1}'", writeback=False)  # unplanned: ARGS as given
    assert _writebacks(conn) == [('build', 'false')]
