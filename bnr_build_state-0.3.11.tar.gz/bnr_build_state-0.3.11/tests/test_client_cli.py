import io

from bnr_build_state import cli


def test_dbt_subcommand_dispatches_to_runner(monkeypatch):
    seen = {}
    monkeypatch.setattr(cli.runner, 'run', lambda argv, env, **kw: seen.setdefault('argv', argv) and 7)
    assert cli.main(['dbt', 'build', '-s', 'x']) == 7 and seen['argv'] == ['build', '-s', 'x']


def test_state_explain_dispatches_with_node_filter(monkeypatch):
    seen = {}
    monkeypatch.setattr(cli.runner, 'explain', lambda plan_id, env, node=None, **kw: seen.update(plan_id=plan_id, node=node) or 0)
    assert cli.main(['state', 'explain', 'pl_1', '-s', 'fct']) == 0 and seen == dict(plan_id='pl_1', node='fct')


def test_usage_on_unknown_command(capsys):
    assert cli.main(['frobnicate']) == 2
    assert 'usage' in capsys.readouterr().err.lower()
    assert cli.main([]) == 2
