"""Hand-built dbt artifacts covering models, a seed, a snapshot, tests, sources and hooks."""
import json
from pathlib import Path

SRC_A = 'source.p.raw.a'
SRC_B = 'source.p.raw.b'
SRC_C = 'source.p.raw.c'


def _node(uid, resource_type, name, *, materialized=None, deps=(), compiled='select 1', database='D', schema='S',
          relation=True, hooks=False, language='sql', checksum=None, original=None, unrendered=None):
    original = original or f'models/{name}.sql'
    node = dict(unique_id=uid, name=name, resource_type=resource_type, database=database, schema=schema, alias=name, fqn=['p', name],
                original_file_path=original, path=original.split('/', 1)[-1], language=language,
                depends_on=dict(macros=[], nodes=list(deps)),
                config={'materialized': materialized, 'pre-hook': (['insert 1'] if hooks else []), 'post-hook': []},
                unrendered_config=unrendered if unrendered is not None else {'materialized': materialized},
                relation_name=(f'{database}.{schema}.{name}' if relation else None))
    if compiled is not None:
        node['compiled_code'] = compiled
    if checksum:
        node['checksum'] = dict(name='sha256', checksum=checksum)
    return node


MANIFEST = dict(
    metadata=dict(dbt_schema_version='https://schemas.getdbt.com/dbt/manifest/v12.json', project_name='p', adapter_type='snowflake'),
    nodes={
        'model.p.stg': _node('model.p.stg', 'model', 'stg', materialized='view', deps=[SRC_A], checksum='stgsum'),
        'model.p.fct': _node('model.p.fct', 'model', 'fct', materialized='incremental', deps=['model.p.stg', SRC_B],
                             compiled='select id from D.S.stg',
                             unrendered={'materialized': 'incremental', 'unique_key': 'id', 'on_schema_change': 'append_new_columns',
                                         'tags': ['core'], 'schema': 'marts', 'meta': {'owner': 'x'}}),
        'model.p.hooked': _node('model.p.hooked', 'model', 'hooked', materialized='table', deps=['model.p.stg', SRC_C], hooks=True),
        'model.p.py': _node('model.p.py', 'model', 'py', materialized='table', deps=['model.p.stg'], compiled=None, language='python',
                            original='models/py.py'),
        'model.p.eph': _node('model.p.eph', 'model', 'eph', materialized='ephemeral', deps=[SRC_C], relation=False),
        'model.p.nosql': _node('model.p.nosql', 'model', 'nosql', materialized='table', deps=[], compiled=None, original='models/nosql.sql'),
        'seed.p.countries': _node('seed.p.countries', 'seed', 'countries', materialized='seed', compiled=None, checksum='c0ffee',
                                  original='seeds/countries.csv'),
        'snapshot.p.snap': _node('snapshot.p.snap', 'snapshot', 'snap', materialized='snapshot', deps=['model.p.stg'],
                                 compiled='select 2', original='snapshots/snap.sql'),
        'test.p.not_null_fct_id': _node('test.p.not_null_fct_id', 'test', 'not_null_fct_id', materialized='test',
                                        deps=['model.p.fct'], relation=False, original='models/schema.yml'),
        # Two parents: dbt's eager exclusion of either parent takes this test with it.
        'test.p.relationships_fct_stg': _node('test.p.relationships_fct_stg', 'test', 'relationships_fct_stg', materialized='test',
                                              deps=['model.p.fct', 'model.p.stg'], relation=False, original='models/schema.yml'),
    },
    sources={
        SRC_A: dict(unique_id=SRC_A, name='a', source_name='raw', database='D', schema='RAW', identifier='A',
                    relation_name='D.RAW.A', loaded_at_field='_load_ts', loaded_at_query=None),
        SRC_B: dict(unique_id=SRC_B, name='b', source_name='raw', database='D', schema='RAW', identifier='B',
                    relation_name='D.RAW.B', loaded_at_field=None, loaded_at_query='select max(ts) from D.RAW.B'),
        SRC_C: dict(unique_id=SRC_C, name='c', source_name='raw', database='D', schema='RAW', identifier='C',
                    relation_name='D.RAW.C', loaded_at_field=None, loaded_at_query=None),
    },
)

SELECTED = ['model.p.stg', 'model.p.fct', 'model.p.hooked', 'model.p.py', 'model.p.eph', 'model.p.nosql',
            'seed.p.countries', 'snapshot.p.snap', 'test.p.not_null_fct_id', 'test.p.relationships_fct_stg']


def run_results(statuses, *, version='1.12.5', which='build'):
    """statuses: dict unique_id -> dbt status string."""
    return dict(metadata=dict(dbt_version=version), args=dict(which=which),
                results=[dict(unique_id=uid, status=status, timing=[
                    dict(name='compile', started_at='2026-10-27T00:00:00Z', completed_at='2026-10-27T00:00:01Z'),
                    dict(name='execute', started_at='2026-10-27T00:00:01Z', completed_at='2026-10-27T00:00:02Z')])
                    for uid, status in statuses.items()])


RUN_RESULTS = run_results({uid: 'success' for uid in SELECTED})


def write_project(root: Path, *, manifest=MANIFEST, results=RUN_RESULTS, profile_type='snowflake'):
    """Write dbt_project.yml, profiles.yml, target/ artifacts and one compiled file (for model.p.nosql)."""
    root.mkdir(parents=True, exist_ok=True)
    (root / 'dbt_project.yml').write_text('name: p\nprofile: p\n')
    outputs = dict(snowflake=dict(type='snowflake', account='acme-xy12345', user='u', password="{{ env_var('PW') }}",
                                  database='D', schema='S', warehouse='W'),
                   postgres=dict(type='postgres', host='db.local', port=5432, user='u', password='x', dbname='D', schema='S'),
                   duckdb=dict(type='duckdb', path='/tmp/x.duckdb', schema='S'))[profile_type]
    (root / 'profiles.yml').write_text(json.dumps({'p': {'target': 'dev', 'outputs': {'dev': outputs}}}))
    target = root / 'target'
    target.mkdir(exist_ok=True)
    (target / 'manifest.json').write_text(json.dumps(manifest))
    (target / 'run_results.json').write_text(json.dumps(results))
    compiled = target / 'compiled' / 'p' / 'models'
    compiled.mkdir(parents=True, exist_ok=True)
    (compiled / 'nosql.sql').write_text('select 3')
    return root
