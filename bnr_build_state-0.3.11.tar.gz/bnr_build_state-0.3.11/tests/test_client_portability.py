"""Spec section 11: nothing outside providers/ names a warehouse or parses a stamp."""
from pathlib import Path
import re

SRC = Path(__file__).resolve().parents[1] / 'src' / 'bnr_build_state'
FORBIDDEN = re.compile(r'snowflake|psycopg|duckdb|SYSTEM\$|pg_stat|information_schema|datetime\.fromisoformat', re.I)


def test_only_providers_know_warehouses():
    offenders = []
    for path in SRC.rglob('*.py'):
        if 'providers' in path.parts:
            continue
        for number, line in enumerate(path.read_text().splitlines(), 1):
            if FORBIDDEN.search(line):
                offenders.append(f'{path.relative_to(SRC)}:{number}: {line.strip()}')
    assert not offenders, '\n'.join(offenders)
