import json

import pytest

from bnr_build_state.state_api import StateApi, StateUnavailable


class FakeTransport:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def __call__(self, method, url, headers, body, timeout):
        self.calls.append((method, url, headers, body, timeout))
        item = self.responses.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


def test_plan_posts_json_with_bearer_and_expects_201():
    transport = FakeTransport([(201, json.dumps(dict(plan_id='pl_1', mode='shadow', nodes=[], summary={})).encode())])
    api = StateApi('https://api.example.com/', 'tok', transport=transport)
    assert api.plan(dict(account_id=1))['plan_id'] == 'pl_1'
    method, url, headers, body, timeout = transport.calls[0]
    assert (method, url) == ('POST', 'https://api.example.com/v1/state/plan')
    assert headers['Authorization'] == 'Bearer tok' and headers['Content-Type'] == 'application/json'
    assert json.loads(body) == dict(account_id=1) and timeout == 30.0


def test_report_and_explain_paths():
    transport = FakeTransport([(200, b'{"updated": 1}'), (200, b'{"plan_id": "pl_1", "nodes": []}')])
    api = StateApi('https://api.example.com', 'tok', transport=transport)
    assert api.report(dict(plan_id='pl_1'))['updated'] == 1
    assert api.explain('pl_1')['plan_id'] == 'pl_1'
    assert transport.calls[0][1].endswith('/v1/state/report') and transport.calls[1][:2] == ('GET', 'https://api.example.com/v1/state/explain/pl_1')


@pytest.mark.parametrize('failure', [(500, b'oops'), (401, b'{}'), OSError('refused'), TimeoutError()])
def test_failures_raise_state_unavailable(failure):
    api = StateApi('https://api.example.com', 'tok', transport=FakeTransport([failure]))
    with pytest.raises(StateUnavailable) as info:
        api.plan({})
    assert info.value.reason


def test_non_json_success_body_is_unavailable():
    api = StateApi('https://api.example.com', 'tok', transport=FakeTransport([(201, b'<html>')]))
    with pytest.raises(StateUnavailable):
        api.plan({})


def test_redirect_status_is_unavailable():
    api = StateApi('https://api.example.com', 'tok', transport=FakeTransport([(302, b'')]))
    with pytest.raises(StateUnavailable):
        api.plan({})


@pytest.mark.parametrize('raw', [b'[]', b'null', b'"x"', b'1'])
def test_non_object_json_is_unavailable(raw):
    api = StateApi('https://api.example.com', 'tok', transport=FakeTransport([(201, raw)]))
    with pytest.raises(StateUnavailable) as info:
        api.plan({})
    assert info.value.reason == 'non-object response'


def test_urllib_transport_does_not_follow_redirects():
    import threading
    from http.server import BaseHTTPRequestHandler, HTTPServer

    seen = []

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            seen.append(self.path)
            self.send_response(302)
            self.send_header('Location', '/elsewhere')
            self.send_header('Content-Length', '0')
            self.end_headers()

        def log_message(self, *args):
            pass

    server = HTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        api = StateApi(f'http://127.0.0.1:{server.server_port}', 'tok')
        with pytest.raises(StateUnavailable) as info:
            api.plan({})
    finally:
        server.shutdown()
        server.server_close()
    assert 'http 302' in info.value.reason and seen == ['/v1/state/plan']
