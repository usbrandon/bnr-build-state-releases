from bnr_build_state.invocation import build_argv, compile_argv, parse
from bnr_build_state.invocation import test_argv as follow_up_test_argv  # the name would otherwise be collected as a test


def test_non_build_commands_are_not_wrapped():
    assert parse(['docs', 'generate']) is None
    assert parse(['test', '--select', 'x']) is None
    assert parse([]) is None


def test_parse_collects_values_and_global_flags():
    inv = parse(['--no-use-colors', 'build', '--select', 'a', 'b', '--exclude', 'c', '-t', 'prod',
                 '--profiles-dir', '/p', '--project-dir', '/d', '--target-path', 'out', '--full-refresh', '--fail-fast'])
    assert inv.command == 'build' and inv.global_args == ('--no-use-colors',)
    assert (inv.target, inv.profiles_dir, inv.project_dir, inv.target_path) == ('prod', '/p', '/d', 'out')
    assert inv.full_refresh and inv.exclude == ('c',)


def test_test_argv_keeps_target_defer_and_run_flags_and_drops_the_users_selection():
    inv = parse(['--debug', 'build', '--select', 'a', 'b', '--exclude', 'c', '--selector', 's', '-t', 'prod', '--profiles-dir', '/p',
                 '--project-dir', '/d', '--target-path', 'out', '--threads', '8', '--vars', '{"k": 1}', '--state', 'st', '--defer',
                 '--favor-state', '--indirect-selection', 'cautious', '--full-refresh', '--store-failures', '-x',
                 '--resource-type', 'model', '--empty'])
    assert follow_up_test_argv(inv, 'dbt', ['p.t1', 'p.t2']) == [
        'dbt', '--debug', 'test', '-t', 'prod', '--profiles-dir', '/p', '--project-dir', '/d', '--target-path', 'out', '--threads', '8',
        '--vars', '{"k": 1}', '--state', 'st', '--defer', '--favor-state', '--indirect-selection', 'cautious', '--store-failures', '-x',
        '--select', 'p.t1', 'p.t2']
    assert follow_up_test_argv(parse(['run']), 'dbt', ['p.t']) == ['dbt', 'test', '--select', 'p.t']


def test_parse_records_fail_fast_from_either_segment():
    assert parse(['build', '-x']).fail_fast and parse(['--fail-fast', 'build']).fail_fast
    assert not parse(['build']).fail_fast


def test_parse_accepts_equals_form():
    inv = parse(['run', '--target=prod', '--select=m'])
    assert inv.target == 'prod'


def test_compile_argv_keeps_selection_and_drops_build_only_flags():
    inv = parse(['build', '--select', 'a', 'b', '--selector', 's', '--exclude', 'c', '--vars', '{"k": 1}',
                 '--threads', '8', '--full-refresh', '--fail-fast', '--store-failures', '-t', 'prod'])
    assert compile_argv(inv, 'dbt') == ['dbt', 'compile', '--select', 'a', 'b', '--selector', 's', '--exclude', 'c',
                                        '--vars', '{"k": 1}', '--threads', '8', '-t', 'prod']


def test_resource_type_filters_narrow_the_selection_the_way_the_build_will():
    from bnr_build_state.invocation import builds_type
    inv = parse(['build', '--resource-type', 'model', '--resource-type', 'snapshot', '--selector', 'intraday'])
    assert inv.resource_types == ('model', 'snapshot')
    assert builds_type(inv, 'model.p.a') and builds_type(inv, 'snapshot.p.s') and not builds_type(inv, 'test.p.t')
    inv = parse(['build', '--exclude-resource-type', 'unit_test'])
    assert builds_type(inv, 'test.p.t') and not builds_type(inv, 'unit_test.p.u')
    assert builds_type(parse(['build', '--resource-type', 'all']), 'test.p.t')


def test_compile_argv_drops_resource_type_filters_compile_does_not_accept():
    # dbt compile has no --exclude-resource-type or --resource-type; forwarding them makes compile exit 2 and the
    # build is never run (`dbt build --exclude-resource-type unit_test` is the usual way to skip unit tests).
    inv = parse(['build', '--exclude-resource-type', 'unit_test', '--resource-type', 'model', '-s', 'a'])
    assert compile_argv(inv, 'dbt') == ['dbt', 'compile', '-s', 'a']
    assert build_argv(inv, 'dbt', ['x']) == ['dbt', 'build', '--exclude-resource-type', 'unit_test', '--resource-type', 'model',
                                             '-s', 'a', '--exclude', 'x']


def test_parse_records_runs_that_build_partial_data():
    assert not parse(['build', '-s', 'a']).partial_data
    assert parse(['build', '--empty', '-s', 'a']).partial_data
    assert parse(['run', '--sample', '3 days']).partial_data
    assert parse(['run', '--sample=3 days']).partial_data
    assert parse(['--empty', 'run']).partial_data


def test_parse_records_favor_state_from_either_segment():
    assert not parse(['build', '--defer', '--state', 'p']).favor_state
    assert parse(['build', '--defer', '--favor-state', '--state', 'p']).favor_state
    assert parse(['--favor-state', 'build', '--defer']).favor_state


def test_compile_argv_keeps_global_flags():
    assert compile_argv(parse(['--quiet', 'run']), 'dbt-fusion') == ['dbt-fusion', '--quiet', 'compile']


def test_build_argv_without_skips_is_the_original_command():
    inv = parse(['build', '--select', 'a', '--full-refresh'])
    assert build_argv(inv, 'dbt', []) == ['dbt', 'build', '--select', 'a', '--full-refresh']


def test_build_argv_merges_user_exclude_with_skips():
    inv = parse(['build', '--select', 'a', '--exclude', 'x', 'y', '--fail-fast'])
    assert build_argv(inv, 'dbt', ['m1', 'm2']) == ['dbt', 'build', '--select', 'a', '--fail-fast', '--exclude', 'x', 'y', 'm1', 'm2']


def test_build_argv_appends_exclude_when_user_had_none():
    assert build_argv(parse(['run']), 'dbt', ['m1']) == ['dbt', 'run', '--exclude', 'm1']


def test_compile_argv_keeps_state_and_deferral_flags():
    inv = parse(['build', '--state', 'prod-artifacts', '--defer', '--favor-state', '-m', 'a', '--profile', 'p2'])
    assert compile_argv(inv, 'dbt') == ['dbt', 'compile', '--state', 'prod-artifacts', '--defer', '--favor-state',
                                        '-m', 'a', '--profile', 'p2']
    assert build_argv(inv, 'dbt', ['x']) == ['dbt', 'build', '--state', 'prod-artifacts', '--defer', '--favor-state',
                                             '-m', 'a', '--profile', 'p2', '--exclude', 'x']


def test_parse_finds_subcommand_after_global_value_flags():
    inv = parse(['--log-format', 'json', '--target', 'prod', 'build', '--select', 'a'])
    assert inv.command == 'build'
    assert inv.global_args == ('--log-format', 'json', '--target', 'prod')
    assert inv.target == 'prod'
    assert compile_argv(inv, 'dbt') == ['dbt', '--log-format', 'json', '--target', 'prod', 'compile', '--select', 'a']


def test_subcommand_segment_wins_over_global():
    assert parse(['--target', 'g', 'run', '--target', 'l']).target == 'l'


def test_global_value_flag_named_like_a_command_does_not_hide_the_subcommand():
    inv = parse(['--target', 'test', 'build'])
    assert inv is not None and inv.command == 'build' and inv.target == 'test' and inv.global_args == ('--target', 'test')


def test_global_log_flags_are_value_flags():
    inv = parse(['--log-level', 'debug', 'run'])
    assert inv is not None and inv.command == 'run' and inv.global_args == ('--log-level', 'debug')
    assert parse(['--log-format-file', 'json', '--log-level-file', 'info', '--log-format', 'text', 'build']).command == 'build'


def test_selector_is_recorded_from_either_segment():
    assert parse(['build', '--selector', 's']).selector == 's'
    assert parse(['build', '--selector=s']).selector == 's'
    assert parse(['build', '--select', 'a']).selector is None


def test_redacted_args_hide_vars_values_only():
    from bnr_build_state.invocation import redacted_args
    assert redacted_args(parse(['build', '--vars', '{"pw": "x"}'])) == ['--vars', '<redacted>']
    assert redacted_args(parse(['build', '--vars={"pw": "x"}', '--select', 'a'])) == ['--vars=<redacted>', '--select', 'a']
    assert redacted_args(parse(['build', '--select', 'a'])) == ['--select', 'a']
