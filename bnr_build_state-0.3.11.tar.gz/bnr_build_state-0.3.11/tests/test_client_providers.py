import pytest

from bnr_build_state.artifacts import Relation
from bnr_build_state.profile import Profile
from bnr_build_state.providers import PROVIDERS, for_profile
from bnr_build_state.providers.base import UnsupportedAdapter, loaded_at_stamps, lit, stringify
from bnr_build_state.providers.duckdb import DuckDbProvider
from bnr_build_state.providers.postgres import PostgresProvider
from bnr_build_state.providers.snowflake import SnowflakeProvider

A = Relation('D', 'RAW', 'A', 'D.RAW.A')
B = Relation('D', 'RAW', 'B', 'D.RAW.B')
T = Relation('D', 'S', 'fct', 'D.S.fct')


class FakeConnection:
    """Returns canned rows per SQL substring; records every statement; raises on 'boom'."""

    def __init__(self, answers=None, columns=None):
        self.answers = answers or {}
        self.columns = columns or {}
        self.sql = []
        self.closed = False

    def execute(self, sql):
        self.sql.append(sql)
        if 'boom' in sql:
            raise RuntimeError('boom')
        for needle, rows in self.answers.items():
            if needle in sql:
                return rows
        return []

    def execute_with_columns(self, sql):
        rows = self.execute(sql)
        for needle, names in self.columns.items():
            if needle in sql:
                return names, rows
        return [], rows

    def close(self):
        self.closed = True


def test_lit_escapes_single_quotes():
    assert lit("o'brien") == "'o''brien'"


def test_stringify_is_stable_and_none_safe():
    from datetime import date, datetime, timezone
    assert stringify(None) is None
    assert stringify(datetime(2026, 10, 27, tzinfo=timezone.utc)) == '2026-10-27T00:00:00+00:00'
    assert stringify(7) == '7' and stringify(b'\x01') == '01'
    assert stringify(date(2026, 10, 27)) == '2026-10-27' and stringify(datetime(2026, 10, 27, 1, 2)) == '2026-10-27T01:02:00'


def test_stringify_renders_aware_datetimes_in_utc_whatever_the_session_zone():
    # The same instant as a TIMESTAMP_LTZ read under America/Los_Angeles and under UTC must give one stamp.
    from datetime import datetime, timedelta, timezone
    la = datetime(2026, 10, 26, 17, 0, tzinfo=timezone(timedelta(hours=-7)))
    utc = datetime(2026, 10, 27, 0, 0, tzinfo=timezone.utc)
    assert stringify(la) == stringify(utc) == '2026-10-27T00:00:00+00:00'


def test_snowflake_connect_sets_the_session_to_utc(monkeypatch):
    import sys, types
    from bnr_build_state.providers import snowflake as sf

    class Raw:
        def __init__(self):
            self.sql, self.timeouts = [], []

        def cursor(self):
            raw = self

            class Cur:
                description = None
                def execute(self, sql, timeout=None): raw.sql.append(sql); raw.timeouts.append(timeout)
                def fetchall(self): return []
                def close(self): pass
            return Cur()
    raw = Raw()
    connector = types.SimpleNamespace(connect=lambda **kwargs: raw)
    monkeypatch.setitem(sys.modules, 'snowflake', types.SimpleNamespace(connector=connector))
    monkeypatch.setitem(sys.modules, 'snowflake.connector', connector)
    provider = sf.SnowflakeProvider.connect(dict(type='snowflake', account='acme', user='u', password='p', warehouse='W'))
    assert raw.sql == ["alter session set timezone = 'UTC'"] and provider.warehouse_name == 'W'
    assert raw.timeouts == [sf.QUERY_TIMEOUT_SECONDS]  # every bnr metadata query carries the ceiling


def test_snowflake_use_utc_failure_only_warns(caplog):
    caplog.set_level('WARNING')

    class NoAlter(FakeConnection):
        def execute(self, sql):
            raise RuntimeError('no privilege')
    SnowflakeProvider(NoAlter(), locator='x').use_utc()
    assert any('session timezone' in r.getMessage() and 'no privilege' in r.getMessage() for r in caplog.records)


def test_snowflake_last_ddl_stamp_is_timezone_independent():
    from datetime import datetime, timedelta, timezone
    la = datetime(2026, 10, 26, 17, 0, tzinfo=timezone(timedelta(hours=-7)))
    utc = datetime(2026, 10, 27, 0, 0, tzinfo=timezone.utc)
    stamps = []
    for ddl in (la, utc):
        conn = FakeConnection({'SYSTEM$LAST_CHANGE_COMMIT_TIME': [('D.RAW.A', 111)],
                               'information_schema.tables': [('A', 'BASE TABLE', ddl, 3)]})
        stamps.append(SnowflakeProvider(conn, locator='x').stamps([A])[A])
    assert stamps[0] == stamps[1] == '111:2026-10-27T00:00:00+00:00'


def test_loaded_at_batches_scalar_subqueries_in_one_statement():
    conn = FakeConnection({'as s0': [('2026-01-01', 5)]})
    out = loaded_at_stamps(conn, [('src.a', 'select max(x) from a'), ('src.b', 'select max(y) from b')])
    assert out == {'src.a': '2026-01-01', 'src.b': '5'}
    assert len(conn.sql) == 1 and conn.sql[0] == 'select (select max(x) from a) as s0, (select max(y) from b) as s1'


def test_loaded_at_batch_falls_back_to_single_queries():
    conn = FakeConnection({'select (select max(x) from a) as s0': [('v',)]})
    out = loaded_at_stamps(conn, [('src.a', 'select max(x) from a'), ('src.b', 'select boom from b')])
    assert out == {'src.a': 'v', 'src.b': None}
    assert len(conn.sql) == 3  # batch, then one per item


def test_loaded_at_respects_batch_size():
    conn = FakeConnection({'as s0': [('1',)]})
    loaded_at_stamps(conn, [(f'src.{i}', f'select {i}') for i in range(3)], batch=2)
    assert len(conn.sql) == 2


def test_snowflake_stamps_combine_commit_time_and_last_ddl():
    conn = FakeConnection({'SYSTEM$LAST_CHANGE_COMMIT_TIME': [('D.RAW.A', 111), ('D.RAW.B', 222)],
                           'information_schema.tables': [('A', 'BASE TABLE', '2026-10-27T00:00:00', 3), ('B', 'BASE TABLE', None, None)]})
    provider = SnowflakeProvider(conn, locator='acme-xy12345')
    assert provider.stamps([A, B]) == {A: '111:2026-10-27T00:00:00', B: '222:'}
    # The catalog first (exact, prunable schema filter), then commit times for the base tables it listed.
    assert conn.sql[0] == ('select table_name, table_type, last_ddl, row_count, is_iceberg from "D".information_schema.tables '
                           "where table_schema = 'RAW'")
    assert "SYSTEM$LAST_CHANGE_COMMIT_TIME('D.RAW.A')" in conn.sql[1]


ICEBERG_COLUMNS = {'show iceberg tables': ['created_on', 'name', 'database_name', 'schema_name', 'owner', 'external_volume_name',
                                           'catalog_name', 'iceberg_table_type']}


def test_snowflake_iceberg_table_in_an_external_catalog_is_unknown_and_managed_keeps_its_stamp():
    c = Relation('D', 'RAW', 'C', 'D.RAW.C')
    conn = FakeConnection({'SYSTEM$LAST_CHANGE_COMMIT_TIME': [('D.RAW.A', 1), ('D.RAW.B', 2), ('D.RAW.C', 3)],
                           'information_schema.tables': [('A', 'BASE TABLE', 'x', 1, 'NO'), ('B', 'BASE TABLE', 'y', 1, 'YES'),
                                                         ('C', 'BASE TABLE', 'z', 1, 'YES')],
                           'show iceberg tables': [('2026', 'B', 'D', 'RAW', 'R', 'VOL', 'SNOWFLAKE', 'MANAGED'),
                                                   ('2026', 'C', 'D', 'RAW', 'R', 'VOL', 'GLUE_INT', 'UNMANAGED')]},
                          columns=ICEBERG_COLUMNS)
    assert SnowflakeProvider(conn, locator='x').stamps([A, B, c]) == {A: '1:x', B: '2:y', c: None}
    assert 'is_iceberg' in conn.sql[0] and conn.sql[1] == 'show iceberg tables in schema "D"."RAW"'
    assert "'D.RAW.C'" not in conn.sql[2]  # no commit time for a table whose stamp is unknown anyway


def test_snowflake_show_iceberg_tables_runs_only_for_schemas_that_hold_one():
    conn = FakeConnection({'SYSTEM$LAST_CHANGE_COMMIT_TIME': [('D.RAW.A', 1)], 'information_schema.tables': [('A', 'BASE TABLE', 'x', 1, 'NO')]})
    assert SnowflakeProvider(conn, locator='x').stamps([A]) == {A: '1:x'}
    assert not any('show iceberg' in s for s in conn.sql)


def test_snowflake_unreadable_iceberg_catalog_makes_every_iceberg_table_unknown(caplog):
    caplog.set_level('WARNING')
    rows = {'SYSTEM$LAST_CHANGE_COMMIT_TIME': [('D.RAW.A', 1), ('D.RAW.B', 2)],
            'information_schema.tables': [('A', 'BASE TABLE', 'x', 1, 'NO'), ('B', 'BASE TABLE', 'y', 1, 'YES')]}

    class NoShow(FakeConnection):
        def execute(self, sql):
            if 'show iceberg' in sql:
                raise RuntimeError('no privilege')
            return super().execute(sql)
    assert SnowflakeProvider(NoShow(dict(rows)), locator='x').stamps([A, B]) == {A: '1:x', B: None}
    # A SHOW whose output lacks the catalog columns is equally unusable.
    conn = FakeConnection(dict(rows, **{'show iceberg tables': [('2026', 'B')]}), columns={'show iceberg tables': ['created_on', 'name']})
    assert SnowflakeProvider(conn, locator='x').stamps([A, B]) == {A: '1:x', B: None}
    assert sum('iceberg_tables' in r.getMessage() for r in caplog.records) == 2


def test_snowflake_stamp_batch_error_retries_per_relation():
    boom = Relation('D', 'RAW', 'boom', 'D.RAW.boom')
    conn = FakeConnection({"SYSTEM$LAST_CHANGE_COMMIT_TIME('D.RAW.A')": [('D.RAW.A', 5)], 'information_schema.tables': [('A', 'BASE TABLE', 'x', 1)]})
    provider = SnowflakeProvider(conn, locator='x')
    assert provider.stamps([A, boom]) == {A: '5:x', boom: None}


def test_snowflake_relations_read_the_catalog_with_the_exact_schema_name():
    """information_schema, not SHOW TERSE OBJECTS: SHOW stops at 10,000 rows and the rest would count as absent."""
    conn = FakeConnection({'information_schema.tables': [('FCT',), ('Other',)]})
    provider = SnowflakeProvider(conn, locator='x')
    assert provider.relations('D', 'S') == {'fct', 'other'}
    assert conn.sql == ["select table_name from \"D\".information_schema.tables where table_schema = 'S'"]
    conn = FakeConnection({'information_schema.tables': [('FCT',)]})
    assert SnowflakeProvider(conn, locator='x').relations(None, 'my schema') == {'fct'}
    assert conn.sql[0] == "select table_name from information_schema.tables where table_schema = 'my schema'"


def test_snowflake_observe_carries_only_content_stable_values():
    conn = FakeConnection({'information_schema.tables': [('FCT', 'BASE TABLE', '2026-10-27', 42)],
                           'information_schema.columns': [('FCT', 'ID', 'NUMBER'), ('FCT', 'NAME', 'TEXT')]})
    provider = SnowflakeProvider(conn, locator='x')
    out = provider.observe([T])
    assert set(out[T]) == {'row_count', 'schema_sha256'}  # no hash_agg answer in the fake: the key is simply absent
    assert out[T]['row_count'] == '42'
    assert len(out[T]['schema_sha256']) == 64 and len(conn.sql) == 3 and 'hash_agg(*)' in conn.sql[2]


def test_snowflake_observe_hashes_the_content_of_small_base_tables_only(monkeypatch):
    big = Relation('D', 'S', 'BIG', 'D.S.BIG')
    view = Relation('D', 'S', 'V', 'D.S.V')
    conn = FakeConnection({'information_schema.tables': [('FCT', 'BASE TABLE', 'x', 42), ('BIG', 'BASE TABLE', 'x', 10_000_000), ('V', 'VIEW', 'x', None)],
                           'information_schema.columns': [], 'hash_agg(*)': [('D.S.fct', -123456789)]})
    out = SnowflakeProvider(conn, locator='x').observe([T, big, view])
    assert out[T]['content_hash'] == '-123456789' and 'content_hash' not in out[big] and 'content_hash' not in out[view]
    assert [s for s in conn.sql if 'hash_agg' in s] == ["select 'D.S.fct', hash_agg(*) from D.S.fct"]
    monkeypatch.setenv('BNR_CONTENT_HASH_MAX_ROWS', '0')
    conn = FakeConnection({'information_schema.tables': [('FCT', 'BASE TABLE', 'x', 42)], 'information_schema.columns': []})
    assert 'content_hash' not in SnowflakeProvider(conn, locator='x').observe([T])[T] and not any('hash_agg' in s for s in conn.sql)


def test_snowflake_observe_hash_scope_raises_or_removes_the_ceiling_per_relation(monkeypatch):
    big = Relation('D', 'S', 'BIG', 'D.S.BIG')
    huge = Relation('D', 'S', 'HUGE', 'D.S.HUGE')
    conn = FakeConnection({'information_schema.tables': [('FCT', 'BASE TABLE', 'x', 42), ('BIG', 'BASE TABLE', 'x', 3_000_000), ('HUGE', 'BASE TABLE', 'x', 60_000_000)],
                           'information_schema.columns': [], 'hash_agg(*)': [('D.S.BIG', 7)]})
    out = SnowflakeProvider(conn, locator='x').observe([T, big, huge], hash_scope={T: 'skip', big: 'force', huge: 'force'})
    assert 'content_hash' not in out[T]            # opted out, although it is under the default cap
    assert out[big]['content_hash'] == '7'          # forced: 3M rows is under the 5M forced ceiling
    assert 'content_hash' not in out[huge]          # forced but above the ceiling: a full scan per run is not paid
    assert [s for s in conn.sql if 'hash_agg' in s] == ["select 'D.S.BIG', hash_agg(*) from D.S.BIG"]
    monkeypatch.setenv('BNR_CONTENT_HASH_FORCE_MAX_ROWS', '1000')
    conn = FakeConnection({'information_schema.tables': [('BIG', 'BASE TABLE', 'x', 3_000_000)], 'information_schema.columns': []})
    assert 'content_hash' not in SnowflakeProvider(conn, locator='x').observe([big], hash_scope={big: 'force'})[big]


def test_snowflake_observe_null_row_count_is_empty_string():
    conn = FakeConnection({'information_schema.tables': [('FCT', 'VIEW', None, None)],
                           'information_schema.columns': [('FCT', 'ID', 'NUMBER')]})
    assert SnowflakeProvider(conn, locator='x').observe([T])[T]['row_count'] == ''


def test_snowflake_view_stamps_none_and_base_table_keeps_token():
    conn = FakeConnection({'SYSTEM$LAST_CHANGE_COMMIT_TIME': [('D.RAW.A', 111), ('D.RAW.B', 222)],
                           'information_schema.tables': [('A', 'VIEW', '2026-10-27', 0), ('B', 'BASE TABLE', '2026-10-28', 5)]})
    out = SnowflakeProvider(conn, locator='x').stamps([A, B])
    assert out == {A: None, B: '222:2026-10-28'}
    assert 'table_type' in conn.sql[0]
    assert "'D.RAW.A'" not in conn.sql[1]  # a view never enters a commit-time batch, where it would fail all of it


def test_snowflake_view_definitions_read_information_schema_and_null_stays_none():
    conn = FakeConnection({'information_schema.views': [('A', 'create view D.RAW.A as select 1'), ('B', None)]})
    out = SnowflakeProvider(conn, locator='x').view_definitions([A, B])
    assert out == {A: 'create view D.RAW.A as select 1', B: None}
    assert conn.sql[0].endswith("information_schema.views where table_schema = 'RAW'")
    assert SnowflakeProvider(FakeConnection({'information_schema.views': []}), locator='x').view_definitions([A]) == {A: None}


def test_snowflake_view_definitions_failure_gives_none():
    broken = Relation('boom', 'RAW', 'A', 'boom.RAW.A')
    assert SnowflakeProvider(FakeConnection(), locator='x').view_definitions([broken]) == {broken: None}


def test_postgres_stamps_use_stat_counters_and_relfilenode():
    conn = FakeConnection({'track_counts': [('on', False)], 'pg_stat_user_tables': [('a', 12, 4455, 'r'), ('v', 0, 0, 'v')]})
    a = Relation('d', 'raw', 'a', '"raw"."a"')
    v = Relation('d', 'raw', 'v', '"raw"."v"')
    missing = Relation('d', 'raw', 'nope', '"raw"."nope"')
    provider = PostgresProvider(conn, locator='db.local:5432')
    assert provider.stamps([a, v, missing]) == {a: '12:4455', v: None, missing: None}
    assert "n.nspname = 'raw'" in conn.sql[1] and "'a'" in conn.sql[1]


def test_postgres_relations_and_observe():
    conn = FakeConnection({'information_schema.tables': [('a',), ('B',)],
                           'pg_stat_user_tables': [('a', 1, 77, 'r')],
                           'pg_relation_size': [('a', 'r', 8192)],
                           'count(*)': [(42,)],
                           'information_schema.columns': [('a', 'id', 'integer')]})
    a = Relation('d', 'raw', 'a', '"raw"."a"')
    provider = PostgresProvider(conn, locator='x')
    assert provider.relations('d', 'raw') == {'a', 'b'}
    out = provider.observe([a])
    assert set(out[a]) == {'schema_sha256', 'row_count'} and len(out[a]['schema_sha256']) == 64
    assert out[a]['row_count'] == '42' and conn.sql[-1] == 'select (select count(*) from "raw"."a") as s0'


def test_postgres_observe_counts_only_tables_within_the_size_bound():
    from bnr_build_state.providers.postgres import COUNT_LIMIT_BYTES
    small = Relation('d', 'raw', 'small', '"raw"."small"')
    big = Relation('d', 'raw', 'big', '"raw"."big"')
    view = Relation('d', 'raw', 'v', '"raw"."v"')
    part = Relation('d', 'raw', 'p', '"raw"."p"')
    conn = FakeConnection({'pg_relation_size': [('small', 'r', COUNT_LIMIT_BYTES), ('big', 'r', COUNT_LIMIT_BYTES + 1), ('v', 'v', 0), ('p', 'p', 0)],
                           'count(*)': [(7,)], 'information_schema.columns': [('small', 'id', 'integer')]})
    out = PostgresProvider(conn, locator='x').observe([small, big, view, part])
    assert {r.identifier: v['row_count'] for r, v in out.items()} == {'small': '7', 'big': '', 'v': '', 'p': ''}
    counts = [s for s in conn.sql if 'count(*)' in s]
    assert counts == ['select (select count(*) from "raw"."small") as s0']
    assert any('pg_relation_size(c.oid)' in s and "n.nspname = 'raw'" in s for s in conn.sql)


def test_postgres_observe_without_sizes_or_counts_keeps_the_schema_signature(caplog):
    caplog.set_level('WARNING')
    a = Relation('d', 'raw', 'a', '"raw"."a"')

    class NoClass(FakeConnection):
        def execute(self, sql):
            if 'pg_relation_size' in sql:
                raise RuntimeError('no privilege')
            return super().execute(sql)
    out = NoClass({'information_schema.columns': [('a', 'id', 'integer')]})
    assert PostgresProvider(out, locator='x').observe([a])[a]['row_count'] == ''
    assert not any('count(*)' in s for s in out.sql)

    class CountBoom(FakeConnection):
        def execute(self, sql):
            if 'count(*)' in sql:
                raise RuntimeError('timeout')
            return super().execute(sql)
    out = CountBoom({'pg_relation_size': [('a', 'r', 1)], 'information_schema.columns': [('a', 'id', 'integer')]})
    result = PostgresProvider(out, locator='x').observe([a])[a]
    assert result['row_count'] == '' and len(result['schema_sha256']) == 64


def test_duckdb_has_no_change_stamps():
    conn = FakeConnection({'information_schema.tables': [('a', 'BASE TABLE'), ('v', 'VIEW')],
                           'information_schema.columns': [('a', 'id', 'INTEGER')], 'count(*)': [(3,)]})
    a = Relation(None, 'main', 'a', 'main.a')
    v = Relation(None, 'main', 'v', 'main.v')
    provider = DuckDbProvider(conn, locator='/tmp/x.duckdb')
    assert provider.stamps([a]) == {a: None} and conn.sql == []
    assert provider.relations(None, 'main') == {'a', 'v'}
    out = provider.observe([a, v])
    assert set(out[a]) == {'schema_sha256', 'row_count'} and out[a]['row_count'] == '3' and out[v]['row_count'] == ''
    assert [s for s in conn.sql if 'count(*)' in s] == ['select (select count(*) from main.a) as s0']  # views are not counted


def test_registry_and_locators():
    assert set(PROVIDERS) == {'snowflake', 'postgres', 'duckdb'}
    conn = FakeConnection()
    sf = for_profile(Profile('p', 'dev', 'snowflake', dict(type='snowflake', account='acme-xy12345')), connection=conn)
    assert (sf.platform, sf.dialect, sf.locator) == ('snowflake', 'snowflake', 'acme-xy12345')
    pg = for_profile(Profile('p', 'dev', 'postgres', dict(type='postgres', host='h', port=5433)), connection=conn)
    assert (pg.platform, pg.locator) == ('postgres', 'h:5433')
    dk = for_profile(Profile('p', 'dev', 'duckdb', dict(type='duckdb', path='md:mydb')), connection=conn)
    assert (dk.platform, dk.locator) == ('duckdb', 'md:mydb')
    with pytest.raises(UnsupportedAdapter):
        for_profile(Profile('p', 'dev', 'bigquery', dict(type='bigquery')), connection=conn)


def test_close_closes_connection():
    conn = FakeConnection()
    SnowflakeProvider(conn, locator='x').close()
    assert conn.closed


def test_postgres_partitioned_parent_stamps_none():
    conn = FakeConnection({'track_counts': [('on', False)], 'pg_stat_user_tables': [('p', 0, 0, 'p')]})
    p = Relation('d', 'raw', 'p', '"raw"."p"')
    assert PostgresProvider(conn, locator='x').stamps([p]) == {p: None}


def test_snowflake_lit_escapes_backslash_and_quote():
    from bnr_build_state.providers.snowflake import _lit
    assert _lit("a\\'b") == "'a\\\\''b'"


def test_snowflake_ident_quotes_when_needed_and_database_none_has_no_prefix():
    from bnr_build_state.providers.snowflake import _ident
    assert _ident('ANALYTICS_1$') == 'ANALYTICS_1$' and _ident('my-schema') == '"my-schema"'
    assert _ident('a"b') == '"a""b"'
    conn = FakeConnection({'information_schema.tables': [('X',)]})
    provider = SnowflakeProvider(conn, locator='x')
    provider.relations('D', 'my-schema')
    provider.relations(None, 'S')
    # A quoted (non-bare) schema keeps its case; a bare one is stored upper-cased.
    assert conn.sql == ['select table_name from "D".information_schema.tables where table_schema = \'my-schema\'',
                        "select table_name from information_schema.tables where table_schema = 'S'"]
    conn = FakeConnection()
    SnowflakeProvider(conn, locator='x').stamps([Relation(None, 'S', 'a', 'S.a')])
    assert any('from information_schema.tables' in s for s in conn.sql)


def test_snowflake_lowercase_schema_matches_uppercase_metadata():
    t = Relation('D', 's', 'fct', 'D.s.fct')
    conn = FakeConnection({'SYSTEM$LAST_CHANGE_COMMIT_TIME': [('D.s.fct', 9)],
                           'information_schema.tables': [('FCT', 'BASE TABLE', '2026-10-27', 1)],
                           'information_schema.columns': [('FCT', 'ID', 'NUMBER')]})
    provider = SnowflakeProvider(conn, locator='x')
    assert provider.stamps([t]) == {t: '9:2026-10-27'}
    out = provider.observe([t])
    # dbt wrote the schema unquoted, so Snowflake stores it upper-cased: one exact, prunable filter.
    assert all("table_schema = 'S'" in s for s in conn.sql if 'information_schema' in s)
    assert not any('upper(table_schema)' in s for s in conn.sql)
    assert out[t]['schema_sha256'] != __import__('hashlib').sha256(b'').hexdigest()


def test_snowflake_missing_ddl_row_stays_unknown_and_present_row_stamps():
    conn = FakeConnection({'SYSTEM$LAST_CHANGE_COMMIT_TIME': [('D.RAW.A', 5), ('D.RAW.B', 6)],
                           'information_schema.tables': [('A', 'BASE TABLE', '2026', 1)]})
    assert SnowflakeProvider(conn, locator='x').stamps([A, B]) == {A: '5:2026', B: None}


class _TablesBoom(FakeConnection):
    def execute(self, sql):
        if 'information_schema.tables' in sql or 'information_schema.columns' in sql:
            self.sql.append(sql)
            raise RuntimeError('no privilege')
        return super().execute(sql)


def test_snowflake_information_schema_failure_gives_none_not_exception(caplog):
    caplog.set_level('WARNING')
    conn = _TablesBoom({'SYSTEM$LAST_CHANGE_COMMIT_TIME': [('D.RAW.A', 5), ('D.RAW.B', 6)]})
    provider = SnowflakeProvider(conn, locator='x')
    assert provider.stamps([A, B]) == {A: None, B: None}
    assert provider.observe([A, B]) == {A: {}, B: {}}
    assert any('last_ddl' in r.getMessage() and 'no privilege' in r.getMessage() for r in caplog.records)


def test_duckdb_catalog_filter_only_when_database_given():
    conn = FakeConnection({'information_schema.tables': [('a',)]})
    provider = DuckDbProvider(conn, locator='x')
    provider.relations('md_db', 'main')
    provider.relations(None, 'main')
    assert "table_catalog = 'md_db'" in conn.sql[0] and 'table_catalog' not in conn.sql[1]
    conn = FakeConnection({'information_schema.columns': [('a', 'id', 'INTEGER')]})
    a = Relation('md_db', 'main', 'a', 'main.a')
    DuckDbProvider(conn, locator='x').observe([a])
    assert "table_catalog = 'md_db'" in conn.sql[0]


def test_postgres_blind_counters_stamp_none_everywhere(caplog):
    caplog.set_level('WARNING')
    a = Relation('d', 'raw', 'a', '"raw"."a"')
    for setting in ([('off', False)], [('on', True)]):
        conn = FakeConnection({'track_counts': setting, 'pg_stat_user_tables': [('a', 12, 4455, 'r')]})
        assert PostgresProvider(conn, locator='x').stamps([a]) == {a: None}
        assert len(conn.sql) == 1 and 'pg_is_in_recovery()' in conn.sql[0]
    assert any('track_counts' in r.getMessage() for r in caplog.records)
    conn = FakeConnection({'track_counts': [('on', False)], 'pg_stat_user_tables': [('a', 12, 4455, 'r')]})
    assert PostgresProvider(conn, locator='x').stamps([a]) == {a: '12:4455'}


def test_snowflake_ident_trailing_newline_is_quoted():
    from bnr_build_state.providers.snowflake import _ident
    assert _ident('ok\n') == '"ok\n"'


def test_snowflake_connect_kwargs_inline_private_key_and_jwt():
    from bnr_build_state.providers.snowflake import _connect_kwargs
    kwargs = _connect_kwargs(dict(account='a', user='u', private_key='-----BEGIN PRIVATE KEY-----\nabc', authenticator='SNOWFLAKE_JWT',
                                  private_key_passphrase='pp'))
    assert kwargs['private_key'] == b'-----BEGIN PRIVATE KEY-----\nabc' and kwargs['authenticator'] == 'snowflake_jwt'
    assert 'private_key_file' not in kwargs and 'private_key_file_pwd' not in kwargs and 'private_key_passphrase' not in kwargs


def test_snowflake_connect_kwargs_key_file_with_passphrase():
    from bnr_build_state.providers.snowflake import _connect_kwargs
    kwargs = _connect_kwargs(dict(account='a', user='u', private_key_path='/k.p8', private_key_passphrase='pp'))
    assert kwargs['private_key_file'] == '/k.p8' and kwargs['private_key_file_pwd'] == 'pp' and 'private_key_path' not in kwargs


def test_snowflake_warehouse_reports_size_and_credits():
    conn = FakeConnection({'show warehouses like': [('TRANSFORM', 'STARTED', 'Medium')]}, columns={'show warehouses like': ['name', 'state', 'size']})
    provider = SnowflakeProvider(conn, locator='acct'); provider.warehouse_name = 'transform'
    assert provider.warehouse() == dict(name='TRANSFORM', size='Medium', credits_per_hour=4)
    assert conn.sql[-1] == "show warehouses like 'transform'"


def test_snowflake_warehouse_picks_the_exact_name_among_like_rows():
    # LIKE treats '_' as a wildcard, so 'transform_wh' also matches TRANSFORMXWH.
    rows = [('TRANSFORMXWH', 'STARTED', 'X-Large'), ('TRANSFORM_WH', 'STARTED', 'Small')]
    conn = FakeConnection({'show warehouses like': rows}, columns={'show warehouses like': ['name', 'state', 'size']})
    provider = SnowflakeProvider(conn, locator='acct'); provider.warehouse_name = 'transform_wh'
    assert provider.warehouse() == dict(name='TRANSFORM_WH', size='Small', credits_per_hour=2)
    provider.warehouse_name = 'transform'
    assert provider.warehouse() is None


def test_snowflake_warehouse_lookup_failure_sends_no_warehouse():
    provider = SnowflakeProvider(FakeConnection({'show warehouses like': 'boom'}), locator='acct'); provider.warehouse_name = 'boom'
    assert provider.warehouse() is None
    assert SnowflakeProvider(FakeConnection(), locator='acct').warehouse() is None  # no name configured
    assert PostgresProvider(FakeConnection(), locator='x').warehouse() is None
    assert DuckDbProvider(FakeConnection(), locator='x').warehouse() is None


def test_unknown_size_has_no_credits():
    conn = FakeConnection({'show warehouses like': [('W', 'STARTED', 'Snowpark-optimized')]}, columns={'show warehouses like': ['name', 'state', 'size']})
    provider = SnowflakeProvider(conn, locator='acct'); provider.warehouse_name = 'w'
    assert provider.warehouse() == dict(name='W', size='Snowpark-optimized')


class _TimedOut(Exception):
    errno = 604  # Snowflake "SQL execution canceled"


def test_snowflake_cursor_turns_a_cancelled_query_into_query_timeout():
    from bnr_build_state.providers.base import QueryTimeout
    from bnr_build_state.providers.snowflake import _Cursor

    class Raw:
        seen = []

        def cursor(self):
            class Cur:
                description = None
                def execute(self, sql, timeout=None):
                    Raw.seen.append(timeout)
                    raise _TimedOut('000604: SQL execution canceled')
                def close(self): pass
            return Cur()
    with pytest.raises(QueryTimeout):
        _Cursor(Raw(), timeout=5).execute('select 1')
    assert Raw.seen == [5]
    with pytest.raises(_TimedOut):  # without a ceiling a cancellation is someone else's, and stays as raised
        _Cursor(Raw()).execute('select 1')


def test_timed_out_commit_time_batch_is_left_unknown_without_per_relation_retries():
    from bnr_build_state.providers.base import QueryTimeout

    class Slow(FakeConnection):
        def execute(self, sql):
            if 'SYSTEM$LAST_CHANGE_COMMIT_TIME' in sql:
                self.sql.append(sql)
                raise QueryTimeout('cancelled after 600 s')
            return super().execute(sql)
    conn = Slow({'information_schema.tables': [('A', 'BASE TABLE', 'd', 1), ('B', 'BASE TABLE', 'd', 1)]})
    assert SnowflakeProvider(conn, locator='x').stamps([A, B]) == {A: None, B: None}
    assert sum('SYSTEM$LAST_CHANGE_COMMIT_TIME' in q for q in conn.sql) == 1


def test_timed_out_loaded_at_batch_is_left_unknown_without_per_item_retries():
    from bnr_build_state.providers.base import QueryTimeout

    class Slow(FakeConnection):
        def execute(self, sql):
            self.sql.append(sql)
            raise QueryTimeout('cancelled after 600 s')
    conn = Slow()
    assert loaded_at_stamps(conn, [('src.a', 'select 1'), ('src.b', 'select 2')]) == {'src.a': None, 'src.b': None}
    assert len(conn.sql) == 1


@pytest.mark.parametrize('value, expected', [(None, 600), ('120', 120), ('nope', 600)])
def test_query_timeout_comes_from_the_environment(value, expected):
    from bnr_build_state.providers.snowflake import query_timeout
    assert query_timeout({} if value is None else {'BNR_QUERY_TIMEOUT_SECONDS': value}) == expected


def test_quoted_mixed_case_location_keeps_its_case_and_falls_back_when_the_account_ignores_it():
    q = Relation('Mixed', 'MySchema', 'Fct', '"Mixed"."MySchema"."Fct"')
    conn = FakeConnection({"table_schema = 'MySchema'": [('Fct', 'BASE TABLE', 'd', 1, 'NO')],
                           'SYSTEM$LAST_CHANGE_COMMIT_TIME': [('"Mixed"."MySchema"."Fct"', 5)]})
    assert SnowflakeProvider(conn, locator='x').stamps([q]) == {q: '5:d'}
    assert conn.sql[0].startswith('select table_name, table_type') and '"Mixed".information_schema.tables' in conn.sql[0]
    # QUOTED_IDENTIFIERS_IGNORE_CASE stores it upper-cased: the exact read finds nothing, the case-insensitive one does.
    ignoring = FakeConnection({"upper(table_schema) = upper('MySchema')": [('FCT', 'BASE TABLE', 'd', 1, 'NO')],
                               'SYSTEM$LAST_CHANGE_COMMIT_TIME': [('"Mixed"."MySchema"."Fct"', 5)]})
    assert SnowflakeProvider(ignoring, locator='x').stamps([q]) == {q: '5:d'}


def test_unquoted_empty_schema_is_not_reread_case_insensitively():
    conn = FakeConnection()
    SnowflakeProvider(conn, locator='x').stamps([A])
    assert len([s for s in conn.sql if 'information_schema.tables' in s]) == 1  # the slow scan never runs


def test_relation_name_parts_respect_quotes():
    from bnr_build_state.providers.snowflake import _Location, _parts
    assert _parts('"a.b"."S".t') == ['"a.b"', '"S"', 't']
    loc = _Location(Relation('a.b', 'S', 't', '"a.b"."S".t'))
    assert (loc.database, loc.schema, loc.quoted, loc.prefix) == ('a.b', 'S', True, '"a.b".')
    loc = _Location(Relation(None, 's', 't', 's.t'))
    assert (loc.database, loc.schema, loc.quoted, loc.prefix) == (None, 'S', False, '')


def test_one_bad_query_in_a_batch_is_isolated_by_halving_and_named(caplog):
    good = {f'as s0': [('v',)]}  # every single-item query succeeds except the one with `boom`
    class Conn(FakeConnection):
        def execute(self, sql):
            self.sql.append(sql)
            if 'boom' in sql:
                raise RuntimeError('invalid identifier')
            return [tuple('v' for _ in range(sql.count(' as s')))]
    conn = Conn(good)
    items = [(f'src.{i}', f'select {i}') for i in range(8)]
    items[5] = ('src.bad', 'select boom')
    with caplog.at_level('WARNING', logger='bnr_build_state'):
        out = loaded_at_stamps(conn, items)
    assert out == {f'src.{i}': 'v' for i in range(8) if i != 5} | {'src.bad': None}
    assert len(conn.sql) <= 1 + 2 * 3  # the batch, then halves down to the one at fault: never one query per item
    assert any('src.bad' in r.getMessage() and 'left unknown' in r.getMessage() for r in caplog.records)
