from bnr_build_state import artifacts as a
from bnr_build_state.hashing import SqlFacts, analyze
from bnr_build_state.planning import exclusions_for, plan_request, report_request, skipped_ids, summary
from client_fixtures import MANIFEST, SELECTED, SRC_A, SRC_B, SRC_C, run_results, write_project


def _facts(tmp_path):
    write_project(tmp_path)
    return a.facts(MANIFEST, SELECTED, tmp_path / 'target', 'p')


def _sql_facts(facts):
    return {f.unique_id: analyze(f.sql, 'snowflake') for f in facts if f.sql}


def _request(tmp_path, **overrides):
    facts = _facts(tmp_path)
    kwargs = dict(account_id=1, project='p', platform='snowflake', locator='acme', database='D', schema='S',
                  engine=dict(family='core', version='1.12.5'), invocation=dict(command='build', args=['-s', 'x'], cause='test'),
                  run_id=None, facts=facts, sql_facts=_sql_facts(facts),
                  stamps={SRC_A: ('2026-10-27', 'loaded_at_field'), SRC_B: ('5', 'loaded_at_query'), SRC_C: (None, 'unknown')},
                  present={('D', 'S'): {'stg', 'fct', 'countries'}})
    kwargs.update(overrides)
    return plan_request(**kwargs)


def test_plan_request_shape_matches_service(tmp_path):
    body = _request(tmp_path)
    assert body['account_id'] == 1 and body['target'] == dict(platform='snowflake', locator='acme', database='D', schema='S')
    assert body['engine'] == dict(family='core', version='1.12.5') and body['run_id'] is None
    nodes = {n['unique_id']: n for n in body['nodes']}
    assert list(nodes) == SELECTED
    assert nodes['model.p.fct']['depends_on'] == ['model.p.stg', SRC_B] and nodes['model.p.fct']['target_present'] is True
    assert nodes['model.p.hooked']['target_present'] is False and nodes['model.p.hooked']['flags'] == ['has_hooks']
    assert nodes['test.p.not_null_fct_id']['target_present'] is None
    assert nodes['seed.p.countries']['sql_sha256'] == 'c0ffee'
    assert nodes['model.p.eph']['target_present'] is None
    assert nodes['model.p.fct']['config_sha256'] == a.config_sha256(MANIFEST['nodes']['model.p.fct'])
    assert nodes['model.p.fct']['materialized'] == 'incremental'
    assert {s['unique_id']: (s['stamp'], s['stamp_kind']) for s in body['sources']} == {
        SRC_A: ('2026-10-27', 'loaded_at_field'), SRC_B: ('5', 'loaded_at_query'), SRC_C: (None, 'unknown')}


def test_plan_request_marks_missing_sql_as_error(tmp_path):
    facts = [f for f in _facts(tmp_path) if f.unique_id == 'model.p.fct']
    body = _request(tmp_path, facts=facts, sql_facts={})
    assert body['nodes'][0]['sql_sha256'] is None and body['nodes'][0]['errors'] == ['no_compiled_sql']


def test_plan_request_flags_unparsed_and_select_star_on_ref(tmp_path):
    facts = [f for f in _facts(tmp_path) if f.unique_id == 'model.p.fct']
    body = _request(tmp_path, facts=facts, sql_facts={'model.p.fct': SqlFacts('h', False, True)})
    assert sorted(body['nodes'][0]['flags']) == ['select_star_on_ref', 'unparsed']
    body = _request(tmp_path, facts=facts, sql_facts={'model.p.fct': SqlFacts('h', False, False)})
    assert sorted(body['nodes'][0]['flags']) == ['select_star_on_ref', 'unparsed']  # star unknown without a parse
    lone = [f for f in _facts(tmp_path) if f.unique_id == 'model.p.stg']
    body = _request(tmp_path, facts=lone, sql_facts={'model.p.stg': SqlFacts('h', True, True)})
    assert body['nodes'][0]['flags'] == []  # star over a source, not a ref


def test_plan_request_full_refresh_flag(tmp_path):
    body = _request(tmp_path, invocation=dict(command='build', args=['--full-refresh'], cause='t', full_refresh=True))
    flagged = {n['unique_id'] for n in body['nodes'] if 'full_refresh' in n['flags']}
    # Seeds are dropped and reloaded under --full-refresh (the way to apply column_types changes to an unchanged
    # CSV), so they must build too; tests follow their model.
    assert flagged == {n['unique_id'] for n in body['nodes'] if n['resource_type'] in ('model', 'seed', 'snapshot')}
    assert 'full_refresh' not in body['invocation']


def test_skipped_ids_and_names(tmp_path):
    facts = _facts(tmp_path)
    response = dict(nodes=[dict(unique_id='model.p.fct', action='skip', reason='skip'),
                           dict(unique_id='test.p.not_null_fct_id', action='skip', reason='skip'),
                           dict(unique_id='seed.p.countries', action='skip', reason='skip'),
                           dict(unique_id='model.p.stg', action='build', reason='sql_changed')])
    ids = skipped_ids(response)
    assert ids == ['model.p.fct', 'test.p.not_null_fct_id', 'seed.p.countries']
    assert exclusions_for(ids, facts) == ['path:models/fct.sql', 'path:seeds/countries.csv']


def test_cut_tests_splits_by_plan_action_and_needs_an_excluded_parent(tmp_path):
    from bnr_build_state.planning import cut_tests, test_selectors
    facts = _facts(tmp_path)
    plan = dict(nodes=[dict(unique_id='test.p.relationships_fct_stg', action='build'), dict(unique_id='test.p.not_null_fct_id', action='skip'),
                       dict(unique_id='model.p.fct', action='skip')])
    done = {uid for uid in SELECTED if not uid.startswith('test.')}
    run_, reused = cut_tests(plan, facts, done, {'model.p.fct'})
    assert [f.unique_id for f in run_] == ['test.p.relationships_fct_stg'] and [f.unique_id for f in reused] == ['test.p.not_null_fct_id']
    assert cut_tests(plan, facts, done, set()) == ([], [])  # nothing excluded: a missing test is dbt's omission
    assert cut_tests(plan, facts, done | {'test.p.relationships_fct_stg'}, {'model.p.fct'})[0] == []  # it ran
    assert test_selectors(run_) == ['p.relationships_fct_stg']
    bare = [type('F', (), dict(fqn=(), name='singular'))()]
    assert test_selectors(bare) == ['singular']


def test_report_request_maps_statuses_and_adds_reused():
    results = run_results({'model.p.stg': 'success', 'test.p.not_null_fct_id': 'pass', 'model.p.hooked': 'error',
                           'model.p.py': 'skipped', 'snapshot.p.snap': 'warn', 'seed.p.countries': 'runtime error'})
    body = report_request('pl_1', results, ['model.p.fct'], {'model.p.stg': dict(last_ddl='x')})
    statuses = {r['unique_id']: r['status'] for r in body['results']}
    assert statuses == {'model.p.stg': 'success', 'test.p.not_null_fct_id': 'success', 'model.p.hooked': 'error',
                        'model.p.py': 'skipped', 'snapshot.p.snap': 'success', 'seed.p.countries': 'error', 'model.p.fct': 'reused'}
    first = body['results'][0]
    assert first['started_at'] == '2026-10-27T00:00:01Z' and first['completed_at'] == '2026-10-27T00:00:02Z'
    assert body['observations'] == [dict(unique_id='model.p.stg', values=dict(last_ddl='x'))]
    assert body['plan_id'] == 'pl_1'


def test_unknown_status_is_reported_as_error():
    body = report_request('pl', run_results({'model.p.stg': 'mystery'}), [], {})
    assert body['results'][0]['status'] == 'error'


def test_partial_success_is_reported_as_error():
    # A microbatch model with failed batches is not built: recording success would let the next run skip it.
    body = report_request('pl', run_results({'model.p.fct': 'partial success'}), [], {})
    assert body['results'][0]['status'] == 'error'


def test_summary_counts():
    plan = dict(plan_id='pl', summary=dict(build=2, skip=1, undetermined=1))
    report = dict(results=[dict(status='success'), dict(status='reused'), dict(status='error')])
    assert summary(plan, report) == dict(built=1, reused=1, errors=1, undetermined=1, plan_id='pl')


def test_seed_with_path_checksum_is_undetermined(tmp_path):
    import copy
    write_project(tmp_path)
    manifest = copy.deepcopy(MANIFEST)
    manifest['nodes']['seed.p.countries']['checksum'] = dict(name='path', checksum='seeds/big.csv')
    facts = [f for f in a.facts(manifest, SELECTED, tmp_path / 'target', 'p') if f.unique_id == 'seed.p.countries']
    seed = _request(tmp_path, facts=facts, sql_facts={})['nodes'][0]
    assert seed['sql_sha256'] is None and seed['errors'] == ['seed_checksum_unavailable']
    ok = [f for f in _facts(tmp_path) if f.unique_id == 'seed.p.countries']
    seed = _request(tmp_path, facts=ok, sql_facts={})['nodes'][0]
    assert seed['sql_sha256'] == 'c0ffee' and seed['errors'] == []


def test_exclusions_use_paths_and_skip_nodes_without_one(tmp_path):
    import dataclasses
    facts = _facts(tmp_path)
    ids = ['model.p.fct', 'seed.p.countries']
    assert exclusions_for(ids, facts) == ['path:models/fct.sql', 'path:seeds/countries.csv']
    bare = [dataclasses.replace(f, original_file_path=None) for f in facts]
    assert exclusions_for(ids, bare) == []


def test_snapshots_are_never_excluded(tmp_path):
    facts = _facts(tmp_path)
    assert exclusions_for(['snapshot.p.snap', 'model.p.fct'], facts) == ['path:models/fct.sql']


def test_a_path_shared_with_a_node_that_builds_is_not_excluded(tmp_path):
    import dataclasses
    facts = [dataclasses.replace(f, original_file_path='models/shared.sql') if f.unique_id in ('model.p.fct', 'model.p.stg') else f
             for f in _facts(tmp_path)]
    assert exclusions_for(['model.p.fct'], facts) == []
    assert exclusions_for(['model.p.fct', 'model.p.stg'], facts) == ['path:models/shared.sql']


def _one(body, uid):
    return next(n for n in body['nodes'] if n['unique_id'] == uid)


def test_volatile_sql_is_flagged_unless_the_node_opts_out(tmp_path):
    facts = _facts(tmp_path)
    sql_facts = _sql_facts(facts)
    sql_facts['model.p.fct'] = SqlFacts('h', True, False, volatile=True)
    body = _request(tmp_path, facts=facts, sql_facts=sql_facts)
    assert 'volatile' in _one(body, 'model.p.fct')['flags'] and 'volatile' not in _one(body, 'model.p.stg')['flags']
    # config(bnr_state={"volatile": false}): a load timestamp that may lag is accepted; true forces the flag on.
    opted = [f if f.unique_id != 'model.p.fct' else a.NodeFacts(**{**f.__dict__, 'bnr_state': {'volatile': False}}) for f in facts]
    assert 'volatile' not in _one(_request(tmp_path, facts=opted, sql_facts=sql_facts), 'model.p.fct')['flags']
    forced = [f if f.unique_id != 'model.p.stg' else a.NodeFacts(**{**f.__dict__, 'bnr_state': {'volatile': True}}) for f in facts]
    assert 'volatile' in _one(_request(tmp_path, facts=forced, sql_facts=sql_facts), 'model.p.stg')['flags']


def test_bnr_state_always_build_and_lag_tolerance_reach_the_request(tmp_path):
    facts = _facts(tmp_path)
    tuned = [f if f.unique_id != 'model.p.fct' else a.NodeFacts(**{**f.__dict__, 'bnr_state': {'always_build': True, 'lag_tolerance_seconds': 900}})
             for f in facts]
    node = _one(_request(tmp_path, facts=tuned, sql_facts=_sql_facts(facts)), 'model.p.fct')
    assert 'always_build' in node['flags'] and node['lag_tolerance_seconds'] == 900
    assert 'lag_tolerance_seconds' not in _one(_request(tmp_path), 'model.p.fct')
    bad = [f if f.unique_id != 'model.p.fct' else a.NodeFacts(**{**f.__dict__, 'bnr_state': {'lag_tolerance_seconds': '15m', 'always_build': 'yes'}})
           for f in facts]
    node = _one(_request(tmp_path, facts=bad, sql_facts=_sql_facts(facts)), 'model.p.fct')
    assert 'lag_tolerance_seconds' not in node and 'always_build' not in node['flags']


def test_dbts_own_reused_and_no_op_statuses_are_not_errors():
    """dbt-core's NodeStatus has `reused` (its own cache hit) and `no-op`; both leave the relation as it was."""
    body = report_request('pl', run_results({'model.p.stg': 'reused', 'model.p.fct': 'no-op'}), [], {})
    assert {r['unique_id']: r['status'] for r in body['results']} == {'model.p.stg': 'reused', 'model.p.fct': 'skipped'}


def test_folded_ephemerals_change_the_readers_hash_and_carry_their_flags():
    from bnr_build_state.planning import fold_ephemerals
    eph = a.NodeFacts('model.p.e', 'e', 'model', 'ephemeral', (SRC_A,), 'select * from D.RAW.A', None, (), None)
    reader = a.NodeFacts('model.p.r', 'r', 'model', 'table', (SRC_A,), 'select id from __dbt__cte__e', None, (), None)
    own = {'model.p.r': analyze(reader.sql, 'snowflake'), 'model.p.e': analyze(eph.sql, 'snowflake')}
    folded = fold_ephemerals(own, {'model.p.r': [eph]})
    assert folded['model.p.r'].sha256 != own['model.p.r'].sha256 and folded['model.p.r'].select_star  # the star in the ephemeral
    changed = dict(own, **{'model.p.e': analyze('select * from D.RAW.A where x', 'snowflake')})
    assert fold_ephemerals(changed, {'model.p.r': [eph]})['model.p.r'].sha256 != folded['model.p.r'].sha256
    assert fold_ephemerals(own, {})['model.p.r'] == own['model.p.r']
    # Fusion compiled_code lacks the injected CTE, so an ephemeral change must still reach the reader: the hash does it.
    body = plan_request(account_id=1, project='p', platform='snowflake', locator='l', database='D', schema='S',
                        engine={}, invocation=dict(command='build', args=[], cause='t'), run_id=None, facts=[reader], sql_facts=own,
                        stamps={SRC_A: ('1', 'provider')}, present={}, folded={'model.p.r': [eph]})
    node = body['nodes'][0]
    assert node['sql_sha256'] == folded['model.p.r'].sha256 and 'select_star_on_ref' not in node['flags']  # the star is over a source


def test_volatile_applies_only_to_materializations_that_store_rows():
    """A view or ephemeral stores nothing and a dynamic table is refreshed by the warehouse, so a clock in their SQL
    does not make a rebuild necessary; a table or incremental rewrites rows with it."""
    base = a.NodeFacts('model.p.x', 'x', 'model', 'view', (SRC_A,), 'select current_date as d from D.RAW.A', None, (), None)
    sql_facts = {'model.p.x': analyze(base.sql, 'snowflake')}
    assert sql_facts['model.p.x'].volatile
    for materialized, expected in (('view', False), ('ephemeral', False), ('dynamic_table', False), ('materialized_view', False),
                                   ('table', True), ('incremental', True)):
        fact = a.NodeFacts(**{**base.__dict__, 'materialized': materialized})
        body = plan_request(account_id=1, project='p', platform='snowflake', locator='l', database='D', schema='S', engine={},
                            invocation=dict(command='build', args=[], cause='t'), run_id=None, facts=[fact], sql_facts=sql_facts,
                            stamps={SRC_A: ('1', 'provider')}, present={})
        assert ('volatile' in body['nodes'][0]['flags']) is expected, materialized
    # The run's start time rendered into the SQL counts the same way (artifacts.neutralize_run_timestamps flags it).
    stamped = a.NodeFacts(**{**base.__dict__, 'materialized': 'table', 'sql': 'select 1 as d from D.RAW.A', 'flags': ('run_timestamp',)})
    plain = {'model.p.x': analyze(stamped.sql, 'snowflake')}
    body = plan_request(account_id=1, project='p', platform='snowflake', locator='l', database='D', schema='S', engine={},
                        invocation=dict(command='build', args=[], cause='t'), run_id=None, facts=[stamped], sql_facts=plain,
                        stamps={SRC_A: ('1', 'provider')}, present={})
    assert {'run_timestamp', 'volatile'} <= set(body['nodes'][0]['flags'])
    view = a.NodeFacts(**{**stamped.__dict__, 'materialized': 'view'})
    body = plan_request(account_id=1, project='p', platform='snowflake', locator='l', database='D', schema='S', engine={},
                        invocation=dict(command='build', args=[], cause='t'), run_id=None, facts=[view], sql_facts=plain,
                        stamps={SRC_A: ('1', 'provider')}, present={})
    assert 'volatile' not in body['nodes'][0]['flags']


def test_tests_never_carry_select_star_on_ref():
    model = a.NodeFacts('model.p.m', 'm', 'model', 'table', ('model.p.src',), 'select * from D.S.src', None, (), None)
    test = a.NodeFacts('test.p.t', 't', 'test', 'test', ('model.p.m',), 'select * from D.S.m where x is null', None, (), None)
    sql_facts = {f.unique_id: analyze(f.sql, 'snowflake') for f in (model, test)}
    body = plan_request(account_id=1, project='p', platform='snowflake', locator='l', database='D', schema='S', engine={},
                        invocation=dict(command='build', args=[], cause='t'), run_id=None, facts=[model, test], sql_facts=sql_facts,
                        stamps={}, present={})
    flags = {n['unique_id']: n['flags'] for n in body['nodes']}
    assert 'select_star_on_ref' in flags['model.p.m'] and 'select_star_on_ref' not in flags['test.p.t']


def test_content_hash_scope_targets_the_shapes_that_can_change_content_silently():
    from bnr_build_state.artifacts import NodeFacts
    from bnr_build_state.hashing import SqlFacts
    from bnr_build_state.planning import content_hash_scope

    def fact(materialized='table', strategy=None, bnr_state=None):
        return NodeFacts('model.p.a', 'a', 'model', materialized, (), 'select 1', None, (), None, bnr_state=bnr_state, incremental_strategy=strategy)

    plain = SqlFacts('h', True, False); unordered = SqlFacts('h', True, False, unordered=True)
    assert content_hash_scope(fact(), plain) == 'default'
    assert content_hash_scope(fact('incremental', 'append'), plain) == 'default'
    assert content_hash_scope(fact('incremental', 'merge'), plain) == 'force'
    assert content_hash_scope(fact('incremental', 'delete+insert'), plain) == 'force'
    assert content_hash_scope(fact('table'), unordered) == 'force'
    assert content_hash_scope(fact('view'), unordered) == 'default'  # a view stores no rows to hash
    assert content_hash_scope(fact('incremental', 'merge', {'content_hash': False}), unordered) == 'skip'
    assert content_hash_scope(fact(), None) == 'default'
    assert content_hash_scope(fact(bnr_state={'content_hash': True}), plain) == 'force'

