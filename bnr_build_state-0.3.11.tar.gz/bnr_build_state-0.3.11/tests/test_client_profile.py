import json

import pytest

from bnr_build_state.profile import ProfileError, read_profile, render_env_vars
from client_fixtures import write_project


def test_env_var_rendering_with_and_without_default():
    text = "a: {{ env_var('X') }}\nb: {{ env_var(\"Y\", 'dflt') }}\nc: {{ var('z') }}"
    assert render_env_vars(text, {'X': '1'}) == "a: 1\nb: dflt\nc: {{ var('z') }}"


def test_missing_env_var_without_default_is_an_error():
    with pytest.raises(ProfileError, match='X'):
        render_env_vars("a: {{ env_var('X') }}", {})


def test_read_profile_from_project_dir(tmp_path):
    write_project(tmp_path)
    profile = read_profile(tmp_path, env={'PW': 'secret'})
    assert (profile.name, profile.target, profile.adapter) == ('p', 'dev', 'snowflake')
    assert profile.output['password'] == 'secret' and profile.output['database'] == 'D'


def test_profiles_dir_argument_then_env_then_project_then_home(tmp_path, monkeypatch):
    write_project(tmp_path)
    other = tmp_path / 'elsewhere'
    other.mkdir()
    (other / 'profiles.yml').write_text('{"p": {"target": "prod", "outputs": {"prod": {"type": "postgres", "host": "h"}}}}')
    assert read_profile(tmp_path, profiles_dir=str(other), env={'PW': ''}).target == 'prod'
    assert read_profile(tmp_path, env={'PW': '', 'DBT_PROFILES_DIR': str(other)}).target == 'prod'
    assert read_profile(tmp_path, env={'PW': ''}).target == 'dev'
    (tmp_path / 'profiles.yml').unlink()
    home = tmp_path / 'home'
    (home / '.dbt').mkdir(parents=True)
    (home / '.dbt' / 'profiles.yml').write_text('{"p": {"target": "home", "outputs": {"home": {"type": "duckdb", "path": "x"}}}}')
    monkeypatch.setattr('pathlib.Path.home', lambda: home)
    assert read_profile(tmp_path, env={}).target == 'home'


def test_target_override_and_unknown_target(tmp_path):
    write_project(tmp_path)
    with pytest.raises(ProfileError, match='nope'):
        read_profile(tmp_path, target='nope', env={'PW': ''})
    assert read_profile(tmp_path, env={'PW': '', 'DBT_TARGET': 'dev'}).target == 'dev'


def test_missing_profile_name_is_an_error(tmp_path):
    write_project(tmp_path)
    (tmp_path / 'profiles.yml').write_text('{"other": {"target": "dev", "outputs": {"dev": {"type": "x"}}}}')
    with pytest.raises(ProfileError, match="profile 'p'"):
        read_profile(tmp_path, env={})


def test_unset_env_var_in_other_target_is_ignored(tmp_path):
    (tmp_path / 'dbt_project.yml').write_text('name: p\nprofile: p\n')
    (tmp_path / 'profiles.yml').write_text(json.dumps({'p': {'target': 'dev', 'outputs': {
        'dev': {'type': 'duckdb', 'path': 'x'},
        'prod': {'type': 'postgres', 'host': 'h', 'password': "{{ env_var('NOPE') }}"},
    }}}))
    profile = read_profile(tmp_path, env={})
    assert profile.target == 'dev' and profile.adapter == 'duckdb'


def test_secret_with_hash_and_newline_survives(tmp_path):
    write_project(tmp_path)
    profile = read_profile(tmp_path, env={'PW': 'a#b\nc'})
    assert profile.output['password'] == 'a#b\nc'


def test_missing_project_file_is_profile_error(tmp_path):
    with pytest.raises(ProfileError, match='dbt_project.yml'):
        read_profile(tmp_path, env={})
