# bnr-build-state

Wraps a dbt invocation so unchanged models are skipped using the Branch & Row state API.

    pip install bnr-build-state[snowflake]
    export BNR_URL=https://api.example.com BNR_TOKEN=... BNR_ACCOUNT_ID=1
    bnr dbt build --selector workday_refresh

Steps: `dbt compile` with the same selection, hash compiled SQL, fetch source stamps
through the project profile, `POST /v1/state/plan`, run the original command (Enforce
mode appends `--exclude` for skipped nodes), `POST /v1/state/report`, exit with dbt's
exit code. If the state API is unreachable the original command runs unchanged.

Enforce skips a node only after one of its planned skips was checked against a real rebuild (Shadow rebuilds every
planned skip; Enforce builds a never-checked node once more, reason `unverified`) and the rebuilt relation matched the
stored row count, column signature and, on Snowflake, the content hash (`HASH_AGG(*)`) of base tables up to
`BNR_CONTENT_HASH_MAX_ROWS` rows (200,000; 0 turns it off). Models that can change content without changing their row
count are hashed regardless of that cap, up to `BNR_CONTENT_HASH_FORCE_MAX_ROWS` (5,000,000): incrementals with a
rewriting strategy (`merge`, `delete+insert`, `insert_overwrite`, `replace_where`) and tables whose SQL uses an unordered
aggregate (`any_value`, `listagg`/`array_agg`/`object_agg` without an ORDER BY). `config(bnr_state={"content_hash":
true})` forces the hash for a model, `false` turns it off. The report carries those observations in both modes. A test
has no relation to observe: its planned skip is verified when the rerun passes and contradicted when it fails.

Environment: `BNR_URL`, `BNR_TOKEN`, `BNR_ACCOUNT_ID` (required); `BNR_RUN_ID`,
`BNR_CAUSE`, `BNR_DBT_BIN`, `BNR_STATE_MODE_OVERRIDE=off` (optional).

The run ends with one summary line, `[bnr] mode shadow: built 3558, reused 0, errors 0, undetermined 0,
disagreements 1`: the first four counts are the client's, `disagreements` is the service's answer to the report
(planned skips the rebuild contradicted), absent when the report could not be sent.
`bnr state explain <plan_id> [-s node]` prints the stored decision per node.

Always built, whatever the state says: Python models, snapshots, custom materializations, nodes with hooks, `select *`
over a `ref()`, `--full-refresh`, and tables or incremental models whose SQL reads the clock, a random source or the
session (`current_date`, `current_timestamp`, `sysdate`, `random`, `uuid_string`, `current_user`, ...) or renders the
run's start time (`run_started_at`, `var('load_datetime')`): the same SQL over unchanged inputs stores other rows
tomorrow, and no change signal can show that. A view, ephemeral, dynamic table or materialized view stores no rows of
dbt's own, so only its definition counts. The run's start time rendered into any SQL is replaced by a token before
hashing, so a template that stamps `LOAD_DATETIME` does not read as new SQL every run. An empty selection
(`state:modified+` with nothing modified) plans nothing and records nothing. Per node, `config(bnr_state={...})` takes
`always_build: true`, `volatile: false` (accept that a clock-derived column, say a load timestamp, lags while the node
is reused), `volatile: true`, and `lag_tolerance_seconds: N`. Put it under `meta` on dbt Fusion
(`config(meta={"bnr_state": {...}})`, or `+meta: {bnr_state: {...}}` for a folder in dbt_project.yml): Fusion rejects
unrecognized config keys in dbt_project.yml; dbt-core accepts either place.

A node that reads a selected view also carries the view's own dependencies, so a rebuild of the table under the view,
or new data in the view's sources, reaches the reader although the view itself skips. Selected ephemeral models are not
planned (dbt never builds them): each is folded into the models that read it, which
carry its sources and a hash that covers its SQL. Unselected view and ephemeral parents are stamped by lineage: the stamps of the sources and
tables they read, through further views, plus each definition's checksum. Lineage that reaches a
node selected in the same invocation stays unknown, so its dependents build. A `select *` forces
a build only when it expands a relation, not when it reads the statement's own CTEs or subqueries.

dbt Projects on Snowflake: where dbt runs inside Snowflake (`EXECUTE DBT PROJECT`), call
`bnr_build_state.providers.snowflake_project.run_project(args, env, connection, '<DB.SCHEMA.OBJECT>',
database=..., schema=..., locator=..., warehouse=...)` from the script that runs it. Each dbt step becomes an
`EXECUTE DBT PROJECT` on that connection and its artifacts are downloaded from the run's results folder. It adds a
compile and a `list` step to every run; each is a fresh Snowflake sandbox, so most of their time is startup. bnr's
own steps never write `target/` back (`WRITEBACK = FALSE`); pass `writeback=False` to do the same for the build.
Where the time goes and the options not yet taken (dropping `list`, pre-warm, Fusion in the caller's container):
`docs/research/2026-11-07-snowflake-dbt-project-startup.md`.

Snowflake metadata queries (stamps, catalog reads, Shadow observations) are cancelled after 600 seconds
(`BNR_QUERY_TIMEOUT_SECONDS`); the stamps they would have produced stay unknown, so those models build. dbt's own
queries never carry this limit.

Warehouse adapters: `snowflake`, `postgres` (including pg_duckdb), `duckdb` (including
MotherDuck; data changes need `loaded_at_field`). Install the matching extra.

Postgres stamps read `pg_stat_user_tables`, whose counters a writing backend flushes when it goes
idle and at most once per second (`PGSTAT_MIN_INTERVAL`). A write committed within about a second
before `bnr dbt` reads its stamps is therefore seen one run late: usually one extra rebuild, and in
the narrow case of a write landing just before a plan whose build never reads it, a skip corrected
by the next run. There is no cross-session force flush; declare `loaded_at_field` on sources where
that window matters. Snowflake Iceberg tables held in an external catalog (Glue, Open Catalog)
have no Snowflake commit signal and stamp as unknown unless they declare `loaded_at_field`.

dbt is a trademark of dbt Labs, LLC.
