"""Read dbt artifacts (manifest.json, run_results.json) into small typed facts.

No warehouse, no network. Works for dbt Core 1.x and dbt Fusion 2.x artifacts: both
carry `compiled_code` per node; when it is absent the compiled file under
`<target>/compiled/<project>/<original_file_path>` is read instead.
"""
from dataclasses import dataclass, replace
from datetime import datetime
import hashlib
import json
import logging
from pathlib import Path
import re

import yaml

log = logging.getLogger(__name__)

STANDARD_MATERIALIZATIONS = frozenset({'view', 'table', 'incremental', 'ephemeral', 'seed', 'snapshot', 'test', 'unit',
                                       'materialized_view', 'dynamic_table'})
MATERIALIZED_TYPES = frozenset({'model', 'seed', 'snapshot'})
# Config keys left out of `config_sha256`. dbt's `state:modified.configs` compares `unrendered_config` minus the fields
# marked CompareBehavior.Exclude (dbt-core 1.12 NodeAndTestConfig: alias, schema, database, tags, group; the docs also
# name meta). The relation keys are covered by target presence, `materialized` is its own planner rule, hooks already
# force a build, `docs`/`meta`/`enabled` are metadata, and `bnr_state` is this client's own setting.
CONFIG_EXCLUDED = frozenset({'alias', 'schema', 'database', 'tags', 'group', 'meta', 'docs', 'enabled', 'materialized',
                             'pre-hook', 'post-hook', 'pre_hook', 'post_hook', 'bnr_state'})


@dataclass(frozen=True)
class Relation:
    database: str | None
    schema: str
    identifier: str
    quoted: str  # the manifest's relation_name, used verbatim in SQL


@dataclass(frozen=True)
class NodeFacts:
    unique_id: str
    name: str
    resource_type: str
    materialized: str | None
    depends_on: tuple[str, ...]
    sql: str | None
    checksum: str | None
    flags: tuple[str, ...]
    relation: Relation | None
    fqn: tuple[str, ...] = ()
    original_file_path: str | None = None
    config_sha256: str | None = None
    bnr_state: dict | None = None  # config(bnr_state={...}): always_build, volatile, lag_tolerance_seconds
    incremental_strategy: str | None = None  # merge / delete+insert rewrite rows in place; append only adds


def bnr_state(node):
    """This client's own node settings. dbt-core accepts a custom config key (`config(bnr_state={...})`, `+bnr_state:`),
    but dbt Fusion rejects unrecognized config keys in dbt_project.yml (SerializationError dbt1013, seen on BCS
    2026-11-08), so the settings are also read from `meta` (`config(meta={"bnr_state": {...}})`, `+meta:`), which both
    engines accept and both write to the node's config and top-level `meta`. A key under config wins over meta; anything
    that is not a mapping is ignored."""
    config = node.get('config') or {}
    for value in (config.get('bnr_state'), (config.get('meta') or {}).get('bnr_state'), (node.get('meta') or {}).get('bnr_state')):
        if isinstance(value, dict):
            return dict(value)
    return {}


def config_sha256(node):
    """sha256 over the node's `unrendered_config` minus CONFIG_EXCLUDED, canonical JSON; None when the manifest
    carries no unrendered config, which the planner reads as unknown (never a rebuild)."""
    config = node.get('unrendered_config')
    if not isinstance(config, dict):
        return None
    kept = {k: v for k, v in config.items() if k not in CONFIG_EXCLUDED}
    text = json.dumps(kept, sort_keys=True, separators=(',', ':'), default=str)
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text())


def selected_ids(run_results):
    return [r['unique_id'] for r in (run_results.get('results') or []) if isinstance(r.get('unique_id'), str)]


def engine_of(run_results):
    version = str((run_results.get('metadata') or {}).get('dbt_version') or '')
    return dict(family='fusion' if version.startswith('2.') else 'core', version=version)


def project_name(project_dir, manifest=None):
    """dbt_project.yml's name; without a local project file (a project run elsewhere), the manifest's."""
    path = Path(project_dir) / 'dbt_project.yml'
    if not path.is_file() and manifest is not None:
        name = (manifest.get('metadata') or {}).get('project_name')
        if name:
            return str(name)
    doc = yaml.safe_load(path.read_text()) or {}
    return str(doc.get('name') or Path(project_dir).resolve().name)


def _project_target_path(project_dir):
    try:
        doc = yaml.safe_load((Path(project_dir) / 'dbt_project.yml').read_text()) or {}
    except (OSError, yaml.YAMLError):
        return None
    value = doc.get('target-path') if isinstance(doc, dict) else None
    return str(value) if value else None


def target_dir(project_dir, override, env):
    chosen = override or env.get('DBT_TARGET_PATH') or _project_target_path(project_dir) or 'target'
    path = Path(chosen)
    return path if path.is_absolute() else Path(project_dir) / path


def compiled_sql(node, target, project):
    code = node.get('compiled_code')
    if isinstance(code, str) and code.strip():
        return code
    if node.get('language', 'sql') != 'sql':
        return None
    original = node.get('original_file_path')
    if not original:
        return None
    path = Path(target) / 'compiled' / project / original
    return path.read_text() if path.is_file() else None


def node_flags(node):
    config = node.get('config') or {}
    materialized = config.get('materialized')
    flags = []
    if node.get('language') == 'python':
        flags.append('python')
    if node.get('resource_type') == 'snapshot':
        flags.append('snapshot')
    if materialized == 'semantic_view':
        flags.append('semantic_view')
    elif materialized and materialized not in STANDARD_MATERIALIZATIONS and node.get('resource_type') == 'model':
        flags.append('custom_materialization')
    if config.get('pre-hook') or config.get('post-hook'):
        flags.append('has_hooks')
    return tuple(flags)


def relation_of(node):
    quoted = node.get('relation_name')
    if not quoted or node.get('resource_type') not in MATERIALIZED_TYPES:
        return None
    if (node.get('config') or {}).get('materialized') == 'ephemeral':
        return None
    return Relation(node.get('database'), node['schema'], node.get('alias') or node['name'], quoted)


def facts(manifest, unique_ids, target, project):
    nodes = manifest.get('nodes') or {}
    out = []
    for uid in unique_ids:
        node = nodes.get(uid)
        if node is None:
            continue
        resource_type = node['resource_type']
        sql = compiled_sql(node, target, project) if resource_type != 'seed' else None
        checksum = None
        if resource_type == 'seed':
            recorded = node.get('checksum') or {}
            # dbt records a path-based checksum for large seeds; only a content hash can detect edits.
            checksum = recorded.get('checksum') if recorded.get('name') == 'sha256' else None
        out.append(NodeFacts(uid, node['name'], resource_type, (node.get('config') or {}).get('materialized'),
                             tuple((node.get('depends_on') or {}).get('nodes') or []), sql, checksum,
                             node_flags(node), relation_of(node), tuple(node.get('fqn') or ()),
                             node.get('original_file_path') or None, config_sha256(node), bnr_state(node),
                             (node.get('config') or {}).get('incremental_strategy')))
    return out


def sources_for(manifest, node_facts):
    sources = manifest.get('sources') or {}
    wanted = {dep for f in node_facts for dep in f.depends_on if dep.startswith('source.')}
    return {uid: sources[uid] for uid in wanted if uid in sources}


_SOURCE_REF = re.compile(r"""\{\{\s*source\(\s*['"]([^'"]+)['"]\s*,\s*['"]([^'"]+)['"]\s*\)\s*\}\}""")


def render_source_refs(text, manifest):
    """`{{ source('a', 'b') }}` in a loaded_at_query, replaced by that source's relation name; dbt keeps the query
    unrendered in the manifest and renders it at freshness time. None when anything else needs rendering."""
    by_name = {(s.get('source_name'), s.get('name')): s.get('relation_name') for s in ((manifest or {}).get('sources') or {}).values()}

    def relation(match):
        return by_name.get((match.group(1), match.group(2))) or match.group(0)

    rendered = _SOURCE_REF.sub(relation, text)
    return None if '{{' in rendered or '{%' in rendered else rendered


def loaded_at(source, manifest=None):
    """(kind, scalar query) from the source's loaded_at_query or loaded_at_field, read at the top level (dbt-core writes
    both there) or under `config` (where dbt 1.10+ declares them), the query taking precedence as in dbt. A query that
    cannot be rendered here is dropped with a warning: the source is then stamped like one with no declaration."""
    config = source.get('config') if isinstance(source.get('config'), dict) else {}
    query = source.get('loaded_at_query') or config.get('loaded_at_query')
    if query:
        rendered = render_source_refs(query, manifest) if '{{' in query or '{%' in query else query
        if rendered is None:
            log.warning('build-state cannot render the loaded_at_query of %s, stamping it without it: %s', source.get('unique_id'), query)
            return None
        return 'loaded_at_query', rendered
    field = source.get('loaded_at_field') or config.get('loaded_at_field')
    if field:
        return 'loaded_at_field', f'select max({field}) from {source["relation_name"]}'
    return None


def inline_ephemerals(node_facts):
    """Fold selected ephemeral models into the nodes that read them.

    dbt never builds an ephemeral: its SQL is injected into each reader as a CTE, so it never appears in run results,
    its state row never exists and, planned as a node, it stays `no_prior_state` and makes every reader
    `upstream_built` forever. Here each ephemeral is dropped from the selection and its `depends_on` spliced into its
    readers (through chains of ephemerals), so the readers' stamps cover what the ephemeral read. The ephemeral's own
    SQL is folded into the readers' hash by `planning.plan_request` (Fusion's manifest `compiled_code` does not carry
    the injected CTEs, so the reader's own SQL alone would miss a change to the ephemeral).

    Returns (remaining facts, {reader unique_id: [ephemeral facts it reads, transitively]}).
    """
    ephemeral = {f.unique_id: f for f in node_facts if f.materialized == 'ephemeral'}
    if not ephemeral:
        return list(node_facts), {}

    def expand(uid, seen):
        """Non-ephemeral dependencies and the ephemerals passed through, reading `uid`'s ephemeral dependencies."""
        deps, passed = [], []
        for dep in ephemeral[uid].depends_on:
            if dep in ephemeral and dep not in seen:
                inner_deps, inner_passed = expand(dep, seen | {dep})
                deps.extend(inner_deps)
                passed.extend([ephemeral[dep]] + inner_passed)
            elif dep not in ephemeral:
                deps.append(dep)
        return deps, passed

    out, folded = [], {}
    for fact in node_facts:
        if fact.unique_id in ephemeral:
            continue
        if not any(dep in ephemeral for dep in fact.depends_on):
            out.append(fact)
            continue
        deps, passed = [], []
        for dep in fact.depends_on:
            if dep in ephemeral:
                inner_deps, inner_passed = expand(dep, {dep})
                deps.extend(inner_deps)
                passed.extend([ephemeral[dep]] + inner_passed)
            else:
                deps.append(dep)
        folded[fact.unique_id] = list({e.unique_id: e for e in passed}.values())
        out.append(replace(fact, depends_on=tuple(dict.fromkeys(deps))))
    return out, folded


RUN_TIMESTAMP_TOKEN = '<run_started_at>'
_ISO_INSTANT = re.compile(r'(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})')  # the fraction and zone are not needed


def run_started_at(manifest, run_results=None):
    """The invocation's start instant (dbt's `run_started_at`), from `metadata.invocation_started_at` of the manifest
    (dbt-core 1.9+ and Fusion write it) or of run_results; None when neither carries it."""
    for doc in (manifest, run_results or {}):
        text = ((doc or {}).get('metadata') or {}).get('invocation_started_at')
        if isinstance(text, str) and text:
            match = _ISO_INSTANT.match(text)
            return datetime(*map(int, match.groups())) if match else None
    return None


def run_timestamp_pattern(started):
    """Matches every rendering of `started` a template puts into SQL: `2026-11-08 04:02:16.075569`, with a `T`, with
    any fraction, with `+00:00` or `Z`, or seconds only."""
    base = re.escape(started.strftime('%Y-%m-%d')) + r'[ T]' + re.escape(started.strftime('%H:%M:%S'))
    return re.compile(base + r'(?:\.\d{1,9})?(?:\s*(?:\+00:00|Z|UTC))?')


def neutralize_run_timestamps(node_facts, started):
    """Replace the run's start instant in each node's compiled SQL with RUN_TIMESTAMP_TOKEN and flag the node
    `run_timestamp`. A template that renders `run_started_at` (`var('load_datetime', run_started_at)`, a
    `TO_TIMESTAMP('...') AS LOAD_DATETIME` column) makes the compiled SQL differ on every run although nothing about
    the model changed; the token keeps the hash stable, and the flag lets planning treat the stored rows as
    time-dependent where that matters (a table rewrites every row with it; a view or snapshot does not)."""
    if started is None:
        return list(node_facts)
    pattern = run_timestamp_pattern(started)
    out = []
    for fact in node_facts:
        if fact.sql and pattern.search(fact.sql):
            out.append(replace(fact, sql=pattern.sub(RUN_TIMESTAMP_TOKEN, fact.sql), flags=(*fact.flags, 'run_timestamp')))
        else:
            out.append(fact)
    return out


READS_THROUGH = ('view', 'ephemeral')


def expand_through_views(node_facts):
    """Give every node the dependencies of the selected views it reads, transitively through further views.

    A view stores nothing: when the table under it is rebuilt the view is not (it reads through), so a planner that
    looks only at a node's direct dependencies would let the view's readers skip while their data changed. With the
    view's own dependencies spliced into each reader, the reader follows the table (`upstream_built`) and the view's
    sources (stamps) exactly as if it read them itself; the view stays a dependency too, so a change to its SQL still
    reaches the reader."""
    by_id = {f.unique_id: f for f in node_facts}
    cache = {}

    def through(uid, seen):
        if uid in cache:
            return cache[uid]
        fact = by_id.get(uid)
        if fact is None or fact.materialized not in READS_THROUGH:
            return ()
        out = []
        for dep in fact.depends_on:
            out.append(dep)
            if dep not in seen:
                out.extend(through(dep, seen | {dep}))
        cache[uid] = tuple(dict.fromkeys(out))
        return cache[uid]

    result = []
    for fact in node_facts:
        extra = [d for dep in fact.depends_on for d in through(dep, {dep})]
        if extra:
            result.append(replace(fact, depends_on=tuple(dict.fromkeys([*fact.depends_on, *extra]))))
        else:
            result.append(fact)
    return result


def target_schemas(node_facts):
    return {(f.relation.database, f.relation.schema) for f in node_facts if f.relation is not None}
