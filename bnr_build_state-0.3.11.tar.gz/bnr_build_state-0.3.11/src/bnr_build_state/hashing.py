"""Hash compiled SQL after normalization so formatting churn does not force rebuilds.

Normalization (sqlglot): whitespace and comments removed, unquoted identifiers lowercased,
rendered in the adapter's dialect. SQL sqlglot cannot parse structurally (including statements
it falls back to exp.Command for) is hashed as the exact raw text, and the caller records the
`unparsed` flag. An unknown dialect raises rather than being treated as unparsed SQL.

`select_star` means a `*` that expands a relation. A star over the statement's own CTEs or
subqueries is not one: those columns are fixed by SQL that is part of the hash.

`volatile` means the SQL reads the clock, a random source or the session (current_date,
current_timestamp, random, uuid_string, current_user, ...): the same SQL over the same inputs
yields different rows on another day, so no change signal can prove a rebuild unnecessary.
"""
from dataclasses import dataclass
import hashlib
import re

import sqlglot
from sqlglot import exp
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from sqlglot.optimizer.scope import Scope, traverse_scope


@dataclass(frozen=True)
class SqlFacts:
    sha256: str
    parsed: bool
    select_star: bool
    volatile: bool = False
    # An aggregate whose result depends on the engine's row order (any_value, listagg/array_agg/object_agg without an
    # ORDER BY): the same inputs can rebuild into different content, which only a content hash can see.
    unordered: bool = False


UNORDERED_FUNCTIONS = frozenset({'any_value', 'listagg', 'array_agg', 'object_agg', 'arrayagg', 'string_agg', 'group_concat'})
_UNORDERED_TEXT = re.compile(r'\b(' + '|'.join(sorted(UNORDERED_FUNCTIONS)) + r')\s*\(', re.IGNORECASE)


# Expression classes sqlglot gives the clock, random and session functions of every dialect it knows (a warehouse's
# sysdate, getdate and systimestamp all parse to CurrentTimestamp), plus function names it leaves anonymous.
VOLATILE_EXPRESSIONS = tuple(getattr(exp, name) for name in (
    'CurrentDate', 'CurrentTimestamp', 'CurrentTime', 'CurrentDatetime', 'Localtimestamp', 'Localtime', 'Rand', 'Randn',
    'Uuid', 'CurrentUser', 'CurrentRole', 'CurrentSchema', 'CurrentDatabase', 'CurrentSession', 'CurrentWarehouse',
    'NextValueFor', 'Seq1', 'Seq2', 'Seq4', 'Seq8', 'Uniform', 'Randstr', 'Zipf', 'Normal') if hasattr(exp, name))
VOLATILE_FUNCTIONS = frozenset({
    'current_date', 'current_timestamp', 'current_time', 'localtime', 'localtimestamp', 'sysdate', 'getdate', 'now',
    'systimestamp', 'today', 'random', 'rand', 'uuid_string', 'uuid', 'gen_random_uuid', 'newid', 'nextval', 'seq1', 'seq2',
    'seq4', 'seq8', 'uniform', 'randstr', 'zipf', 'normal', 'current_user', 'current_role', 'current_session',
    'current_warehouse', 'current_account', 'current_region', 'current_transaction', 'current_statement',
    'current_client', 'current_version', 'current_ip_address', 'last_query_id', 'session_user', 'invoker_role',
    'invoker_share', 'is_role_in_session', 'is_granted_to_invoker_role'})
_VOLATILE_TEXT = re.compile(r'\b(' + '|'.join(sorted(VOLATILE_FUNCTIONS)) + r')\b', re.IGNORECASE)


def raw_sha256(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def _star_qualifier(item):
    """'' for a bare `*`, the qualifier for `a.*`, None for anything that is not a star."""
    if isinstance(item, exp.Star):
        return ''
    if isinstance(item, exp.Column) and isinstance(item.this, exp.Star):
        return item.table
    return None


def _expands_relation(source):
    """True when a star over this scope source could change shape without its SQL changing.

    A CTE or derived table is its own scope, checked on its own; a physical table (a ref, source or
    anything else) and anything sqlglot cannot model as a query (table functions) count as relations.
    """
    if isinstance(source, Scope):
        return not isinstance(source.expression, (exp.Query, exp.Values))
    return True


def _selects_star(tree, dialect):
    """True when some `*` or `a.*` expands a relation rather than a CTE or subquery of the same statement."""
    try:
        # Case-fold unquoted names the way the warehouse does, so `final` and `"final"` resolve correctly.
        scopes = traverse_scope(normalize_identifiers(tree.copy(), dialect=dialect))
    except Exception:  # scope analysis is best effort; an unanalysable star is assumed to read a relation
        scopes = None
    if not scopes:
        return any(_star_qualifier(item) is not None for select in tree.find_all(exp.Select) for item in select.expressions)
    for scope in scopes:
        if not isinstance(scope.expression, exp.Select):
            continue
        for item in scope.expression.expressions:
            qualifier = _star_qualifier(item)
            if qualifier is None:
                continue
            if qualifier == '':
                sources = list(scope.sources.values())
            else:
                sources = [scope.sources.get(qualifier)]
            if not sources or any(source is None or _expands_relation(source) for source in sources):
                return True
    return False


def _is_volatile(tree):
    for node in tree.walk():
        if isinstance(node, VOLATILE_EXPRESSIONS):
            return True
        if isinstance(node, exp.Anonymous) and node.name.casefold() in VOLATILE_FUNCTIONS:
            return True
        # `current_date` with no parentheses parses as a column in some dialects.
        if isinstance(node, exp.Column) and not node.table and not node.this.quoted and node.name.casefold() in VOLATILE_FUNCTIONS:
            return True
    return False


def _is_unordered(tree):
    ordered_kinds = tuple(getattr(exp, name) for name in ('GroupConcat', 'ArrayAgg', 'ArrayUniqueAgg', 'ObjectAgg', 'JSONObjectAgg') if hasattr(exp, name))
    for node in tree.walk():
        if isinstance(node, exp.AnyValue):
            return True
        if isinstance(node, ordered_kinds):
            ordered = isinstance(node.parent, exp.WithinGroup) or isinstance(node.this, exp.Order) or node.args.get('order') is not None
            if not ordered:
                return True
        if isinstance(node, exp.Anonymous) and node.name.casefold() in UNORDERED_FUNCTIONS:
            return True
    return False


def analyze(sql, dialect):
    sqlglot.Dialect.get_or_raise(dialect)
    try:
        trees = [t for t in sqlglot.parse(sql, read=dialect) if t is not None]
        if not trees or any(isinstance(t, exp.Command) for t in trees):
            return SqlFacts(raw_sha256(sql), False, False, bool(_VOLATILE_TEXT.search(sql)), bool(_UNORDERED_TEXT.search(sql)))
        rendered = ';'.join(t.sql(dialect=dialect, normalize=True, comments=False, pretty=False) for t in trees)
    except (sqlglot.errors.SqlglotError, RecursionError):
        return SqlFacts(raw_sha256(sql), False, False, bool(_VOLATILE_TEXT.search(sql)), bool(_UNORDERED_TEXT.search(sql)))
    return SqlFacts(hashlib.sha256(rendered.encode('utf-8')).hexdigest(), True, any(_selects_star(t, dialect) for t in trees),
                    any(_is_volatile(t) for t in trees), any(_is_unordered(t) for t in trees))
