"""Build state client: wrap a dbt build with compile, hash, stamp, plan, build, report."""
__version__ = '0.3.11'
