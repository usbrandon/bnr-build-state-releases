"""Resolve the dbt profile output the run will use, the same way dbt does for the common cases.

Only `env_var()` is rendered; other jinja is left untouched. Precedence for the profiles
directory: explicit argument, DBT_PROFILES_DIR, ./profiles.yml in the project, ~/.dbt.
"""
from dataclasses import dataclass
from pathlib import Path
import re

import yaml

_ENV_VAR = re.compile(r"""\{\{\s*env_var\(\s*['"]([^'"]+)['"]\s*(?:,\s*['"]([^'"]*)['"]\s*)?\)\s*\}\}""")


class ProfileError(Exception):
    pass


@dataclass(frozen=True)
class Profile:
    name: str
    target: str
    adapter: str
    output: dict


def render_env_vars(text, env):
    def replace(match):
        name, default = match.group(1), match.group(2)
        if name in env:
            return env[name]
        if default is not None:
            return default
        raise ProfileError(f'environment variable {name} is not set and has no default')
    return _ENV_VAR.sub(replace, text)


def _profiles_file(project_dir, profiles_dir, env):
    candidates = []
    if profiles_dir:
        candidates.append(Path(profiles_dir))
    if env.get('DBT_PROFILES_DIR'):
        candidates.append(Path(env['DBT_PROFILES_DIR']))
    candidates.append(Path(project_dir))
    candidates.append(Path.home() / '.dbt')
    for directory in candidates:
        for name in ('profiles.yml', 'profiles.yaml'):
            path = directory / name
            if path.is_file():
                return path
    raise ProfileError('profiles.yml not found in ' + ', '.join(str(c) for c in candidates))


def _render_value(value, env):
    if isinstance(value, str):
        return render_env_vars(value, env)
    if isinstance(value, dict):
        return {key: _render_value(item, env) for key, item in value.items()}
    if isinstance(value, list):
        return [_render_value(item, env) for item in value]
    return value


def _load_yaml(path):
    try:
        return yaml.safe_load(path.read_text()) or {}
    except OSError as exc:
        raise ProfileError(f'cannot read {path}: {exc}') from exc
    except yaml.YAMLError as exc:
        raise ProfileError(f'cannot parse {path}: {exc}') from exc


def read_profile(project_dir, *, profiles_dir=None, target=None, env):
    project_file = Path(project_dir) / 'dbt_project.yml'
    project = _load_yaml(project_file)
    name = project.get('profile') if isinstance(project, dict) else None
    if not name:
        raise ProfileError(f'{project_file} has no profile')
    path = _profiles_file(project_dir, profiles_dir, env)
    doc = _load_yaml(path)
    entry = doc.get(name) if isinstance(doc, dict) else None
    if not isinstance(entry, dict):
        raise ProfileError(f"profile '{name}' not found in {path}")
    chosen = target or env.get('DBT_TARGET') or entry.get('target')
    outputs = entry.get('outputs') or {}
    if chosen not in outputs:
        raise ProfileError(f"target '{chosen}' not found in profile '{name}'")
    output = _render_value(dict(outputs[chosen]), env)
    adapter = output.get('type')
    if not adapter:
        raise ProfileError(f"target '{chosen}' has no type")
    return Profile(name, chosen, str(adapter), output)
