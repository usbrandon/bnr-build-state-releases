"""Postgres stamps (also pg_duckdb): pg_stat_user_tables counters plus relfilenode.

Known limitation: a backend flushes its counters to shared memory when it goes idle and at most once per
PGSTAT_MIN_INTERVAL (1 s, PostgreSQL "Viewing Statistics"), so a write committed within about a second before
the stamps are read is not yet in the counters. The stamp then records the pre-write counter against a build
that may already have read the new rows, and the next plan sees the counter move and rebuilds: one late
rebuild, never a wrong skip, except when the write lands in that window right before a plan whose build does
not read it, which is caught one run later. pg_stat_force_next_flush() and pg_stat_xact_* act on the calling
session only, and n_mod_since_analyze is the same lagging counter, so there is no cross-session fix; declare
`loaded_at_field` on sources where a one-second window matters.
"""
import logging

from .base import StampProvider, by_schema, lit, loaded_at_stamps, signature
from .snowflake import _Cursor

log = logging.getLogger(__name__)

# Shadow observations count rows exactly, but only on relations whose main fork is at most this large
# (pg_relation_size is a file stat, not a scan); larger ones carry the schema signature only.
COUNT_LIMIT_BYTES = 1 << 30


class PostgresProvider(StampProvider):
    platform = 'postgres'
    dialect = 'postgres'

    def __init__(self, connection, *, locator):
        self.connection = connection
        self.locator = locator

    @classmethod
    def connect(cls, output):
        import psycopg  # optional extra
        raw = psycopg.connect(host=output.get('host'), port=output.get('port', 5432), user=output.get('user'),
                              password=output.get('password'), autocommit=True, dbname=output.get('dbname') or output.get('database'),
                              sslmode=output.get('sslmode') or 'prefer')
        return cls(_Cursor(raw), locator=f"{output.get('host')}:{output.get('port', 5432)}")

    def _rows(self, schema, names):
        sql = ("select c.relname, coalesce(s.n_tup_ins, 0) + coalesce(s.n_tup_upd, 0) + coalesce(s.n_tup_del, 0), "
               "c.relfilenode, c.relkind from pg_class c join pg_namespace n on n.oid = c.relnamespace "
               "left join pg_stat_user_tables s on s.relid = c.oid "
               f"where n.nspname = {lit(schema)} and c.relname in ({', '.join(lit(n) for n in names)})")
        return {row[0]: row for row in self.connection.execute(sql)}

    def _counters_trustworthy(self):
        rows = self.connection.execute('select current_setting(\'track_counts\'), pg_is_in_recovery()')
        if not rows or rows[0][0] != 'on' or rows[0][1]:
            log.warning('build-state postgres counters unreliable (track_counts=%s, in_recovery=%s); stamps unknown',
                        rows[0][0] if rows else None, rows[0][1] if rows else None)
            return False
        return True

    def stamps(self, relations):
        if not self._counters_trustworthy():
            return {r: None for r in relations}
        out = {}
        for (_, schema), group in by_schema(relations).items():
            rows = self._rows(schema, [r.identifier for r in group])
            for r in group:
                row = rows.get(r.identifier)
                out[r] = f'{row[1]}:{row[2]}' if row is not None and row[3] in ('r', 'm') else None
        return out

    def relations(self, database, schema):
        rows = self.connection.execute(f'select table_name from information_schema.tables where table_schema = {lit(schema)}')
        return {row[0].casefold() for row in rows}

    def _sizes(self, schema, names):
        """name -> (relkind, main fork bytes); empty when pg_class cannot be read, which skips the counts."""
        sql = ("select c.relname, c.relkind, pg_relation_size(c.oid) from pg_class c join pg_namespace n on n.oid = c.relnamespace "
               f"where n.nspname = {lit(schema)} and c.relname in ({', '.join(lit(n) for n in names)})")
        try:
            return {row[0]: (row[1], row[2]) for row in self.connection.execute(sql)}
        except Exception as error:
            log.warning('build-state %s query failed for %d relation(s): %s', 'relation_size', len(names), error)
            return {}

    def observe(self, relations, hash_scope=None):  # no content hash here: the scope is a Snowflake matter
        """Schema signature plus an exact row count: the only content-stable data-level evidence Postgres offers
        (reltuples and n_live_tup are estimates that drift with vacuum and analyze). The count is bounded by
        COUNT_LIMIT_BYTES; a bigger relation, a view or a partitioned parent reports an empty row_count."""
        out = {}
        for (_, schema), group in by_schema(relations).items():
            cols = self.connection.execute(
                f"select table_name, column_name, data_type from information_schema.columns "
                f"where table_schema = {lit(schema)} order by table_name, ordinal_position")
            columns = {}
            for table, column, data_type in cols:
                columns.setdefault(table, []).append((column, data_type))
            sizes = self._sizes(schema, [r.identifier for r in group])
            countable = [r for r in group if sizes.get(r.identifier, (None, None))[0] in ('r', 'm')
                         and (sizes[r.identifier][1] or 0) <= COUNT_LIMIT_BYTES]
            counts = loaded_at_stamps(self.connection, [(r, f'select count(*) from {r.quoted}') for r in countable]) if countable else {}
            for r in group:
                out[r] = dict(schema_sha256=signature(columns.get(r.identifier, [])), row_count=counts.get(r) or '')
        return out

    def close(self):
        self.connection.close()
