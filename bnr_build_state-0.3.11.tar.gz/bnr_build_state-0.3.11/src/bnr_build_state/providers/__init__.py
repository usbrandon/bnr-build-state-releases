"""Provider registry keyed by the dbt profile adapter type. The only module tree that may
import warehouse connectors or name warehouse functions."""
from .base import StampProviderLike, UnsupportedAdapter  # noqa: F401
from .duckdb import DuckDbProvider
from .postgres import PostgresProvider
from .snowflake import SnowflakeProvider

PROVIDERS = {'snowflake': SnowflakeProvider, 'postgres': PostgresProvider, 'duckdb': DuckDbProvider}


def locator_of(profile):
    output = profile.output
    if profile.adapter == 'snowflake':
        return str(output.get('account', ''))
    if profile.adapter == 'postgres':
        return f"{output.get('host', '')}:{output.get('port', 5432)}"
    return str(output.get('path', ''))


def for_profile(profile, connection=None):
    cls = PROVIDERS.get(profile.adapter)
    if cls is None:
        raise UnsupportedAdapter(f'no stamp provider for adapter {profile.adapter!r}')
    if connection is not None:
        return cls(connection, locator=locator_of(profile))
    return cls.connect(profile.output)
