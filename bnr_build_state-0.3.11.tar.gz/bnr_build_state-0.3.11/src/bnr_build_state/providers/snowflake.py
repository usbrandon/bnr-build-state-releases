"""Snowflake stamps: SYSTEM$LAST_CHANGE_COMMIT_TIME plus LAST_DDL, one statement per schema (plus SHOW ICEBERG TABLES
for a schema that holds Iceberg tables, to tell Snowflake-managed ones from externally catalogued ones)."""
import logging
import os
import re

from .base import QueryTimeout, StampProvider, by_schema, resolve_in_batches, signature, stringify

log = logging.getLogger(__name__)

_BARE = re.compile(r'^[A-Za-z_][A-Za-z0-9_$]*$')


def _lit(text):
    """Snowflake string literal: backslash is an escape character, so double it as well as the quote."""
    return "'" + str(text).replace('\\', '\\\\').replace("'", "''") + "'"


def _ident(name):
    name = str(name)
    return name if _BARE.fullmatch(name) else '"' + name.replace('"', '""') + '"'


def _prefix(database):
    return f'{_ident(database)}.' if database else ''


def _parts(relation_name):
    """Split a relation name on the dots outside double quotes: '"My"."S".t' -> ['"My"', '"S"', 't']."""
    parts, current, quoted = [], '', False
    for ch in str(relation_name):
        if ch == '"':
            quoted = not quoted
        if ch == '.' and not quoted:
            parts.append(current)
            current = ''
        else:
            current += ch
    return parts + [current]


def _stored(part):
    """(name as Snowflake stores it, quoted?): a quoted identifier keeps its case, an unquoted one is upper-cased."""
    part = part.strip()
    if len(part) >= 2 and part[0] == part[-1] == '"':
        return part[1:-1].replace('""', '"'), True
    return part.upper(), False


class _Location:
    """Where a group of relations lives, spelled as Snowflake stores it.

    information_schema is filtered with one exact `table_schema = '<stored>'`: wrapping the column in upper() (or
    comparing with IN) defeats Snowflake's pruning of the catalog and reads the whole database's metadata, measured
    on BCS at 95-115 s for one columns query against 1.3-1.6 s exact. A name dbt quoted keeps its case, unless the
    account ignores quoted case, so a quoted location that returns nothing is re-read case-insensitively.
    """

    def __init__(self, relation):
        parts = _parts(relation.quoted)
        names = [_stored(p) for p in parts]
        if len(names) >= 3:
            (self.database, db_quoted), (self.schema, schema_quoted) = names[-3], names[-2]
        else:
            self.database, db_quoted = (_stored(relation.database) if relation.database else (None, False))
            self.schema, schema_quoted = names[-2] if len(names) == 2 else _stored(relation.schema)
        self.quoted = db_quoted or schema_quoted
        self.prefix = f'{_quote(self.database)}.' if self.database else ''
        self.qualified = f'{self.prefix}{_quote(self.schema)}'


def _quote(name):
    return '"' + str(name).replace('"', '""') + '"'


class _Named:
    """A schema spelled the way the manifest spells it, for _Location: unquoted when bare, quoted otherwise."""

    def __init__(self, database, schema):
        self.database, self.schema = database, schema
        self.quoted = f'{_prefix(database)}{_ident(schema)}.x'

BATCH = 100
# Ceiling for each metadata query bnr runs (stamps, catalog reads, Shadow observations); never applied to dbt's own
# queries, which run on dbt's connection or inside EXECUTE DBT PROJECT. Measured on BCS (2026-11-05 Shadow runs): the
# slowest was an information_schema.columns read at 170 s, stamp queries at most 33 s. A hung query is cancelled
# after this and its stamps stay unknown, so those models build; nothing fails. BNR_QUERY_TIMEOUT_SECONDS overrides.
QUERY_TIMEOUT_SECONDS = 600
# Shadow and Enforce verify a planned skip by comparing the rebuilt relation with the stored observation. Row count and
# column signature miss a content-only change (a model that is not a function of its inputs: ties in a window order,
# any_value, listagg without an order), so base tables up to this many rows also carry HASH_AGG(*), Snowflake's
# order-independent hash of every row: a full scan, cheap below the cap and skipped above it. BNR_CONTENT_HASH_MAX_ROWS
# overrides; 0 turns it off.
CONTENT_HASH_MAX_ROWS = 200_000
# Ceiling for relations the planner asks to hash regardless of size (rewriting incrementals, unordered aggregates,
# `bnr_state: {content_hash: true}`); BNR_CONTENT_HASH_FORCE_MAX_ROWS overrides it. Above this even a forced hash is
# skipped: a full scan of tens of millions of rows per run is the cost the default cap exists to avoid.
CONTENT_HASH_FORCE_MAX_ROWS = 5_000_000
CONTENT_HASH_BATCH = 20
SNOWFLAKE_CANCELLED = 604  # errno of "SQL execution canceled", raised when a client-side timeout fires
SESSION_UTC = "alter session set timezone = 'UTC'"

CREDITS_PER_HOUR = {'X-Small': 1, 'Small': 2, 'Medium': 4, 'Large': 8, 'X-Large': 16, '2X-Large': 32,
                    '3X-Large': 64, '4X-Large': 128, '5X-Large': 256, '6X-Large': 512}


def _connect_kwargs(output):
    """Map a dbt-snowflake profile output to snowflake.connector.connect keyword arguments."""
    kwargs = {k: output[k] for k in ('account', 'user', 'password', 'role', 'warehouse', 'database', 'schema',
                                     'authenticator', 'token', 'private_key_path') if output.get(k)}
    if isinstance(kwargs.get('authenticator'), str) and kwargs['authenticator'].lower() == 'snowflake_jwt':
        kwargs['authenticator'] = 'snowflake_jwt'
    if 'private_key_path' in kwargs:
        kwargs['private_key_file'] = kwargs.pop('private_key_path')
        if output.get('private_key_passphrase'):
            kwargs['private_key_file_pwd'] = output['private_key_passphrase']
    elif output.get('private_key'):
        kwargs['private_key'] = str(output['private_key']).encode()
    return kwargs


class SnowflakeProvider(StampProvider):
    platform = 'snowflake'
    dialect = 'snowflake'

    def __init__(self, connection, *, locator):
        self.connection = connection
        self.locator = locator
        self.warehouse_name = None

    @classmethod
    def connect(cls, output):
        import snowflake.connector  # optional extra
        raw = snowflake.connector.connect(**_connect_kwargs(output))
        provider = cls(_Cursor(raw, timeout=query_timeout()), locator=str(output.get('account', '')))
        provider.warehouse_name = output.get('warehouse') or None
        provider.use_utc()
        return provider

    def use_utc(self):
        """TIMESTAMP_LTZ values (LAST_DDL, loaded_at_field columns) render in the session TIMEZONE, which defaults to
        America/Los_Angeles and differs per user and account; a stamp must not move when the session does."""
        try:
            self.connection.execute(SESSION_UTC)
        except Exception as error:  # stringify still renders aware values in UTC; naive ones are the session's problem
            log.warning('build-state could not set the session timezone to UTC: %s', error)

    def warehouse(self):
        """Name, size and credits per hour of the profile's warehouse; None when it cannot be determined."""
        if not self.warehouse_name:
            return None
        try:
            sql = f'show warehouses like {_lit(self.warehouse_name)}'
            if hasattr(self.connection, 'execute_with_columns'):
                columns, rows = self.connection.execute_with_columns(sql)
                names = [str(c).casefold() for c in columns or []]
            else:
                rows, names = self.connection.execute(sql), []
            name_at = names.index('name') if 'name' in names else 0
            # LIKE treats '_' and '%' as wildcards: keep only the row whose name is the configured one
            row = next((r for r in rows or [] if str(r[name_at]).casefold() == self.warehouse_name.casefold()), None)
            if row is None:
                return None
            size = str(row[names.index('size') if 'size' in names else 3])
            out = dict(name=str(row[name_at]), size=size)
            if size in CREDITS_PER_HOUR:
                out['credits_per_hour'] = CREDITS_PER_HOUR[size]
            return out
        except Exception as error:
            log.warning('build-state warehouse lookup failed: %s', error)
            return None

    def _catalog(self, location, view, columns, order=''):
        """Rows of `<db>.information_schema.<view>` for one schema (see _Location)."""
        rows = self.connection.execute(f'select {columns} from {location.prefix}information_schema.{view} '
                                       f'where table_schema = {_lit(location.schema)}{order}')
        if not rows and location.quoted:
            rows = self.connection.execute(f'select {columns} from {location.prefix}information_schema.{view} '
                                           f'where upper(table_schema) = upper({_lit(location.schema)}){order}')
        return rows

    def _commit_times(self, relations):
        def attempt(chunk):
            sql = ' union all '.join(f"select {_lit(r.quoted)}, SYSTEM$LAST_CHANGE_COMMIT_TIME({_lit(r.quoted)})" for r in chunk)
            found = {name: stringify(value) for name, value in self.connection.execute(sql)}
            return {r: found.get(r.quoted) for r in chunk}

        return resolve_in_batches(relations, attempt, label='commit_time', name=lambda r: r.quoted, batch=BATCH)

    def _table_info(self, location):
        """name -> (table_type, last_ddl, row_count, is_iceberg) from information_schema.tables."""
        rows = self._catalog(location, 'tables', 'table_name, table_type, last_ddl, row_count, is_iceberg')
        return {str(row[0]).casefold(): (row[1], stringify(row[2]) or '', row[3], str(row[4] if len(row) > 4 else 'NO').upper() == 'YES')
                for row in rows}

    def _unmanaged_iceberg(self, location):
        """Casefolded names of the schema's Iceberg tables whose catalog is not Snowflake, or None when that cannot be read.

        information_schema.tables says only IS_ICEBERG; the catalog is in SHOW ICEBERG TABLES (iceberg_table_type
        MANAGED / UNMANAGED, catalog_name SNOWFLAKE for Snowflake-managed), so that runs once per schema that has one.
        """
        sql = f'show iceberg tables in schema {location.qualified}'
        try:
            columns, rows = self.connection.execute_with_columns(sql)
        except Exception as error:
            log.warning('build-state %s query failed: %s', 'iceberg_tables', error)
            return None
        names = [str(c).casefold() for c in columns or []]
        if 'name' not in names or not {'iceberg_table_type', 'catalog_name'} & set(names):
            log.warning('build-state %s query returned no catalog columns', 'iceberg_tables')
            return None
        kind_at = names.index('iceberg_table_type') if 'iceberg_table_type' in names else None
        catalog_at = names.index('catalog_name') if 'catalog_name' in names else None
        out = set()
        for row in rows:
            managed = ((kind_at is not None and str(row[kind_at]).upper() == 'MANAGED')
                       or (catalog_at is not None and str(row[catalog_at]).upper() == 'SNOWFLAKE'))
            if not managed:
                out.add(str(row[names.index('name')]).casefold())
        return out

    def stamps(self, relations):
        """The catalog first, then commit times only for the base tables it lists: a view, a missing relation or an
        externally catalogued Iceberg table in a commit-time batch fails the whole batch."""
        out, ddl = {}, {}
        for group in by_schema(relations).values():
            try:
                info = self._table_info(_Location(group[0]))
            except Exception as error:
                log.warning('build-state %s query failed for %d relation(s): %s', 'last_ddl', len(group), error)
                info = {}
            # An Iceberg table managed by an external catalog gets new data through ALTER ICEBERG TABLE ... REFRESH or
            # auto-refresh, not through DML Snowflake commits, so its commit token is no change signal: unknown.
            # Snowflake-managed Iceberg tables commit through Snowflake and keep their stamps.
            unmanaged = self._unmanaged_iceberg(_Location(group[0])) if any(row[3] for row in info.values()) else set()
            for r in group:
                key = r.identifier.casefold()
                row = info.get(key)
                # Views, external tables and anything else without a trustworthy commit token stay unknown.
                if row is None or row[0] != 'BASE TABLE' or (row[3] and (unmanaged is None or key in unmanaged)):
                    out[r] = None
                else:
                    ddl[r] = row[1]
        commit = self._commit_times(list(ddl))
        for r, last_ddl in ddl.items():
            out[r] = None if commit.get(r) is None else f'{commit[r]}:{last_ddl}'
        return out

    def view_definitions(self, relations):
        """information_schema.views.view_definition; NULL without the privilege to read it, which stays None."""
        out = {}
        for group in by_schema(relations).values():
            try:
                rows = self._catalog(_Location(group[0]), 'views', 'table_name, view_definition')
                found = {str(name).casefold(): text for name, text in rows}
            except Exception as error:
                log.warning('build-state %s query failed for %d relation(s): %s', 'view_definition', len(group), error)
                found = {}
            for r in group:
                text = found.get(r.identifier.casefold())
                out[r] = text if isinstance(text, str) and text.strip() else None
        return out

    def relations(self, database, schema):
        """Names in a schema (tables, views, dynamic and external tables), from information_schema with the exact-name
        filter of _Location. SHOW TERSE OBJECTS stops at 10,000 rows, which would read the rest as absent. Callers pass
        the manifest's database and schema, which dbt writes unquoted."""
        location = _Location(_Named(database, schema))
        rows = self._catalog(location, 'tables', 'table_name')
        return {str(row[0]).casefold() for row in rows}

    def observe(self, relations, hash_scope=None):
        out = {}
        scope = hash_scope or {}
        ceilings = {'skip': 0, 'default': content_hash_max_rows(), 'force': content_hash_force_max_rows()}
        for group in by_schema(relations).values():
            location = _Location(group[0])
            try:
                info = self._table_info(location)
                rows = self._catalog(location, 'columns', 'table_name, column_name, data_type',
                                     ' order by table_name, ordinal_position')
            except Exception as error:
                log.warning('build-state %s query failed for %d relation(s): %s', 'columns', len(group), error)
                for r in group:
                    out[r] = {}
                continue
            columns = {}
            for table, column, data_type in rows:
                columns.setdefault(table.casefold(), []).append((column, data_type))
            for r in group:
                key = r.identifier.casefold()
                row_count = info.get(key, (None, '', None))[2]
                out[r] = dict(row_count='' if row_count is None else str(row_count), schema_sha256=signature(columns.get(key, [])))
            hashable = [r for r in group if (lambda row: row is not None and row[0] == 'BASE TABLE' and isinstance(row[2], int)
                                             and row[2] <= ceilings[scope.get(r, 'default')])(info.get(r.identifier.casefold()))]
            for r, digest in self._content_hashes(hashable).items():
                if digest is not None:
                    out[r]['content_hash'] = digest
        return out

    def _content_hashes(self, relations):
        def attempt(chunk):
            sql = ' union all '.join(f'select {_lit(r.quoted)}, hash_agg(*) from {r.quoted}' for r in chunk)
            found = {name: stringify(value) for name, value in self.connection.execute(sql)}
            return {r: found.get(r.quoted) for r in chunk}

        return resolve_in_batches(relations, attempt, label='content_hash', name=lambda r: r.quoted, batch=CONTENT_HASH_BATCH)

    def close(self):
        self.connection.close()


def _rows_setting(env, name, default):
    value = (os.environ if env is None else env).get(name)
    try:
        return int(value) if value else default
    except ValueError:
        log.warning('build-state: ignoring %s=%r, using %s', name, value, default)
        return default


def content_hash_max_rows(env=None):
    return _rows_setting(env, 'BNR_CONTENT_HASH_MAX_ROWS', CONTENT_HASH_MAX_ROWS)


def content_hash_force_max_rows(env=None):
    return _rows_setting(env, 'BNR_CONTENT_HASH_FORCE_MAX_ROWS', CONTENT_HASH_FORCE_MAX_ROWS)


def query_timeout(env=None):
    value = (os.environ if env is None else env).get('BNR_QUERY_TIMEOUT_SECONDS')
    try:
        return int(value) if value else QUERY_TIMEOUT_SECONDS
    except ValueError:
        log.warning('build-state: ignoring BNR_QUERY_TIMEOUT_SECONDS=%r, using %s', value, QUERY_TIMEOUT_SECONDS)
        return QUERY_TIMEOUT_SECONDS


class _Cursor:
    """Adapt a DB-API connection to the Connection protocol; every query is cancelled after `timeout` seconds."""

    def __init__(self, raw, timeout=None):
        self.raw = raw
        self.timeout = timeout

    def execute(self, sql):
        return self.execute_with_columns(sql)[1]

    def execute_with_columns(self, sql):
        cursor = self.raw.cursor()
        try:
            try:
                cursor.execute(sql, timeout=self.timeout) if self.timeout else cursor.execute(sql)
            except Exception as error:
                if getattr(error, 'errno', None) == SNOWFLAKE_CANCELLED and self.timeout:
                    raise QueryTimeout(f'cancelled after {self.timeout} s: {sql[:120]}') from error
                raise
            columns = [d[0] for d in (cursor.description or [])]
            return columns, list(cursor.fetchall())
        finally:
            cursor.close()

    def close(self):
        self.raw.close()
