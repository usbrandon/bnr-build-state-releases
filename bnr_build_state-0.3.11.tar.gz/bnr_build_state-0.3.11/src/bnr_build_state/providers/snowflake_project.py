"""`bnr dbt` against a dbt project object in Snowflake (dbt Projects on Snowflake) instead of a local dbt.

The runner is unchanged: every dbt step it would start (compile, ls, build, test) runs as
`EXECUTE DBT PROJECT <object> ARGS='...'` on the caller's Snowflake connection, and that step's
target/manifest.json and target/run_results.json are downloaded (SYSTEM$LOCATE_DBT_ARTIFACTS, then GET) into a
local target directory, which is where the runner reads them. `dbt ls` output comes from the step's log
(SYSTEM$GET_DBT_LOG). Stamps use the same connection, so no profiles.yml or dbt install is needed where this runs.

    from bnr_build_state.providers.snowflake_project import run_project
    code = run_project('build --select tag:x', os.environ, connection, 'DB_PROD.DBT_PROJECTS.BCS_PLATFORM',
                       database='DB_PROD', schema='BCS', locator='AGMHFEM-GZC16882', warehouse='WH_DBT_CICD')

`database` and `schema` are the target's defaults from the project's profiles.yml (they name the state key);
`warehouse` prices the savings estimate. bnr's own compile and list run with WRITEBACK = FALSE: writing their target/
back changes the object's live version, so the next EXECUTE re-materializes every file (~30 s on a 12k-file project). dbt's exit code is returned as 0 or 1: EXECUTE DBT PROJECT only says
whether dbt failed.
"""
import json
import logging
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile

from .. import invocation as inv_mod, runner
from ..profile import Profile
from .snowflake import SnowflakeProvider, _Cursor, _lit, query_timeout

log = logging.getLogger(__name__)

ARTIFACTS = ('manifest.json', 'run_results.json')
LOG_LIMIT = 10_000_000
LOG_TAIL_LINES = 50
LOCAL_PATH_FLAGS = ('--project-dir', '--profiles-dir', '--target-path')


def args_text(args):
    """The ARGS string: tokens are split on whitespace by the project runtime, so a token with whitespace is quoted."""
    out = []
    for token in args:
        token = str(token)
        if '"' in token:
            raise ValueError(f'dbt argument {token!r} contains a double quote, which ARGS cannot carry')
        out.append(f'"{token}"' if not token or any(c.isspace() for c in token) else token)
    return ' '.join(out)


def list_nodes(log_text):
    """The JSON objects `dbt ls --output json` wrote to a SYSTEM$GET_DBT_LOG log, one per line.

    The log prefixes each line (`05:05:35.268161 [info ]: {...}`), so parse from the first `{"`.
    """
    lines = []
    for line in (log_text or '').splitlines():
        start = line.find('{"')
        if start < 0 or '"unique_id"' not in line:
            continue
        try:
            json.loads(line[start:])
        except ValueError:
            continue
        lines.append(line[start:])
    return '\n'.join(lines) + ('\n' if lines else '')


class ProjectDbt:
    """Stands in for subprocess.run(['dbt', ...]): one EXECUTE DBT PROJECT per call, artifacts into `target`."""

    def __init__(self, connection, project, target, err=sys.stderr, steps=None, writeback=None):
        self.connection = connection
        self.writeback = writeback  # for the caller's own steps; None leaves the object's DEFAULT_WRITEBACK
        self.err = err
        self.project = project
        self.target = Path(target)
        self.query_ids = []
        self.steps = steps if steps is not None else []

    def __call__(self, argv, **kwargs):
        args = list(argv[1:])  # argv[0] is the dbt binary the runner would have started
        at = _command_index(args)
        command = args[at] if at is not None else None
        listing = command in ('ls', 'list')
        if listing:  # the object runs `list`; its log carries the JSON lines, which -q would drop
            args[at] = 'list'
            args = [a for a in args if a not in ('-q', '--quiet')] + ['--output-keys', 'unique_id']
        self.target.mkdir(parents=True, exist_ok=True)
        for name in ARTIFACTS:  # never let an earlier step's files pass for this one's
            (self.target / name).unlink(missing_ok=True)
        planning = listing or command == 'compile'  # bnr's steps, not the caller's: never written back
        code, error, query_id = self._execute(args_text(args), 'list' if listing else command,
                                              False if planning else self.writeback)
        stdout = ''
        if listing and not code:
            text = self._log(query_id)
            if not text:  # unreadable or cut short: an empty listing would read as "nothing selected", which it is not
                code, error = 1, 'the dbt log of the list step could not be read whole'
                print(f'[bnr] EXECUTE DBT PROJECT {self.project} ({query_id}): {error}', file=self.err, flush=True)
            else:
                stdout = list_nodes(text)
        if query_id and not listing:
            # The runner reads the manifest only after compile; later steps need their run_results alone.
            self._fetch(query_id, ARTIFACTS if command == 'compile' else ('run_results.json',))
        return subprocess.CompletedProcess(argv, code, stdout, error)

    def execute(self, text):
        """Run one ARGS string as given, with no artifacts; returns 0 or 1."""
        at = _command_index(shlex.split(text))
        return self._execute(text, shlex.split(text)[at] if at is not None else None, self.writeback)[0]

    def _execute(self, text, command=None, writeback=None):
        sql = f'execute dbt project {self.project} args={_lit(text)}'
        if writeback is not None:
            sql += f' writeback={"true" if writeback else "false"}'
        cursor = self.connection.cursor()
        try:
            try:
                cursor.execute(sql)
                code, error = 0, ''
            except Exception as exc:  # dbt failed, or the statement did: the artifacts tell which
                code, error = 1, f'{type(exc).__name__}: {exc}'
            query_id = cursor.sfqid
        finally:
            cursor.close()
        self.query_ids.append(query_id)
        self.steps.append(dict(command=command, args=text, query_id=query_id, ok=not code, error=error[-1500:] or None))
        if error:  # the exception carries only the tail; dbt's own error is in the log
            tail = '\n'.join((self._log(query_id) or '').splitlines()[-LOG_TAIL_LINES:])
            print(f'[bnr] EXECUTE DBT PROJECT {self.project} ({query_id}): {error[-1500:]}' + (f'\n{tail}' if tail else ''),
                  file=self.err, flush=True)
        return code, error, query_id

    def _scalar(self, sql):
        cursor = self.connection.cursor()
        try:
            cursor.execute(sql)
            row = cursor.fetchone()
            return row[0] if row else None
        finally:
            cursor.close()

    def _log(self, query_id):
        """The step's dbt log, or '' when it cannot be read whole (a truncated listing would plan a partial selection)."""
        if not query_id:
            return ''
        try:
            text = self._scalar(f'select system$get_dbt_log({_lit(query_id)}, {LOG_LIMIT})') or ''
        except Exception as exc:
            log.warning('build-state could not read the dbt log of %s: %s', query_id, exc)
            return ''
        if len(text) >= LOG_LIMIT:
            log.warning('build-state: the dbt log of %s reached %s characters and may be cut short', query_id, LOG_LIMIT)
            return ''
        return text

    def _fetch(self, query_id, names):
        """Download the step's target/ artifacts; a step that died early has none, which the runner treats as no results."""
        try:
            folder = self._scalar(f'select system$locate_dbt_artifacts({_lit(query_id)})')
        except Exception as exc:
            log.warning('build-state could not locate the artifacts of %s: %s', query_id, exc)
            return
        if not folder:
            return
        base = folder if folder.endswith('/') else folder + '/'
        local = 'file://' + str(self.target.resolve()) + '/'
        for name in names:
            cursor = self.connection.cursor()
            try:
                cursor.execute(f'get {_lit(base + "target/" + name)} {_lit(local)}')
            except Exception as exc:
                log.warning('build-state could not download %s of %s: %s', name, query_id, exc)
            finally:
                cursor.close()


class _Borrowed(_Cursor):
    """The caller's connection for stamps. Closing it restores the session timezone the provider switched to UTC
    (the build runs in this session) and leaves the connection open."""

    def __init__(self, raw, timeout=None):
        super().__init__(raw, timeout=timeout)
        self.timezone = None
        try:
            columns, rows = self.execute_with_columns("show parameters like 'TIMEZONE' in session")
            if rows:
                row = dict(zip([c.lower() for c in columns], rows[0]))
                self.timezone = (row.get('value'), str(row.get('level') or '').upper())
        except Exception as exc:
            log.warning('build-state could not read the session timezone: %s', exc)

    def close(self):
        if self.timezone is None:
            return
        value, level = self.timezone
        self.execute(f'alter session set timezone = {_lit(value)}' if level == 'SESSION' else 'alter session unset timezone')


def _command_index(args):
    """Position of the dbt subcommand: the first token that is a command and not the value of a flag."""
    for i, token in enumerate(args):
        if token in inv_mod.DBT_COMMANDS and not (i and args[i - 1] in inv_mod.VALUE_FLAGS):
            return i
    return None


def run_project(args, env, connection, project, *, database, schema, warehouse=None, locator=None, out=sys.stdout,
                err=sys.stderr, provider_factory=None, steps=None, writeback=None, **runner_kwargs):
    """Run `bnr dbt <args>` with dbt executed by the dbt project object `project`. Returns 0 or 1 (see module doc).

    `args` is the ARGS string the caller would have passed to EXECUTE DBT PROJECT. When it cannot be planned
    (a flag that points at local files, or a double quote ARGS cannot re-encode) it runs exactly as given.

    The state key is (project, platform, locator, database, schema), compared as exact strings. For runs here and
    `bnr` runs from profiles.yml against the same target to share one key, pass `locator` spelled like the profile's
    `account:` and `database`/`schema` like the profile's (the default locator is the connector's parsed account,
    which drops any region suffix). The connection needs a current warehouse: stamp queries run on it.

    `steps`, when given a list, receives one dict per EXECUTE DBT PROJECT (command, args, query_id, ok, error), so the
    caller can harvest the build's query (its log, SYSTEM$LOCATE_DBT_ARTIFACTS) as it would its own EXECUTE.

    `writeback` sets WRITEBACK on the caller's steps (build, test, or ARGS run unchanged); None keeps the object's
    DEFAULT_WRITEBACK. Per-query artifacts (SYSTEM$LOCATE_DBT_ARTIFACTS, SYSTEM$GET_DBT_LOG) are kept either way.
    """
    argv = shlex.split(args)
    local = [a for a in argv if a.split('=', 1)[0] in LOCAL_PATH_FLAGS]
    try:
        if local:  # they would move the object's files, or the runner's, but not both
            raise ValueError(f'{", ".join(local)} cannot be used with a dbt project object')
        args_text(argv)
    except ValueError as error:
        message = f'not planned ({error}), running ARGS unchanged'
        print(f'[bnr] {message}', file=err, flush=True)
        with tempfile.TemporaryDirectory(prefix='bnr-project-') as workdir:
            code = ProjectDbt(connection, project, Path(workdir) / 'target', err, steps, writeback).execute(args)
        if all(env.get(k) for k in ('BNR_URL', 'BNR_TOKEN', 'BNR_ACCOUNT_ID')) and env.get('BNR_STATE_MODE_OVERRIDE') != 'off':
            runner.send_event(env, runner_kwargs.get('api_factory') or runner.StateApi, kind='fallback', messages=[message],
                              invocation=dict(args=argv, client=dict(name='bnr-build-state', version=runner.__version__,
                                                                     executor='snowflake_project')), err=err)
        return code
    locator = locator or str(getattr(connection, 'account', '') or '')
    profile = Profile('snowflake-project', 'project', 'snowflake',
                      dict(account=locator, database=database, schema=schema, warehouse=warehouse))

    def borrowed(_profile):
        connection_ = _Borrowed(connection, timeout=query_timeout(env))
        provider = SnowflakeProvider(connection_, locator=locator)
        provider.warehouse_name = warehouse
        if connection_.timezone is not None:  # never leave the caller's session in UTC when it could not be restored
            provider.use_utc()
        return provider

    # The local paths the runner would read from dbt_project.yml or the environment do not exist here.
    env = {k: v for k, v in env.items() if k not in ('DBT_PROJECT_DIR', 'DBT_TARGET_PATH', 'BNR_DBT_BIN')}
    with tempfile.TemporaryDirectory(prefix='bnr-project-') as workdir:
        dbt = ProjectDbt(connection, project, Path(workdir) / 'target', err, steps, writeback)
        return runner.run(argv, env, provider_factory=provider_factory or borrowed, subprocess_run=dbt, out=out, err=err,
                          cwd=workdir, profile=profile, executor='snowflake_project', **runner_kwargs)
