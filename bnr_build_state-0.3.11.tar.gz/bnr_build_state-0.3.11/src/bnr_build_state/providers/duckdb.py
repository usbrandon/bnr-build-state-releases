"""DuckDB and MotherDuck: no change metadata, so stamps are None and skipping needs loaded_at_*."""
from .base import StampProvider, by_schema, lit, loaded_at_stamps, signature
from .snowflake import _Cursor


def _catalog(database):
    return f' and table_catalog = {lit(database)}' if database else ''


class DuckDbProvider(StampProvider):
    platform = 'duckdb'
    dialect = 'duckdb'

    def __init__(self, connection, *, locator):
        self.connection = connection
        self.locator = locator

    @classmethod
    def connect(cls, output):
        import duckdb  # optional extra
        path = output.get('path') or ':memory:'
        # Local files open read-only so a wrong path is not created and no writer lock is taken.
        raw = duckdb.connect(path) if str(path).startswith('md:') or path == ':memory:' else duckdb.connect(path, read_only=True)
        return cls(_Cursor(raw), locator=str(path))

    def stamps(self, relations):
        return {r: None for r in relations}

    def relations(self, database, schema):
        rows = self.connection.execute(
            f'select table_name from information_schema.tables where table_schema = {lit(schema)}'
            f'{_catalog(database)}')
        return {row[0].casefold() for row in rows}

    def observe(self, relations, hash_scope=None):  # no content hash here: the scope is a Snowflake matter
        """Schema signature plus an exact row count. DuckDB answers an unfiltered count(*) over a base table from the
        row-group counts in its table metadata, so the count is cheap at any size; views are not counted, since that
        would run the view."""
        out = {}
        for (database, schema), group in by_schema(relations).items():
            cols = self.connection.execute(
                f"select table_name, column_name, data_type from information_schema.columns "
                f"where table_schema = {lit(schema)}{_catalog(database)} order by table_name, ordinal_position")
            columns = {}
            for table, column, data_type in cols:
                columns.setdefault(table.casefold(), []).append((column, data_type))
            kinds = {str(name).casefold(): kind for name, kind in self.connection.execute(
                f'select table_name, table_type from information_schema.tables where table_schema = {lit(schema)}{_catalog(database)}')}
            countable = [r for r in group if kinds.get(r.identifier.casefold()) == 'BASE TABLE']
            counts = loaded_at_stamps(self.connection, [(r, f'select count(*) from {r.quoted}') for r in countable]) if countable else {}
            for r in group:
                out[r] = dict(schema_sha256=signature(columns.get(r.identifier.casefold(), [])), row_count=counts.get(r) or '')
        return out

    def close(self):
        self.connection.close()
