"""Shared pieces for stamp providers: the connection seam, literal helpers, and the
dialect-neutral `loaded_at_field` / `loaded_at_query` batch.

A stamp is an opaque string; callers compare it by equality only. `None` means the
platform has no reliable change signal for that relation and the service will build.
"""
from datetime import date, datetime, timezone
import hashlib
import logging
from typing import Protocol

log = logging.getLogger(__name__)


class UnsupportedAdapter(Exception):
    pass


class Connection(Protocol):
    def execute(self, sql: str) -> list[tuple]: ...
    def close(self) -> None: ...


class StampProviderLike(Protocol):
    platform: str
    dialect: str
    locator: str
    def stamps(self, relations: list) -> dict: ...
    def relations(self, database: str | None, schema: str) -> set[str]: ...
    def observe(self, relations: list, hash_scope: dict | None = None) -> dict: ...
    def close(self) -> None: ...


class QueryTimeout(Exception):
    """A metadata query ran past the provider's limit and was cancelled. Retrying its parts one by one would only
    multiply the wait, so callers give up on the batch: its stamps stay unknown and those models build."""


class StampProvider:
    """Optional behaviour shared by the stamp providers."""

    def warehouse(self):
        """Compute warehouse facts for pricing, or None when the platform has no such notion."""
        return None

    def view_definitions(self, relations):
        """The deployed SQL of each view, None where it cannot be read; lineage through it stays unknown."""
        return {r: None for r in relations}


def lit(text):
    return "'" + str(text).replace("'", "''") + "'"


def stringify(value):
    """A stamp text that does not depend on the session: an aware datetime is rendered in UTC, since drivers hand
    back TIMESTAMP_LTZ-style values in whatever zone the session happens to use."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return (value.astimezone(timezone.utc) if value.tzinfo is not None else value).isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (bytes, bytearray)):
        return bytes(value).hex()
    return str(value)


def signature(columns):
    """sha256 over (name, type) pairs in ordinal order; columns is a list of (name, type)."""
    text = '\n'.join(f'{name}\t{type_}' for name, type_ in columns)
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def resolve_in_batches(items, attempt, *, label, name=str, batch=50):
    """`attempt(chunk) -> {item: value}` for `batch` items at a time. A failing chunk is split in halves down to one item,
    so one bad item costs about 2·log2(batch) queries instead of one per item; the item that fails alone is named and
    left unknown (None). A timed-out chunk is left unknown whole: retrying its parts would only multiply the wait."""
    out = {}

    def resolve(chunk, top):
        try:
            out.update(attempt(chunk))
            return
        except QueryTimeout as error:
            log.warning('build-state %s query timed out for %d relation(s), left unknown: %s', label, len(chunk), error)
            out.update({item: None for item in chunk})
            return
        except Exception as error:
            if len(chunk) == 1:
                log.warning('build-state %s query failed for %s, left unknown: %s', label, name(chunk[0]), error)
                out[chunk[0]] = None
                return
            if top:
                log.warning('build-state %s query failed for %d relation(s), retrying in halves: %s', label, len(chunk), error)
        half = len(chunk) // 2
        resolve(chunk[:half], False)
        resolve(chunk[half:], False)

    for start in range(0, len(items), batch):
        resolve(list(items[start:start + batch]), True)
    return out


def loaded_at_stamps(connection, items, batch=50):
    """items: list of (unique_id, scalar query). Runs `select (q0) as s0, (q1) as s1, ...` per batch; see
    resolve_in_batches for how a failing batch narrows down to the query at fault."""
    def attempt(chunk):
        sql = 'select ' + ', '.join(f'({query}) as s{i}' for i, (_, query) in enumerate(chunk))
        row = (connection.execute(sql) or [()])[0]
        return {item: stringify(value) for item, value in zip(chunk, row)}

    found = resolve_in_batches(list(items), attempt, label='loaded_at', name=lambda item: item[0], batch=batch)
    return {uid: found.get((uid, query)) for uid, query in items}


def by_schema(relations):
    groups = {}
    for relation in relations:
        groups.setdefault((relation.database, relation.schema), []).append(relation)
    return groups
