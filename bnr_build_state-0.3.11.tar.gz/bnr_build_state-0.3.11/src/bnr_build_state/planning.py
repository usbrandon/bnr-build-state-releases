"""Pure builders for the plan request and the report request (spec 6.1 and 6.2)."""
from collections import Counter
import hashlib

from .artifacts import MATERIALIZED_TYPES
from .hashing import SqlFacts

# 'partial success' (a microbatch model with failed batches) is an error: the relation is not fully built, and
# recording success would let the next run skip it instead of retrying the batches.
# Materializations whose stored rows dbt rewrites from the SQL: a clock, random or session function in their SQL changes
# the stored rows between runs. A view or ephemeral stores nothing (the warehouse evaluates it at read time), and a
# dynamic table or materialized view is refreshed by the warehouse from its definition: for those only the definition
# matters, and that is the SQL hash.
VOLATILE_MATERIALIZATIONS = frozenset({'table', 'incremental'})

# 'reused' is dbt's own cache hit (Fusion state-aware orchestration): the relation stands as it was, not rebuilt now.
# 'no-op' is dbt reporting nothing to do. Neither changes the relation, so neither is a build or a failure.
STATUS_MAP = {'success': 'success', 'pass': 'success', 'warn': 'success', 'partial success': 'error',
              'error': 'error', 'fail': 'error', 'runtime error': 'error', 'skipped': 'skipped',
              'reused': 'reused', 'no-op': 'skipped'}


def _target_present(fact, present):
    if fact.relation is None:
        return None
    names = present.get((fact.relation.database, fact.relation.schema))
    if names is None:
        return None
    return fact.relation.identifier.casefold() in names


def fold_ephemerals(sql_facts, folded):
    """Each reader's SqlFacts combined with those of the ephemerals folded into it (see artifacts.inline_ephemerals):
    the hash covers the ephemeral SQL, a star or clock in the ephemeral counts for the reader, and an unparsed
    ephemeral makes the reader unparsed."""
    out = dict(sql_facts)
    for uid, ephemerals in folded.items():
        own = sql_facts.get(uid)
        if own is None:
            continue
        parts = [sql_facts.get(e.unique_id) for e in sorted(ephemerals, key=lambda e: e.unique_id)]
        if any(part is None for part in parts):
            continue  # an ephemeral without SQL: the reader keeps its own facts and errors as dbt would
        digest = hashlib.sha256('\n'.join([own.sha256] + [p.sha256 for p in parts]).encode('utf-8')).hexdigest()
        out[uid] = SqlFacts(digest, own.parsed and all(p.parsed for p in parts),
                            own.select_star or any(p.select_star for p in parts), own.volatile or any(p.volatile for p in parts))
    return out


def plan_request(*, account_id, project, platform, locator, database, schema, engine, invocation, run_id,
                 facts, sql_facts, stamps, present, folded=None):
    invocation = dict(invocation)
    full_refresh = bool(invocation.pop('full_refresh', False))
    sql_facts = fold_ephemerals(sql_facts, folded) if folded else sql_facts
    nodes = []
    for fact in facts:
        flags = list(fact.flags)
        errors = []
        settings = fact.bnr_state or {}
        sql = sql_facts.get(fact.unique_id)
        if fact.resource_type == 'seed':
            sha = fact.checksum
            if sha is None:
                errors.append('seed_checksum_unavailable')
        elif sql is not None:
            sha = sql.sha256
            has_model_dep = any(dep.startswith('model.') for dep in fact.depends_on)
            if not sql.parsed:
                flags.append('unparsed')
            # Without a parse, star presence is unknown, so a ref dependency forces a build. Only a model stores the
            # expanded columns; a test's `select * from <model> where ...` stores nothing, and its parent's rebuild
            # already reaches it through `upstream_built`.
            if fact.resource_type == 'model' and has_model_dep and (sql.select_star or not sql.parsed):
                flags.append('select_star_on_ref')
            # Clock, random or session functions: the same SQL over unchanged inputs gives other rows tomorrow.
            # config(bnr_state={"volatile": false}) accepts that (say, a load timestamp column that may lag).
            # The run's start time rendered into the SQL (`run_timestamp`, see artifacts.neutralize_run_timestamps) is
            # a clock value like any other once the rows store it.
            stores_rows = fact.materialized in VOLATILE_MATERIALIZATIONS
            time_dependent = sql.volatile or 'run_timestamp' in flags
            if settings['volatile'] if isinstance(settings.get('volatile'), bool) else (time_dependent and stores_rows):
                flags.append('volatile')
        else:
            sha = None
            if fact.resource_type == 'model' and 'python' not in flags:
                errors.append('no_compiled_sql')
        if full_refresh and fact.resource_type in MATERIALIZED_TYPES:  # seeds are dropped and reloaded too
            flags.append('full_refresh')
        if settings.get('always_build') is True:
            flags.append('always_build')
        lag = settings.get('lag_tolerance_seconds')
        node = dict(unique_id=fact.unique_id, resource_type=fact.resource_type, materialized=fact.materialized,
                    sql_sha256=sha, config_sha256=fact.config_sha256, depends_on=list(fact.depends_on),
                    target_present=_target_present(fact, present), flags=flags, errors=errors)
        if isinstance(lag, int) and not isinstance(lag, bool) and lag >= 0:
            node['lag_tolerance_seconds'] = lag
        nodes.append(node)
    sources = [dict(unique_id=uid, stamp=stamp, stamp_kind=kind, schema_sha256=None) for uid, (stamp, kind) in stamps.items()]
    return dict(account_id=account_id, project=project,
                target=dict(platform=platform, locator=locator, database=database, schema=schema),
                engine=dict(engine), invocation=invocation, run_id=run_id, nodes=nodes, sources=sources)


def skipped_ids(plan_response):
    return [n['unique_id'] for n in plan_response.get('nodes') or [] if n.get('action') == 'skip']


EXCLUDABLE_TYPES = frozenset({'model', 'seed'})

# Materializations that rewrite rows in place: a rebuild with the same inputs can change content without changing
# the row count, which only the content hash can see. Append-only history can only grow.
REWRITING_STRATEGIES = frozenset({'merge', 'delete+insert', 'insert_overwrite', 'replace_where'})


def content_hash_scope(fact, sql=None):
    """How far the observation's content hash should reach for this node: 'skip' (never), 'default' (base tables up
    to the provider's default cap) or 'force' (up to the provider's forced ceiling). `bnr_state.content_hash` wins;
    otherwise a rewriting incremental strategy or an unordered aggregate asks for the hash regardless of size, because
    those are the shapes that can change content silently."""
    setting = (fact.bnr_state or {}).get('content_hash')
    if setting is False:
        return 'skip'
    if setting is True:
        return 'force'
    if fact.materialized == 'incremental' and (fact.incremental_strategy or '').casefold() in REWRITING_STRATEGIES:
        return 'force'
    if sql is not None and sql.unordered and fact.materialized in VOLATILE_MATERIALIZATIONS:
        return 'force'
    return 'default'


def excludable(ids, facts):
    """Skipped nodes that `--exclude path:` can address: models and seeds whose file holds only skipped nodes.

    Snapshots are always built. A file shared with a node that builds is never excluded, so a
    selector can never take out more than the plan skipped.
    """
    skipped = set(ids)
    building = {f.original_file_path for f in facts if f.unique_id not in skipped}
    by_id = {f.unique_id: f for f in facts}
    return [by_id[uid] for uid in ids if uid in by_id and by_id[uid].resource_type in EXCLUDABLE_TYPES
            and by_id[uid].original_file_path and by_id[uid].original_file_path not in building]


def exclusions_for(ids, facts):
    """`--exclude` selectors: `path:` of the node's file, one per distinct file."""
    return list(dict.fromkeys('path:' + f.original_file_path for f in excludable(ids, facts)))


def cut_tests(plan_response, facts, done, excluded_ids):
    """Tests dbt's exclusion took with a skipped parent, split by what the plan wanted: (to run, reused).

    dbt expands `--exclude` with the same indirect selection as `--select`, and under the default `eager` a test is
    excluded when ANY parent is ("Test exclusion is always greedy", dbt docs; graph/selector.py expand_selection),
    so `--exclude path:a.sql` also removes a relationships test on a and a built b. A planned-build test that did not
    run and has an excluded parent must still run; a planned-skip one is reused. A test missing for any other
    reason is dbt's omission and is left to the missing-nodes warning.
    """
    action = {n.get('unique_id'): n.get('action') for n in plan_response.get('nodes') or []}
    cut = [f for f in facts if f.resource_type == 'test' and f.unique_id not in done
           and any(dep in excluded_ids for dep in f.depends_on)]
    return ([f for f in cut if action.get(f.unique_id) == 'build'], [f for f in cut if action.get(f.unique_id) == 'skip'])


def test_selectors(facts):
    """One `fqn` selector per test, the whole dotted fqn: dbt's fqn method matches a node whose fqn starts with every
    selector part (graph/selector_methods.py is_selected_node), and a full fqn names exactly one node across packages;
    a bare name could also match a model of that name and eagerly pull in its tests."""
    return ['.'.join(f.fqn) if f.fqn else f.name for f in facts]


def report_request(plan_id, run_results, reused_ids, observations):
    results = []
    seen = set()
    for item in run_results.get('results') or []:
        uid = item.get('unique_id')
        if not isinstance(uid, str):
            continue
        timing = {t.get('name'): t for t in item.get('timing') or [] if isinstance(t, dict)}
        execute = timing.get('execute') or {}
        results.append(dict(unique_id=uid, status=STATUS_MAP.get(str(item.get('status')), 'error'),
                            started_at=execute.get('started_at'), completed_at=execute.get('completed_at')))
        seen.add(uid)
    for uid in reused_ids:
        if uid not in seen:
            results.append(dict(unique_id=uid, status='reused', started_at=None, completed_at=None))
    return dict(plan_id=plan_id, results=results,
                observations=[dict(unique_id=uid, values=dict(values)) for uid, values in observations.items()])


def summary(plan_response, report_body):
    statuses = [r['status'] for r in report_body.get('results') or []]
    return dict(built=statuses.count('success'), reused=statuses.count('reused'), errors=statuses.count('error'),
                undetermined=int((plan_response.get('summary') or {}).get('undetermined') or 0),
                plan_id=plan_response.get('plan_id'))
