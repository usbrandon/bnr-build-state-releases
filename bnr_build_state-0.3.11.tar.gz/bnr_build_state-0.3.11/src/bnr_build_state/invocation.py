"""Parse `dbt build|run` argv far enough to build the compile command and append exclusions.

Everything after the subcommand is preserved byte for byte for the real build, except
that `--exclude` groups are merged into one (user values first, then skipped nodes) so
dbt sees a single exclusion list. Global flags placed before the subcommand are kept
verbatim in `global_args` and also feed the target and path fallbacks.
"""
from dataclasses import dataclass

WRAPPED = ('build', 'run')
DBT_COMMANDS = frozenset({'build', 'run', 'test', 'compile', 'seed', 'snapshot', 'docs', 'source', 'deps', 'clean',
                          'debug', 'parse', 'show', 'list', 'ls', 'run-operation', 'retry', 'clone', 'init'})
VALUE_FLAGS = {'--select', '-s', '--exclude', '--selector', '--target', '-t', '--profiles-dir', '--project-dir',
               '--vars', '--target-path', '--threads', '--resource-type', '--indirect-selection', '--state',
               '--defer-state', '-m', '--models', '--model', '--profile', '--exclude-resource-type', '--log-level', '--log-level-file', '--log-format',
               '--log-format-file', '--sample'}
# Flags under which dbt builds relations with no or partial data (`limit 0` on refs and sources, or a time window).
PARTIAL_DATA_FLAGS = {'--empty', '--sample'}
# `dbt compile` takes no --resource-type or --exclude-resource-type (dbt-core 1.10 cli/main.py): forwarding them
# makes compile exit 2 before the build runs. Compile then covers every resource type, and the build's own
# run_results decide what is reported.
COMPILE_FLAGS = {'--select', '-s', '--exclude', '--selector', '--target', '-t', '--profiles-dir', '--project-dir',
                 '--vars', '--target-path', '--threads', '--indirect-selection', '--state', '--defer-state', '-m',
                 '--models', '--model', '--profile'}
COMPILE_BOOLEAN_FLAGS = {'--defer', '--favor-state', '--no-defer', '--no-favor-state'}
LIST_FLAGS = COMPILE_FLAGS - {'--threads', '--defer-state'}
# The follow-up `dbt test` (runner._retest) keeps the flags that decide where tests run and how refs resolve, and drops
# the selection flags: it selects the tests by name itself. `dbt test` takes these in dbt-core 1.10+ (cli/main.py).
TEST_FLAGS = {'--target', '-t', '--profiles-dir', '--project-dir', '--vars', '--target-path', '--threads', '--state',
              '--defer-state', '--profile', '--indirect-selection', '--log-level', '--log-level-file', '--log-format',
              '--log-format-file'}
TEST_BOOLEAN_FLAGS = {'--defer', '--favor-state', '--no-defer', '--no-favor-state', '--store-failures', '--no-store-failures',
                      '--fail-fast', '-x'}


@dataclass(frozen=True)
class Invocation:
    command: str
    global_args: tuple
    args: tuple
    target: str | None
    profiles_dir: str | None
    project_dir: str | None
    target_path: str | None
    full_refresh: bool
    exclude: tuple
    selector: str | None = None
    partial_data: bool = False  # `--empty` or `--sample`: the relations built hold no or partial data
    favor_state: bool = False  # unselected parents resolve to the --state artifacts' relations, not the manifest's
    resource_types: tuple = ()  # --resource-type values: compile cannot take them, so the selection is narrowed here
    exclude_resource_types: tuple = ()
    fail_fast: bool = False  # `--fail-fast`/`-x`: after a failed build the follow-up test step is not started


def _scan(args, single=False):
    """Yield (index, flag, values) for value flags and (index, token, None) for everything else.

    A value flag consumes the following tokens that do not start with a dash; with `single` it
    consumes exactly one, which is how global flags before the subcommand work.
    """
    i = 0
    while i < len(args):
        token = args[i]
        flag, _, inline = token.partition('=')
        if flag in VALUE_FLAGS:
            if inline or '=' in token:
                yield i, flag, [inline]
                i += 1
                continue
            values = []
            j = i + 1
            while j < len(args) and not args[j].startswith('-') and not (single and values):
                values.append(args[j])
                j += 1
            yield i, flag, values
            i = j
        else:
            yield i, token, None
            i += 1


def _groups(args):
    """Yield (flag, values) for value flags and (token, None) for everything else."""
    for _, flag, values in _scan(args):
        yield flag, values


def _lookup(names, *scopes):
    for scope in scopes:
        for name in names:
            if scope.get(name) is not None:
                return scope[name]
    return None


def parse(argv):
    argv = list(argv)
    command_index = None
    global_found = {}
    global_full_refresh = partial_data = favor_state = fail_fast = False
    for index, flag, values in _scan(argv, single=True):
        if values is None and flag in DBT_COMMANDS:
            command_index = index
            break
        partial_data = partial_data or flag in PARTIAL_DATA_FLAGS
        if values is None:
            global_full_refresh = global_full_refresh or flag in ('--full-refresh', '-f')
            favor_state = favor_state or flag == '--favor-state'
            fail_fast = fail_fast or flag in ('--fail-fast', '-x')
        else:
            global_found[flag] = values[-1] if values else None
    if command_index is None or argv[command_index] not in WRAPPED:
        return None
    args = tuple(argv[command_index + 1:])
    found = {}
    full_refresh = False
    exclude = []
    resource_types, exclude_resource_types = [], []
    for flag, values in _groups(args):
        partial_data = partial_data or flag in PARTIAL_DATA_FLAGS
        if values is None:
            full_refresh = full_refresh or flag in ('--full-refresh', '-f')
            favor_state = favor_state or flag == '--favor-state'
            fail_fast = fail_fast or flag in ('--fail-fast', '-x')
        elif flag == '--exclude':
            exclude.extend(values)
        elif flag == '--resource-type':
            resource_types.extend(values)
        elif flag == '--exclude-resource-type':
            exclude_resource_types.extend(values)
        else:
            found[flag] = values[-1] if values else None
    return Invocation(argv[command_index], tuple(argv[:command_index]), args,
                      _lookup(('--target', '-t'), found, global_found),
                      _lookup(('--profiles-dir',), found, global_found),
                      _lookup(('--project-dir',), found, global_found),
                      _lookup(('--target-path',), found, global_found),
                      full_refresh or global_full_refresh, tuple(exclude),
                      _lookup(('--selector',), found, global_found), partial_data, favor_state,
                      tuple(resource_types), tuple(exclude_resource_types), fail_fast)


def builds_type(inv, unique_id):
    """Whether the build's --resource-type / --exclude-resource-type filters keep this node (`all`/`default` keep all)."""
    kind = unique_id.split('.', 1)[0]
    if inv.resource_types and not {'all', 'default'} & set(inv.resource_types) and kind not in inv.resource_types:
        return False
    return kind not in inv.exclude_resource_types


def compile_argv(inv, dbt_bin):
    out = [dbt_bin, *inv.global_args, 'compile']
    for flag, values in _groups(inv.args):
        if values is None:
            if flag in COMPILE_BOOLEAN_FLAGS:
                out.append(flag)
        elif flag in COMPILE_FLAGS:
            out.append(flag)
            out.extend(values)
    return out


def list_argv(inv, dbt_bin):
    """`dbt ls` with the same selection, one JSON object per node on stdout."""
    out = [dbt_bin, *inv.global_args, 'ls']
    for flag, values in _groups(inv.args):
        if values is not None and flag in LIST_FLAGS:
            out.append(flag)
            out.extend(values)
    return out + ['--output', 'json', '-q']


def build_argv(inv, dbt_bin, excluded_names):
    if not excluded_names:
        return [dbt_bin, *inv.global_args, inv.command, *inv.args]
    out = [dbt_bin, *inv.global_args, inv.command]
    for flag, values in _groups(inv.args):
        if values is None:
            out.append(flag)
        elif flag != '--exclude':
            out.append(flag)
            out.extend(values)
    out.append('--exclude')
    out.extend(inv.exclude)
    out.extend(excluded_names)
    return out


def test_argv(inv, dbt_bin, selectors):
    """`dbt test --select <selectors>` with the invocation's global, target, path and defer flags, no user selection."""
    out = [dbt_bin, *inv.global_args, 'test']
    for flag, values in _groups(inv.args):
        if values is None:
            if flag in TEST_BOOLEAN_FLAGS:
                out.append(flag)
        elif flag in TEST_FLAGS:
            out.append(flag)
            out.extend(values)
    out.append('--select')
    out.extend(selectors)
    return out


def redacted_args(inv):
    """The args that are sent to the state service: `--vars` values may carry secrets."""
    out = []
    args = list(inv.args)
    i = 0
    while i < len(args):
        token = args[i]
        if token == '--vars':
            out.append(token)
            i += 1
            while i < len(args) and not args[i].startswith('-'):
                i += 1
            out.append('<redacted>')
            continue
        out.append('--vars=<redacted>' if token.startswith('--vars=') else token)
        i += 1
    return out
