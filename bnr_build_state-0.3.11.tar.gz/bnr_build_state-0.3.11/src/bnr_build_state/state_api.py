"""Thin HTTP client for the state API. Every failure becomes StateUnavailable so the
caller can fall back to building everything."""
import json
import urllib.error
import urllib.request


class StateUnavailable(Exception):
    def __init__(self, reason):
        super().__init__(reason)
        self.reason = reason


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Never follow a redirect: it would forward the bearer token to another host."""

    def redirect_request(self, *args, **kwargs):
        return None


_OPENER = urllib.request.build_opener(_NoRedirect)


def _urllib_transport(method, url, headers, body, timeout):
    request = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with _OPENER.open(request, timeout=timeout) as response:
            return response.status, response.read()
    except urllib.error.HTTPError as error:
        return error.code, error.read()


class StateApi:
    def __init__(self, url, token, *, transport=None, timeout=30.0):
        self.base = url.rstrip('/')
        self.token = token
        self.transport = transport or _urllib_transport
        self.timeout = timeout

    def _call(self, method, path, body=None):
        headers = {'Authorization': f'Bearer {self.token}', 'Accept': 'application/json'}
        payload = None
        if body is not None:
            payload = json.dumps(body).encode('utf-8')
            headers['Content-Type'] = 'application/json'
        try:
            status, raw = self.transport(method, self.base + path, headers, payload, self.timeout)
        except Exception as error:
            raise StateUnavailable(f'{type(error).__name__}: {error}') from error
        if not isinstance(status, int) or not 200 <= status < 300:
            raise StateUnavailable(f'http {status}: {raw[:200].decode("utf-8", "replace")}')
        try:
            parsed = json.loads(raw)
        except ValueError as error:
            raise StateUnavailable('non-json response') from error
        if not isinstance(parsed, dict):
            raise StateUnavailable('non-object response')
        return parsed

    def plan(self, body):
        return self._call('POST', '/v1/state/plan', body)

    def report(self, body):
        return self._call('POST', '/v1/state/report', body)

    def events(self, body):
        return self._call('POST', '/v1/state/events', body)

    def explain(self, plan_id):
        return self._call('GET', f'/v1/state/explain/{plan_id}')
