"""Console entry point: `bnr dbt <args>` and `bnr state explain <plan_id> [-s node]`."""
import os
import sys

from . import runner

USAGE = 'usage: bnr dbt <build|run|...> [dbt args]  |  bnr state explain <plan_id> [-s node]'


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ['dbt']:
        return runner.run(argv[1:], dict(os.environ))
    if argv[:2] == ['state', 'explain'] and len(argv) >= 3:
        node = None
        rest = argv[3:]
        if rest[:1] in (['-s'], ['--select']) and len(rest) >= 2:
            node = rest[1]
        return runner.explain(argv[2], dict(os.environ), node=node)
    print(USAGE, file=sys.stderr)
    return 2


if __name__ == '__main__':
    raise SystemExit(main())
