"""Orchestrate one wrapped dbt invocation (spec 4.2). All I/O is injected so tests run offline.

Order: compile → (hash ∥ stamps) → presence → plan → build → (test) → report → summary. Any failure
before the plan response falls back to the original command; any failure after the build only
prints a warning. The exit code is always dbt's: the build's, or when the build passed and Enforce
had to run a follow-up `dbt test` for tests its exclusion took along, that step's.
"""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import logging
from pathlib import Path
import subprocess
import sys
import time

import sqlglot
from sqlglot import exp
import yaml

from . import __version__, artifacts, invocation as inv_mod, planning
from .hashing import analyze
from .profile import ProfileError, read_profile
from .providers import for_profile
from .providers.base import UnsupportedAdapter, loaded_at_stamps as default_loaded_at
from .state_api import StateApi, StateUnavailable

MODES = ('off', 'shadow', 'enforce')
FALLBACK = 'state service unavailable, building everything'


def _say(stream, text):
    print(f'[bnr] {text}', file=stream, flush=True)


def _original(inv, dbt_bin, subprocess_run, cwd):
    return subprocess_run(inv_mod.build_argv(inv, dbt_bin, []), cwd=cwd).returncode


def _selector_in_use(inv, project_dir, manifest=None):
    """True when dbt would ignore `--exclude`: an explicit `--selector`, or a default selector in selectors.yml.

    The manifest carries the parsed selectors too, which is all there is when the project lives elsewhere (a dbt
    project object run by the warehouse): with no selection, `--exclude` would replace a default selector and build
    everything else.
    """
    if inv.selector:
        return True
    selectors = (manifest or {}).get('selectors') or {}
    if any(isinstance(item, dict) and item.get('default') is True for item in selectors.values()):
        return True
    path = Path(project_dir) / 'selectors.yml'
    if not path.is_file():
        return False
    try:
        doc = yaml.safe_load(path.read_text())
        return any(isinstance(item, dict) and item.get('default') is True for item in doc.get('selectors') or [])
    except Exception:  # unreadable selectors: assume a default exists, which can only mean building more
        return True


SELECTABLE = ('model.', 'seed.', 'snapshot.', 'test.')


def _listed_ids(inv, dbt_bin, subprocess_run, cwd):
    """The selection from `dbt ls`: dbt Fusion 2.0 writes compile run_results.json with no results."""
    done = subprocess_run(inv_mod.list_argv(inv, dbt_bin), cwd=cwd, capture_output=True, text=True)
    if done.returncode:
        raise StateUnavailable(f'dbt ls exited {done.returncode}')
    ids = []
    for line in (done.stdout or '').splitlines():
        if line.startswith('{'):
            uid = json.loads(line).get('unique_id')
            if isinstance(uid, str) and uid.startswith(SELECTABLE):
                ids.append(uid)
    return ids


def _present(provider, schemas, err):
    present = {}
    for db, schema in schemas:
        try:
            present[(db, schema)] = provider.relations(db, schema)
        except Exception as error:  # e.g. the schema does not exist yet: its targets are absent
            _say(err, f'warning: could not list {db + "." if db else ""}{schema}: {error}; treating its targets as absent')
            present[(db, schema)] = set()
    return present


LINEAGE_MATERIALIZATIONS = ('view', 'ephemeral')


def _parents(manifest, facts):
    """Unselected model, seed and snapshot parents: (relations to stamp, lineage of view and ephemeral parents).

    A view or ephemeral parent holds no data of its own, so it is stamped by lineage: the stamps of the
    sources and tables it reads, through further views and ephemerals, plus each view's deployed
    definition (see _compose). A lineage is (leaves, views) or None when it reaches a node selected in
    this invocation, which this very run may rebuild, or anything that cannot be resolved; the parent
    then stays unknown. Ephemeral bodies are inlined into whatever reads them, so they add no definition.
    """
    selected = {f.unique_id for f in facts}
    nodes = manifest.get('nodes') or {}
    sources = manifest.get('sources') or {}
    relations, lineage = {}, {}

    def resolve(uid, path, leaves, views):
        node = nodes.get(uid)
        if node is None or uid in selected or uid in path:
            return False
        materialized = (node.get('config') or {}).get('materialized')
        if materialized not in LINEAGE_MATERIALIZATIONS:
            relation = artifacts.relation_of(node)
            if relation is None:
                return False
            leaves[uid] = relation
            return True
        if materialized == 'view':
            relation = artifacts.relation_of(node)
            if relation is None:
                return False
            views[uid] = relation
        for dep in (node.get('depends_on') or {}).get('nodes') or []:
            if dep.startswith('source.'):
                if dep not in sources:
                    return False
                leaves[dep] = sources[dep]
            elif not resolve(dep, path | {uid}, leaves, views):
                return False
        return True

    for fact in facts:
        for dep in fact.depends_on:
            if dep in selected or dep in relations or dep in lineage or not dep.startswith(('model.', 'seed.', 'snapshot.')):
                continue
            node = nodes.get(dep)
            if not node:
                continue
            if (node.get('config') or {}).get('materialized') in LINEAGE_MATERIALIZATIONS:
                leaves, views = {}, {}
                lineage[dep] = (leaves, views) if resolve(dep, frozenset(), leaves, views) else None
            elif artifacts.relation_of(node) is not None:
                relations[dep] = artifacts.relation_of(node)
            else:  # a parent that cannot be stamped is unknown, never absent: the planner reads absent as unchanged
                lineage[dep] = None
    return relations, lineage


def _names(database, schema, identifier):
    return tuple(str(part or '').casefold() for part in (database, schema, identifier))


def _reads_only(definition, view, allowed, dialect):
    """True when every relation the deployed view SQL names is one the lineage accounts for.

    A relation hardcoded in the view (not a ref or source) would change unseen, so it makes the lineage
    unknown; so does SQL that cannot be parsed.
    """
    try:
        tree = sqlglot.parse_one(definition, read=dialect)
    except Exception:
        return False
    if tree is None or isinstance(tree, exp.Command):
        return False
    ctes = {cte.alias_or_name.casefold() for cte in tree.find_all(exp.CTE)}
    for table in tree.find_all(exp.Table):
        if not table.name:
            return False
        if not table.db and not table.catalog and table.name.casefold() in ctes:
            continue
        name = _names(table.catalog or view.database, table.db or view.schema, table.name)
        if name not in allowed:
            return False
    return True


def _compose(leaves, views, stamped, definitions, dialect):
    """One stamp for a lineage: unknown when any leaf stamp or view definition is, or a view reads past it."""
    pairs = sorted((uid, stamped.get(uid, (None, None))[0]) for uid in leaves)
    if not pairs or any(stamp is None for _, stamp in pairs):
        return None
    allowed = {_names(r.database, r.schema, r.identifier) for r in views.values()}
    for leaf in leaves.values():
        if isinstance(leaf, artifacts.Relation):
            allowed.add(_names(leaf.database, leaf.schema, leaf.identifier))
        else:
            allowed.add(_names(leaf.get('database'), leaf['schema'], leaf.get('identifier') or leaf['name']))
    shapes = []
    for uid, relation in sorted(views.items()):
        definition = definitions.get(relation)
        if not definition or not _reads_only(definition, relation, allowed, dialect):
            return None
        shapes.append((uid, hashlib.sha256(definition.encode('utf-8')).hexdigest()))
    payload = json.dumps([pairs, shapes], separators=(',', ':'))
    return 'lineage:' + hashlib.sha256(payload.encode('utf-8')).hexdigest()


def _stamps(provider, sources, loaded_at, parents=None, manifest=None):
    """Source stamps: loaded_at_query, then loaded_at_field, else the provider; None stays unknown.

    Unselected table parents are stamped through the provider as if they were sources; unselected
    view and ephemeral parents get a stamp composed from their lineage (see _parents and _compose).
    """
    relations_in, lineage = parents or ({}, {})
    wanted = set(sources) | set(relations_in) | set(lineage)  # lineage leaves are inputs, not request sources
    sources = dict(sources)
    tables = dict(relations_in)
    for found in lineage.values():
        for uid, leaf in (found[0] if found else {}).items():
            if uid.startswith('source.'):
                sources.setdefault(uid, leaf)
            else:
                tables.setdefault(uid, leaf)
    declared, provided = [], []
    for uid, source in sources.items():
        pair = artifacts.loaded_at(source, manifest)
        (declared if pair else provided).append((uid, pair, source))
    out = {}
    if declared:
        values = loaded_at(getattr(provider, 'connection', None), [(uid, pair[1]) for uid, pair, _ in declared])
        for uid, pair, _ in declared:
            out[uid] = (values.get(uid), pair[0])
    relations = {uid: artifacts.Relation(s.get('database'), s['schema'], s.get('identifier') or s['name'], s['relation_name'])
                 for uid, _, s in provided}
    relations.update(tables)
    if relations:
        stamped = provider.stamps(list(relations.values()))
        for uid, relation in relations.items():
            stamp = stamped.get(relation)
            out[uid] = (stamp, 'provider' if stamp is not None else 'unknown')
    path_views = {r for found in lineage.values() if found for r in found[1].values()}
    definitions = provider.view_definitions(list(path_views)) if path_views else {}
    for uid, found in lineage.items():
        stamp = _compose(*found, out, definitions, provider.dialect) if found else None
        out[uid] = (stamp, 'lineage' if stamp is not None else 'unknown')
    return {uid: value for uid, value in out.items() if uid in wanted}


def _warehouse(provider, err):
    """The provider's warehouse facts, only when complete enough for the service to price; never raises."""
    try:
        found = provider.warehouse() if hasattr(provider, 'warehouse') else None
        return found if isinstance(found, dict) and found.get('credits_per_hour') else None
    except Exception as error:
        _say(err, f'warehouse lookup skipped: {type(error).__name__}: {error}')
        return None


def _ms_since(started):
    return int((time.time() - started) * 1000)


MAX_EVENT_MESSAGES = 100
MAX_EVENT_MESSAGE_CHARS = 4000


class _Recorder:
    """Passes writes through to `stream` and keeps the `[bnr]` lines, for the client event sent after the run."""

    def __init__(self, stream):
        self.stream, self.lines, self._partial = stream, [], ''

    def write(self, text):
        self.stream.write(text)
        self._partial += text
        *done, self._partial = self._partial.split('\n')
        self.lines.extend(line[len('[bnr] '):] for line in done if line.startswith('[bnr] '))
        return len(text)

    def flush(self):
        self.stream.flush()


class _RecorderHandler(logging.Handler):
    def __init__(self, recorder):
        super().__init__(logging.WARNING)
        self.recorder = recorder

    def emit(self, record):
        try:
            print(f'[bnr] {record.getMessage()}', file=self.recorder, flush=True)
        except Exception:  # a log line must never break the run
            pass


def send_event(env, api_factory, *, kind, messages, invocation, project=None, plan_id=None, err=sys.stderr):
    """Record a fallback, or a planned run's warnings, with the state service. Best effort: never raises."""
    token = env.get('BNR_TOKEN') or ''
    try:
        clean = [(m.replace(token, '***') if token else m)[:MAX_EVENT_MESSAGE_CHARS] for m in messages][-MAX_EVENT_MESSAGES:]
        body = dict(account_id=int(env['BNR_ACCOUNT_ID']), kind=kind, plan_id=plan_id, project=project, messages=clean,
                    invocation=invocation)
        api_factory(env['BNR_URL'], token).events(body)
    except Exception as error:  # troubleshooting data must never change the run's outcome (a bad account id included)
        print(f'[bnr] could not record the {kind} event: {type(error).__name__}: {error}', file=err, flush=True)


def _client_invocation(inv, env, executor):
    return dict(command=inv.command, args=inv_mod.redacted_args(inv), cause=env.get('BNR_CAUSE') or f'bnr dbt {inv.command}',
                client=dict(name='bnr-build-state', version=__version__, executor=executor))


def run(argv, env, *, api_factory=StateApi, err=sys.stderr, executor='local', **kwargs):
    """Wrap one dbt invocation (see _run), then tell the state service about a fallback or the run's warnings.

    Runs that never consult the service (not wrapped, BNR_STATE_MODE_OVERRIDE=off, partial data, no credentials) send
    nothing. A run that fell back before planning has no plan, so this event is the only trace of it.
    """
    recorder = _Recorder(err)
    context = {}
    # Providers report failed or timed-out metadata queries through logging; carry them into the same [bnr] lines so
    # they reach the event, not only an unprefixed stderr line.
    handler = _RecorderHandler(recorder)
    package_log = logging.getLogger('bnr_build_state')
    package_log.addHandler(handler)
    try:
        code = _run(argv, env, api_factory=api_factory, err=recorder, executor=executor, context=context, **kwargs)
    finally:
        package_log.removeHandler(handler)
    if context.get('inv') is not None and not context.get('empty') and (recorder.lines or not context.get('plan_id')):
        send_event(env, api_factory, kind='warnings' if context.get('plan_id') else 'fallback', messages=recorder.lines,
                   invocation=_client_invocation(context['inv'], env, executor), project=context.get('project'),
                   plan_id=context.get('plan_id'), err=err)
    return code


def _run(argv, env, *, api_factory=StateApi, provider_factory=for_profile, subprocess_run=subprocess.run,
         out=sys.stdout, err=sys.stderr, cwd='.', loaded_at=default_loaded_at, profile=None, executor='local', context=None):
    """`profile`: the target's connection facts when no local profiles.yml describes it (dbt run by the warehouse
    itself, see providers/); otherwise read from the project the way dbt does. `context` receives the invocation once
    the service is consulted, then the project and plan id."""
    context = {} if context is None else context
    dbt_bin = env.get('BNR_DBT_BIN', 'dbt')
    inv = inv_mod.parse(argv)
    if inv is None:
        return subprocess_run([dbt_bin, *argv], cwd=cwd).returncode
    if env.get('BNR_STATE_MODE_OVERRIDE') == 'off':
        _say(err, 'BNR_STATE_MODE_OVERRIDE=off, running dbt unchanged')
        return _original(inv, dbt_bin, subprocess_run, cwd)
    if inv.partial_data:  # relations built with --empty or --sample must never be recorded as built
        _say(err, '--empty or --sample builds partial data: not planned or reported, running dbt unchanged')
        return _original(inv, dbt_bin, subprocess_run, cwd)
    missing = [k for k in ('BNR_URL', 'BNR_TOKEN', 'BNR_ACCOUNT_ID') if not env.get(k)]
    if missing:
        _say(err, f'{", ".join(missing)} not set, running dbt unchanged')
        return _original(inv, dbt_bin, subprocess_run, cwd)

    context['inv'] = inv
    project_dir = inv.project_dir or env.get('DBT_PROJECT_DIR') or cwd
    compile_started = time.time()
    compile_code = subprocess_run(inv_mod.compile_argv(inv, dbt_bin), cwd=cwd).returncode
    timings = dict(compile_ms=_ms_since(compile_started))
    if compile_code:  # compile can fail where the build would not; the wrapper's own step never blocks the run
        _say(err, f'{FALLBACK}: compile exited {compile_code}')
        return _original(inv, dbt_bin, subprocess_run, cwd)

    provider = None
    try:
        target = artifacts.target_dir(project_dir, inv.target_path, env)
        manifest = artifacts.load_json(target / 'manifest.json')
        results_path = target / 'run_results.json'
        if results_path.stat().st_mtime < compile_started:
            raise StateUnavailable('compile artifacts are stale')
        results = artifacts.load_json(results_path)
        # The build writes its own run_results.json; removing this one means a build that dies
        # early can never be mistaken for a successful run.
        results_path.unlink()
        project = artifacts.project_name(project_dir, manifest)
        context['project'] = project
        step_started = time.time()
        selected = artifacts.selected_ids(results) or _listed_ids(inv, dbt_bin, subprocess_run, cwd)
        timings['list_ms'] = _ms_since(step_started)
        selected = [uid for uid in selected if inv_mod.builds_type(inv, uid)]
        if inv.command == 'run':  # `dbt run` executes models only; its listing still names tests, seeds and snapshots
            selected = [uid for uid in selected if uid.startswith('model.')]
        if not selected:
            # `state:modified+` with nothing modified, a selector that matched nothing: dbt will build nothing, so there
            # is nothing to plan and nothing went wrong. Not a fallback: no event is recorded.
            _say(err, 'the selection is empty: nothing to plan, running dbt unchanged')
            context['empty'] = True
            _close(provider, err)
            return _original(inv, dbt_bin, subprocess_run, cwd)
        facts = artifacts.facts(manifest, selected, target, project)
        facts = artifacts.neutralize_run_timestamps(facts, artifacts.run_started_at(manifest, results))
        facts, folded = artifacts.inline_ephemerals(facts)
        facts = artifacts.expand_through_views(facts)
        ephemeral_facts = {e.unique_id: e for group in folded.values() for e in group}
        sources = artifacts.sources_for(manifest, facts)
        profile = profile or read_profile(project_dir, profiles_dir=inv.profiles_dir, target=inv.target, env=env)
        provider = provider_factory(profile)
        parents = _parents(manifest, facts)
        if inv.favor_state:
            # dbt reads unselected parents from the --state artifacts' relations (dbt-core providers.create_relation),
            # not the ones the manifest names, so a stamp on the manifest's relation would track the wrong table.
            parents = ({}, {uid: None for group in parents for uid in group})
        step_started = time.time()
        with ThreadPoolExecutor(max_workers=1) as pool:
            stamps_future = pool.submit(_stamps, provider, sources, loaded_at, parents, manifest)
            sql_facts = {f.unique_id: analyze(f.sql, provider.dialect) for f in [*facts, *ephemeral_facts.values()] if f.sql}
            stamps = stamps_future.result()
        present = _present(provider, artifacts.target_schemas(facts), err)
        warehouse = _warehouse(provider, err)
        timings['stamps_ms'] = _ms_since(step_started)
        timings['before_plan_ms'] = _ms_since(compile_started)
        # Which client and how long its own steps took, so a plan can be traced to client behavior and the wrapper's
        # overhead weighed against what it saves. Stored by the service with the rest of the invocation.
        invocation = dict(_client_invocation(inv, env, executor), full_refresh=inv.full_refresh, timings=timings)
        if warehouse:
            invocation['warehouse'] = warehouse
        request = planning.plan_request(
            account_id=int(env['BNR_ACCOUNT_ID']), project=project, platform=provider.platform, locator=provider.locator,
            database=str(profile.output.get('database') or profile.output.get('dbname') or profile.output.get('path') or ''),
            schema=str(profile.output.get('schema') or ''), engine=artifacts.engine_of(results),
            invocation=invocation,
            run_id=int(env['BNR_RUN_ID']) if env.get('BNR_RUN_ID') else None,
            facts=facts, sql_facts=sql_facts, stamps=stamps, present=present, folded=folded)
        plan = api_factory(env['BNR_URL'], env['BNR_TOKEN']).plan(request)
        plan_id, mode = plan.get('plan_id'), plan.get('mode')
        if not isinstance(plan_id, str) or not plan_id or mode not in MODES:
            raise StateUnavailable(f'invalid plan response (plan_id {plan_id!r}, mode {mode!r})')
        context['plan_id'] = plan_id
        if mode == 'enforce' and _selector_in_use(inv, project_dir, manifest):
            _say(err, '--selector in use: Enforce exclusions not applied (dbt does not combine --exclude with '
                      '--selector); planning in Shadow')
            mode = 'shadow'
        skipped = planning.skipped_ids(plan) if mode == 'enforce' else []
        excluded = planning.excludable(skipped, facts)
        exclusions = planning.exclusions_for(skipped, facts)
    except Exception as error:  # anything before the plan must never stop the build
        _say(err, f'{FALLBACK}: {type(error).__name__}: {error}')
        _close(provider, err)
        return _original(inv, dbt_bin, subprocess_run, cwd)

    _close(provider, err)  # an embedded warehouse file lock would block the build's writes
    build_started = time.time()
    build_code = subprocess_run(inv_mod.build_argv(inv, dbt_bin, exclusions), cwd=cwd).returncode
    exit_code = build_code
    try:
        built = _trusted_results(target, inv.command, build_started)
        outcome = None  # the service's answer to the report: what it kept, and the disagreements it found
        if built is None:
            _say(err, 'no run results from dbt, nothing reported')
            report = dict(results=[])
        else:
            # Shadow checks every planned skip against the rebuild; Enforce checks the nodes it built as `unverified`.
            observations = _observe(provider_factory, profile, facts, err, sql_facts) if mode in ('shadow', 'enforce') else {}
            done = {r.get('unique_id') for r in built.get('results') or []}
            excluded_ids = {f.unique_id for f in excluded}
            retest, reused_tests = planning.cut_tests(plan, facts, done, excluded_ids) if excluded_ids else ([], [])
            if retest and inv.command == 'build':
                exit_code = _retest(retest, inv, dbt_bin, subprocess_run, cwd, target, built, build_code, err)
                done = {r.get('unique_id') for r in built.get('results') or []}
            reused = [f.unique_id for f in excluded] + [f.unique_id for f in reused_tests]
            _warn_missing(plan, facts, inv.command, done, set(reused), err)
            report = planning.report_request(plan_id, built, reused, observations)
            try:
                outcome = api_factory(env['BNR_URL'], env['BNR_TOKEN']).report(report)
            except StateUnavailable as error:
                _say(err, f'report failed: {error}')
        s = planning.summary(plan, report)
        line = f"mode {mode}: built {s['built']}, reused {s['reused']}, errors {s['errors']}, undetermined {s['undetermined']}"
        if isinstance(outcome, dict) and 'disagreements' in outcome:
            # The one number a Shadow run is for: planned skips the rebuild contradicted. Without it in the run log an
            # operator has to open the service to learn whether the run was clean.
            line += f", disagreements {outcome['disagreements']}"
        _say(out, line)
        _say(out, f"bnr state explain {plan_id}")
    except Exception as error:  # reporting is advisory; dbt's exit code stands
        _say(err, f'report failed: {type(error).__name__}: {error}')
    return exit_code


def _retest(tests, inv, dbt_bin, subprocess_run, cwd, target, built, build_code, err):
    """Run the planned-build tests that `--exclude` took with a skipped parent, merge their results into `built`.

    Returns the exit code for the whole invocation: the build's when it failed, else the test step's. With
    `--fail-fast` a failed build stops here, as dbt itself would not have gone on to the tests.
    """
    names = ', '.join(f.unique_id for f in tests)
    if build_code and inv.fail_fast:
        _say(err, f'build failed with --fail-fast: not running {len(tests)} test(s) excluded with a skipped parent: {names}')
        return build_code
    _say(err, f'running {len(tests)} test(s) dbt excluded with a skipped parent: {names}')
    started = time.time()
    test_code = subprocess_run(inv_mod.test_argv(inv, dbt_bin, planning.test_selectors(tests)), cwd=cwd).returncode
    tested = _trusted_results(target, 'test', started)
    if tested is None:
        _say(err, 'no run results from the dbt test step')
    else:
        wanted = {f.unique_id for f in tests}
        built.setdefault('results', []).extend(r for r in tested.get('results') or [] if r.get('unique_id') in wanted)
    return build_code or test_code


def _warn_missing(plan, facts, command, done, reused, err):
    """Planned builds that dbt never reported: a selector surprise must not go unnoticed."""
    by_id = {f.unique_id: f for f in facts}
    expected = ('model',) if command == 'run' else ('model', 'seed', 'snapshot', 'test')
    missing = []
    for item in plan.get('nodes') or []:
        fact = by_id.get(item.get('unique_id'))
        if (item.get('action') != 'build' or fact is None or fact.resource_type not in expected
                or fact.unique_id in done or fact.unique_id in reused or (fact.resource_type == 'model' and fact.relation is None)):
            continue
        missing.append(fact.unique_id)
    if missing:
        _say(err, f"warning: {len(missing)} planned node(s) missing from dbt results: {', '.join(missing)}")


def _close(provider, err):
    if provider is None:
        return
    try:
        provider.close()
    except Exception as error:
        _say(err, f'provider close failed: {type(error).__name__}: {error}')


def _trusted_results(target, command, started):
    """run_results.json written by this build, or None."""
    path = target / 'run_results.json'
    try:
        if path.stat().st_mtime < started:
            return None
        doc = artifacts.load_json(path)
    except (OSError, ValueError):
        return None
    if not isinstance(doc, dict) or (doc.get('args') or {}).get('which') != command:
        return None
    return doc


def _observe(provider_factory, profile, facts, err, sql_facts=None):
    observer = None
    try:
        observer = provider_factory(profile)
        # Everything that stores rows: a seed's planned skip is verified like a model's; a snapshot is never a planned
        # skip, its observation only costs a row in a catalog read the schema pays for anyway.
        observed = [f for f in facts if f.relation is not None and f.resource_type in artifacts.MATERIALIZED_TYPES]
        scope = {f.relation: planning.content_hash_scope(f, (sql_facts or {}).get(f.unique_id)) for f in observed}
        values = observer.observe([f.relation for f in observed], hash_scope=scope)
        return {f.unique_id: {k: v if v is None or isinstance(v, str) else str(v) for k, v in values[f.relation].items()}
                for f in observed if f.relation in values}
    except Exception as error:  # observations are advisory
        _say(err, f'observations skipped: {type(error).__name__}: {error}')
        return {}
    finally:
        _close(observer, err)


def explain(plan_id, env, *, api_factory=StateApi, node=None, out=sys.stdout):
    payload = api_factory(env.get('BNR_URL', ''), env.get('BNR_TOKEN', '')).explain(plan_id)
    print(f"plan {payload.get('plan_id')} mode {payload.get('mode')}", file=out)
    for item in payload.get('nodes') or []:
        uid = item['unique_id']
        if node and node not in uid:
            continue
        inputs = item.get('inputs') or {}
        old, new = (inputs.get('sql_sha256') or [None, None])[:2]
        changed = [dep for dep, pair in (inputs.get('stamps') or {}).items() if pair[0] != pair[1]]
        flags = ','.join(inputs.get('flags') or [])
        print(f"{item['action']:5} {item['reason']:17} {uid}  sql {(old or '-')[:8]}->{(new or '-')[:8]}"
              f"  changed {','.join(changed) or '-'}{'  flags ' + flags if flags else ''}  result {item.get('result_status') or '-'}", file=out)
    return 0
